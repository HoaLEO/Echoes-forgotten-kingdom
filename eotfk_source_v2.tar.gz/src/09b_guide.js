// ============================================================================
// Save / continue (interaction replay log), compass + waypoint guidance, hints
// ============================================================================
// The world is deterministic, so progress is stored as the ordered list of interactions the player performed
// (plus where each star-stone was released). Loading replays that list against a fresh world with sound and
// toasts muted, which restores every door, puzzle and pickup through the same code paths normal play uses.
const SAVE = {
  KEY: 'eotfk_save_v1', log: [], replaying: false, dirty: false, acc: 0, prevGrab: null, stoneSet: null,
  read() { try { const d = JSON.parse(localStorage.getItem(SAVE.KEY) || 'null'); return d && d.v === 1 && Array.isArray(d.log) ? d : null; } catch (e) { return null; } },
  exists() { return !!SAVE.read(); },
  clear() { SAVE.log = []; SAVE.dirty = false; try { localStorage.removeItem(SAVE.KEY); } catch (e) { } },
  write() {
    if (G.mode !== 'play' || SAVE.replaying) return; SAVE.flush(); SAVE.dirty = false; SAVE.acc = 0;
    const s = P.onGround && !P.grab ? P.pos : P.safe, r = v => Math.round(v * 100) / 100;
    try { localStorage.setItem(SAVE.KEY, JSON.stringify({ v: 1, log: SAVE.log, p: [r(s.x), r(s.y), r(s.z), r(P.yaw), r(P.pitch)], time: Math.round(G.time), frags: G.fragCount(), region: G.region, hint: GUIDE.lv, seen: GUIDE.seen })); } catch (e) { }
  },
  hook(idx, o) {
    if (SAVE.replaying || G.mode !== 'play') return;
    if (!SAVE.stoneSet) SAVE.stoneSet = new Set(PLATES.stones.map(s => s.inter));
    if (SAVE.stoneSet.has(o) || o === GATE.core) return;
    SAVE.log.push([Math.round(G.time * 100) / 100, idx]); SAVE.dirty = true; SAVE.acc = 4;
  },
  flush() {   // a released star-stone is recorded with its resting place
    if (SAVE.prevGrab && !P.grab) { const s = SAVE.prevGrab; SAVE.log.push([Math.round(G.time * 100) / 100, 's', PLATES.stones.indexOf(s), Math.round(s.x * 100) / 100, Math.round(s.z * 100) / 100]); SAVE.dirty = true; SAVE.acc = 4; }
    SAVE.prevGrab = P.grab;
  },
  frame(dt) {   // called every simulated frame
    SAVE.flush(); SAVE.acc += dt; if (SAVE.acc > (SAVE.dirty ? 5 : 20)) SAVE.write();
  },
  tick(d) { while (d > 1e-4) { const s = Math.min(.1, d); W.time += s; updateTweens(s); for (const u of W.updaters) u(s, W.time); d -= s; } },
  quiet() { if (UI.panel) { UI.show(UI.panel, false); UI.panel = null; } UI.dlg = null; UI.parent = null; },
  replay(d) {
    SAVE.replaying = true; let t = 0;
    try {
      for (const e of d.log) {
        SAVE.tick(Math.min(5, Math.max(0, e[0] - t))); t = e[0];
        if (e[1] === 's') { const s = PLATES.stones[e[2]]; if (s) { s.x = e[3]; s.z = e[4]; s.g.position.x = s.x; s.g.position.z = s.z; } }
        else { const o = W.inter[e[1]]; if (o) o.use(); }
        SAVE.quiet(); P.grab = null;
      }
      SAVE.tick(6);
    } catch (err) { console.error('save replay failed', err); }
    SAVE.quiet(); SAVE.replaying = false; SAVE.log = d.log.slice(); SAVE.prevGrab = null;
    P.pos.set(d.p[0], d.p[1], d.p[2]); P.vel.set(0, 0, 0); P.yaw = d.p[3]; P.pitch = d.p[4]; P.camY = P.pos.y; P.safe.copy(P.pos); P.onGround = true;
    G.time = d.time || 0; GUIDE.lv = d.hint || 0; GUIDE.seen = d.seen || {}; GUIDE.key = ''; GUIDE.fresh = true; $('toasts').innerHTML = ''; UI.refresh();
  },
};
LOGHOOK = SAVE.hook;
function later(sec, fn) { tween(sec, () => { }, fn); }   // game-time timer (pauses with the game, replays deterministically)

// ---------------------------------------------------------------- guidance
const NAV = {
  n: { founding: [3.4, 13], court: [0, 6], gate: [0, -9.5], westArch: [-20, 0], trail1: [-34, -4], fork: [-48, 6], trail2: [-62, 2], glade: [-74, 4], hmid: [-53, 20], hollow: [-60, 30], grove: [-43.5, -23],
    templeDoor: [19.5, 0], ramp: [30, 0], causeway: [44, 0], hall: [58, 0], hallS: [65, 7], vault: [65, 16.5], chamberW: [77.5, 0], chamber: [82, 3], hidDoor: [86, -8.5], hidVault: [86, -15.5],
    stairDoor: [12, -19.5], p1: [30, -36], p2: [42, -60], p3: [34, -82], p4: [21, -91.5], summit: [9, -95] },
  e: [['founding', 'court'], ['court', 'gate'], ['court', 'westArch'], ['westArch', 'trail1'], ['trail1', 'fork'], ['fork', 'trail2'], ['trail2', 'glade'], ['fork', 'hmid'], ['hmid', 'hollow'], ['trail1', 'grove'],
    ['court', 'templeDoor'], ['templeDoor', 'ramp'], ['ramp', 'causeway'], ['causeway', 'hall'], ['hall', 'hallS'], ['hallS', 'vault'], ['hall', 'chamberW'], ['chamberW', 'chamber'], ['chamber', 'hidDoor'], ['hidDoor', 'hidVault'],
    ['court', 'stairDoor'], ['gate', 'stairDoor'], ['stairDoor', 'p1'], ['p1', 'p2'], ['p2', 'p3'], ['p3', 'p4'], ['p4', 'summit']],
  adj: null,
  route(px, py, pz, target) {
    if (!NAV.adj) { NAV.adj = {}; for (const k in NAV.n) NAV.adj[k] = []; for (const [a, b] of NAV.e) { NAV.adj[a].push(b); NAV.adj[b].push(a); } }
    const N = NAV.n, summitLvl = py > 24, mount = py > 4 && !summitLvl;
    let near = null, bd = 1e9; for (const k in N) { if ((k === 'summit' || k === 'p4') !== summitLvl && (summitLvl || k === 'summit')) continue; const d = Math.hypot(N[k][0] - px, N[k][1] - pz); if (d < bd) { bd = d; near = k; } }
    if (near === target) return N[target];
    const prev = { [near]: null }, q = [near]; while (q.length) { const c = q.shift(); if (c === target) break; for (const nb of NAV.adj[c]) if (!(nb in prev)) { prev[nb] = c; q.push(nb); } }
    const path = []; for (let c = target; c; c = prev[c]) path.unshift(c); if (path[0] !== near) return N[target];
    const a = N[path[0]], b = N[path[1]], lab = Math.hypot(b[0] - a[0], b[1] - a[1]);
    return (bd < 6 || Math.hypot(b[0] - px, b[1] - pz) < lab + 1) ? b : a;
  },
};
const GUIDE = {
  lv: 0, key: '', since: 0, nudged: false, seen: {}, aim: null,
  // current step: [id, nav target, hints…]
  state() {
    const got = f => !!(G.inv[f] || G.placed[f]), F = G.flags;
    if (!G.notes.includes('founding') && G.fragCount() === 0 && !Object.keys(F).length) return ['founding', 'founding', 'A glowing tablet stands a few steps ahead of where you woke. Walk up to it and press E to read.', 'Glowing tablets hold clues; pale spirits will talk. Warden Ilyra, in the courtyard, knows the way to everything.'];
    if (!got('frag_root')) {
      if (!RUNES.solved) return ['runes', 'glade', 'The first fragment is in the forest. Leave the courtyard through the WEST arch and follow the trail to the glade of five rune stones.', 'A tablet in the glade — the Song of Seasons — gives the order. Each verse names one sign.', 'Wake the runes in this order: Root (tree), Wave, Sun, Moon, Star. A wrong touch only resets them.'];
      return ['rootfrag', 'glade', 'The rune ring is awake. The Fragment of the Root is waiting in the middle of the glade.'];
    }
    if (!F.door_temple) {
      if (G.has('key_verdant')) return ['templedoor', 'templeDoor', 'You hold the Verdant Key. The temple door is the wave-carved slab in the EAST wall of the courtyard.'];
      return ['verdant', GUIDE.seen.fork ? 'hollow' : 'fork', 'The temple door needs the Verdant Key, kept somewhere in the forest. Go back to the fork in the forest trail, where a stone watcher stands.', 'Look where the stone watcher is facing: a narrow side path lit by blue mushroom caps leaves the main trail there, heading south.', 'Follow the blue caps south from the fork to a small hollow. The Verdant Key floats above the stump inside.'];
    }
    if (!got('frag_tide')) {
      if (!LIGHT.on) return G.has('lens') ? ['seatlens', 'chamber', 'Carry the Crystal Lens to the Chamber of Mirrors at the east end of the temple and set it in the stone lamp.'] : ['lens', 'vault', 'The temple lamp is blind: it needs a lens. Cross the causeway (jump the broken gap) into the great hall.', 'From the great hall, take the SOUTH corridor down into the flooded vault.', 'The Crystal Lens rests on a pedestal in the flooded vault. Wade in and take it.'];
      if (!LIGHT.solved) return ['mirrors', 'chamber', 'The beam must reach the Eye on the far wall. Turn the three mirrors (E or left click) so the light bends around the pillar.', 'The light should travel NORTH from the first mirror, EAST from the second, then SOUTH from the third into the Eye.', 'Turn each mirror in order, starting with the one the beam hits first. Keep turning until the beam leaves toward the next mirror; each press is an eighth of a turn.'];
      return ['tidefrag', 'hidVault', 'The Eye is open. A hidden door has slid aside in the NORTH wall of the Chamber of Mirrors — the fragment is inside.'];
    }
    if (!F.door_stair) return G.has('key_star') ? ['stairdoor', 'stairDoor', 'The Star Key opens the barred stair in the NORTH wall of the courtyard, just east of the Echo Gate.'] : ['starkey', 'hidVault', 'The Star Key lies in the hidden vault of the temple, beside where the Fragment of the Tide rested.'];
    if (!got('frag_sky')) {
      if (!PLATES.solved) return ['plates', 'summit', 'Climb the mountain stair to the Celestial Sanctuary on the summit.', 'Three star-stones (Sun, Moon, Star) must each stand on the plate carved with the same sign. Press E to take hold of a stone, walk it over, press E to let go.', 'Any stone lights a plate, but only matching signs open the orrery. If a stone ends up somewhere awkward, touch the Rune of Return to send them all home.'];
      return ['skyfrag', 'summit', 'The orrery has opened. The Fragment of the Sky is waiting at its heart.'];
    }
    if (G.placedCount() < 3) return ['place', 'gate', 'You hold every fragment. Return to the Echo Gate in the courtyard and set each fragment in a socket (E).'];
    return ['awaken', 'gate', 'All three fragments are set. Touch the heart of the Echo Gate to awaken it.'];
  },
  hint() {
    if (G.mode !== 'play' || UI.panel) return; const s = GUIDE.state(), hints = s.slice(2), i = Math.min(GUIDE.lv, hints.length - 1);
    UI.toast('Hint ' + (i + 1) + '/' + hints.length + ' — ' + hints[i], 'hint'); AU.sfx('page'); if (GUIDE.lv < hints.length - 1) GUIDE.lv++; GUIDE.nudged = true; SAVE.dirty = true;
  },
  frame(dt) {
    const s = GUIDE.state(); if (s[0] !== GUIDE.key) { GUIDE.key = s[0]; if (!GUIDE.fresh) GUIDE.lv = 0; GUIDE.fresh = false; GUIDE.since = 0; GUIDE.nudged = false; }
    GUIDE.since += dt; if (!GUIDE.nudged && GUIDE.since > 210) { GUIDE.nudged = true; UI.toast('Not sure where to go? Press H for a hint.', 'hint'); }
    if (!GUIDE.seen.fork && Math.hypot(P.pos.x + 48, P.pos.z - 6) < 9) { GUIDE.seen.fork = 1; SAVE.dirty = true; }
    // compass
    const el = $('compass'); if (!el) return; const show = OPT.guide !== false; el.classList.toggle('hidden', !show); if (!show) return;
    const head = -P.yaw, wrap = a => Math.atan2(Math.sin(a), Math.cos(a)), W2 = 170, C = GUIDE.cards || (GUIDE.cards = [...el.querySelectorAll('b')]);
    for (let i = 0; i < 8; i++) { const r = wrap(i * Math.PI / 4 - head), c = C[i]; if (Math.abs(r) > 1.66) { c.style.opacity = 0; continue; } c.style.opacity = 1 - Math.pow(Math.abs(r) / 1.66, 4); c.style.transform = 'translateX(' + (r / (Math.PI / 2) * W2).toFixed(1) + 'px)'; }
    const tgt = NAV.n[s[1]], aim = GUIDE.aim = NAV.route(P.pos.x, P.pos.y, P.pos.z, s[1]), r = wrap(Math.atan2(aim[0] - P.pos.x, -(aim[1] - P.pos.z)) - head), cl = clamp(r, -1.5, 1.5), mk = $('cmpMark');
    mk.style.transform = 'translateX(' + (cl / (Math.PI / 2) * W2).toFixed(1) + 'px)'; mk.className = r < -1.5 ? 'left' : r > 1.5 ? 'right' : '';
    const d = Math.hypot(tgt[0] - P.pos.x, tgt[1] - P.pos.z); $('cmpDist').textContent = d < 4 ? 'here' : Math.round(d) + ' m';
  },
};

// compact description of all persistent world state (used by the save/load regression test)
function snapshot() {
  const r = v => Math.round(v * 10) / 10;
  return { inv: Object.keys(G.inv).sort(), flags: Object.keys(G.flags).sort(), placed: Object.keys(G.placed).sort(), notes: G.notes.slice().sort(), inter: W.inter.map(o => o.on ? 1 : 0).join(''), col: W.colliders.map(c => c.on ? 1 : 0).join(''),
    mirrors: LIGHT.mirrors.map(m => ((m.k % 8) + 8) % 8), light: [LIGHT.on, LIGHT.solved], runes: [RUNES.idx, RUNES.solved], plates: PLATES.solved, stones: PLATES.stones.map(s => [r(s.x), r(s.z)]), pos: [r(P.pos.x), r(P.pos.y), r(P.pos.z)], frags: G.fragCount() };
}
