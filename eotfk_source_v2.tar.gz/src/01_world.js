// ============================================================================
// World registry, terrain, colliders, materials, batching
// ============================================================================
const W = {
  scene: new T.Scene(), colliders: [], inter: [], updaters: [], glows: [], tweens: [], water: [],
  batch: {}, inst: {}, time: 0,
};
const uTime = { value: 0 };
let SEEDC = 1;
const RND = rng(20251113);

// ---------------------------------------------------------------- layout constants
const MOUNT = { x: 0, z: -95, top: 28, r: 18 };
const MPATH = [[12, -20, 0], [30, -36, 3], [42, -60, 11], [34, -82, 20], [21, -91.5, 28], [14.5, -94.5, 28]];
const FPATH = [[-20, 0], [-34, -4], [-48, 6], [-62, 2], [-78, 4]];           // main forest trail
const HPATH = [[-48, 6], [-53, 20], [-60, 30]];                              // hidden trail to the hollow
const GPATH = [[-34, -4], [-42, -20], [-44, -25]];                           // trail to the statue grove
const GLADE = { x: -78, z: 4, r: 14 }, HOLLOW = { x: -60, z: 30, r: 5.5 }, GROVE = { x: -44, z: -25, r: 8 }, POND = { x: -70, z: -6, r: 4.6, y: -.42 };
const WATER_Y = -1.45, TFLOOR = -1.1;
const CH = { x: 86, z: 0 };   // light chamber centre

function sdSeg(px, pz, ax, az, bx, bz) { const dx = bx - ax, dz = bz - az, t = clamp(((px - ax) * dx + (pz - az) * dz) / (dx * dx + dz * dz), 0, 1); return [Math.hypot(px - ax - dx * t, pz - az - dz * t), t]; }
function sdBox(px, pz, cx, cz, hx, hz) { const dx = Math.abs(px - cx) - hx, dz = Math.abs(pz - cz) - hz; return Math.hypot(Math.max(dx, 0), Math.max(dz, 0)) + Math.min(Math.max(dx, dz), 0); }
function polyDist(px, pz, pts) { let d = 1e9; for (let i = 0; i < pts.length - 1; i++) d = Math.min(d, sdSeg(px, pz, pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1])[0]); return d; }
function trailDist(x, z) { return Math.min(polyDist(x, z, FPATH), polyDist(x, z, HPATH) + 1.2, polyDist(x, z, GPATH) + .6); }
// signed distance to the walkable lowland (negative = inside)
function sdLow(x, z) {
  let d = sdBox(x, z, 0, 0, 21.5, 21.5);
  d = Math.min(d, sdBox(x, z, -10, 25.6, 4.4, 4.6));
  d = Math.min(d, polyDist(x, z, FPATH) - 7, Math.hypot(x - GLADE.x, z - GLADE.z) - GLADE.r);
  d = Math.min(d, polyDist(x, z, HPATH) - 2.7, Math.hypot(x - HOLLOW.x, z - HOLLOW.z) - HOLLOW.r);
  d = Math.min(d, polyDist(x, z, GPATH) - 4, Math.hypot(x - GROVE.x, z - GROVE.z) - GROVE.r);
  d = Math.min(d, sdSeg(x, z, 20, 0, 34, 0)[0] - 6, sdBox(x, z, 44, 0, 11, 15.5), sdBox(x, z, 76, 1, 23.5, 22.5));
  d = Math.min(d, sdSeg(x, z, 12, -20, 30, -36)[0] - 4);
  return d;
}
function mpathInfo(x, z) {   // distance to mountain path + path height there
  let bd = 1e9, bh = 0;
  for (let i = 0; i < MPATH.length - 1; i++) { const a = MPATH[i], b = MPATH[i + 1], r = sdSeg(x, z, a[0], a[1], b[0], b[1]); if (r[0] < bd) { bd = r[0]; bh = lerp(a[2], b[2], r[1]); } }
  return [bd, bh];
}
// hard limit of the explorable world: lowland (+ a short bank), the mountain path, the summit plateau
function inPlay(x, z) {
  if (sdLow(x, z) < 2.4) return true;
  if (Math.hypot(x - MOUNT.x, z - MOUNT.z) < MOUNT.r - .7) return true;
  return mpathInfo(x, z)[0] < 4.6;
}
function designH(x, z) {
  // lowland
  let h = (fbm(x * .045 + 9.2, z * .045 - 3.1, 3) - .5) * 2.6 * sstep(-21, -32, x);
  const dp = Math.hypot(x - POND.x, z - POND.z);
  h = lerp(h, 0, sstep(9, 5.5, dp)) - 1.1 * sstep(4.8, 1.5, dp);
  h = lerp(h, .1, sstep(GLADE.r, GLADE.r - 6, Math.hypot(x - GLADE.x, z - GLADE.z)) * .8);
  const wT = sstep(23, 33.5, x) * sstep(-30, -24, z);
  h = lerp(h, -2.0, wT);
  if (x > 30 && x < 56) h -= .5 * (sstep(5.5, 3, Math.hypot(x - 44, z + 8.5)) + sstep(5.5, 3, Math.hypot(x - 44, z - 8.5)));
  const dO = Math.max(0, sdLow(x, z));
  h += sstep(0, 7, dO) * 11 + sstep(2, 14, dO) * (fbm(x * .07, z * .07, 4) * 9 - 2);
  // mountain
  const dM = Math.hypot(x - MOUNT.x, z - MOUNT.z), f = 1 - sstep(MOUNT.r, 62, dM);
  let hm = MOUNT.top * f; hm += (fbm(x * .09 + 4, z * .09, 4) - .5) * 9 * f * (1 - f) * 4 * sstep(MOUNT.r, MOUNT.r + 6, dM);
  if (f > 0 && hm > h) h = hm;
  // carve the mountain path
  const [pd, ph] = mpathInfo(x, z);
  h = lerp(h, ph, sstep(7, 3.2, pd));
  if (dM < MOUNT.r) h = MOUNT.top;
  return h;
}
// ---------------------------------------------------------------- terrain grid
const TG = { x0: -128, z0: -160, nx: 250, nz: 222, h: null };
function buildTerrainGrid() { const { nx, nz } = TG, H = TG.h = new Float32Array((nx + 1) * (nz + 1)); for (let j = 0; j <= nz; j++) for (let i = 0; i <= nx; i++) H[j * (nx + 1) + i] = designH(TG.x0 + i, TG.z0 + j); }
function terrainH(x, z) {
  const fx = clamp(x - TG.x0, 0, TG.nx - 1e-3), fz = clamp(z - TG.z0, 0, TG.nz - 1e-3), i = fx | 0, j = fz | 0, u = fx - i, v = fz - j, w = TG.nx + 1, H = TG.h;
  // matches the triangle split of the terrain mesh
  const a = H[j * w + i], b = H[j * w + i + 1], c = H[(j + 1) * w + i], d = H[(j + 1) * w + i + 1];
  return u + v <= 1 ? a + (b - a) * u + (c - a) * v : d + (c - d) * (1 - u) + (b - d) * (1 - v);
}
function buildTerrainMesh() {
  const { nx, nz, x0, z0 } = TG, w = nx + 1, n = w * (nz + 1), H = TG.h;
  const P = new Float32Array(n * 3), N = new Float32Array(n * 3), C = new Float32Array(n * 3), U = new Float32Array(n * 2), idx = new Uint32Array(nx * nz * 6);
  const cg1 = col('#3a5e22'), cg2 = col('#7f9f38'), cg3 = col('#3f7438'), cd = col('#7f6c4c'), cr = col('#77766c'), crm = col('#7f8aa0'), cw = col('#3d5650'), cdry = col('#5f8f80');
  const hAt = (i, j) => H[clamp(j, 0, nz) * w + clamp(i, 0, nx)];
  for (let j = 0; j <= nz; j++) for (let i = 0; i <= nx; i++) {
    const k = j * w + i, x = x0 + i, z = z0 + j, y = H[k];
    P[k * 3] = x; P[k * 3 + 1] = y; P[k * 3 + 2] = z; U[k * 2] = x * .31; U[k * 2 + 1] = z * .31;
    let nxv = hAt(i - 1, j) - hAt(i + 1, j), nzv = hAt(i, j - 1) - hAt(i, j + 1), nyv = 2; const l = Math.hypot(nxv, nyv, nzv); nxv /= l; nyv /= l; nzv /= l;
    N[k * 3] = nxv; N[k * 3 + 1] = nyv; N[k * 3 + 2] = nzv;
    const n1 = fbm(x * .11, z * .11, 3), n2 = fbm(x * .35 + 40, z * .35, 2);
    let c = [lerp(cg1[0], cg2[0], n1), lerp(cg1[1], cg2[1], n1), lerp(cg1[2], cg2[2], n1)];
    const mix = (t, m) => { c[0] = lerp(c[0], t[0], m); c[1] = lerp(c[1], t[1], m); c[2] = lerp(c[2], t[2], m); };
    mix(cg3, sstep(-18, -40, x) * .55 * n2);                                  // deeper forest greens
    const alt = sstep(6, 22, y); mix(cdry, alt * .7);                         // dry golden grass with altitude
    mix(cd, sstep(2.6, 1.0, trailDist(x, z)) * .85);                          // forest trails
    const [pd] = mpathInfo(x, z); mix(alt > .4 ? crm : cd, sstep(3.6, 2.2, pd) * .9);
    mix(cd, sstep(3, 1, Math.abs(x)) * sstep(21, 17, Math.abs(z)) * .5);      // worn axis of the courtyard
    const wT = sstep(26, 34, x) * sstep(-30, -24, z); mix(cw, wT * .9);       // wet temple basin
    mix(cw, sstep(6, 4, Math.hypot(x - POND.x, z - POND.z)) * .8);
    const rock = sstep(.82, .62, nyv); mix(y > 14 ? crm : cr, rock);          // rock on steep slopes
    const sh = .8 + .4 * n2; C[k * 3] = c[0] * sh; C[k * 3 + 1] = c[1] * sh; C[k * 3 + 2] = c[2] * sh;
  }
  let o = 0; for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) { const a = j * w + i, b = a + 1, c2 = a + w, d = c2 + 1; idx[o++] = a; idx[o++] = c2; idx[o++] = b; idx[o++] = b; idx[o++] = c2; idx[o++] = d; }
  const g = new T.BufferGeometry();
  g.setAttribute('position', new T.BufferAttribute(P, 3)); g.setAttribute('normal', new T.BufferAttribute(N, 3)); g.setAttribute('color', new T.BufferAttribute(C, 3)); g.setAttribute('uv', new T.BufferAttribute(U, 2)); g.setIndex(new T.BufferAttribute(idx, 1));
  const m = new T.Mesh(g, MATS.terrain); m.receiveShadow = true; m.castShadow = true; W.scene.add(m); W.terrain = m;
  // far skirt so the world never visibly ends
  const sk = new T.Mesh(new T.CircleGeometry(900, 48).rotateX(-Math.PI / 2), new T.MeshLambertMaterial({ color: '#3b5330' })); sk.position.set(0, -4, -40); W.scene.add(sk);
}

// ---------------------------------------------------------------- colliders
// box: world = c + (lx*cos + lz*sin, -lx*sin + lz*cos)
function addBox(x, z, hx, hz, y0, y1, yaw = 0, o) { const c = Object.assign({ t: 0, x, z, hx, hz, y0, y1, c: Math.cos(yaw), s: Math.sin(yaw), on: true }, o); W.colliders.push(c); return c; }
function addCyl(x, z, r, y0, y1, o) { const c = Object.assign({ t: 1, x, z, r, y0, y1, on: true }, o); W.colliders.push(c); return c; }
// push a circle (x,z,r) spanning vertical range [f0,f1] out of all solid colliders; returns [x,z]
function resolveCircle(x, z, r, f0, f1, skip) {
  for (let it = 0; it < 2; it++) for (const c of W.colliders) {
    if (!c.on || c === skip || c.y1 <= f0 || c.y0 >= f1) continue;
    if (c.t === 1) { const dx = x - c.x, dz = z - c.z, d = Math.hypot(dx, dz), m = r + c.r; if (d < m) { if (d < 1e-5) { x += m; } else { x = c.x + dx / d * m; z = c.z + dz / d * m; } } continue; }
    const dx = x - c.x, dz = z - c.z; if (Math.abs(dx) + Math.abs(dz) > c.hx + c.hz + r + 1) continue;
    const lx = dx * c.c - dz * c.s, lz = dx * c.s + dz * c.c;
    const qx = clamp(lx, -c.hx, c.hx), qz = clamp(lz, -c.hz, c.hz); let ox = lx - qx, oz = lz - qz; const d2 = ox * ox + oz * oz;
    if (d2 > r * r) continue;
    let nlx = lx, nlz = lz;
    if (d2 < 1e-9) { const px = c.hx - Math.abs(lx), pz = c.hz - Math.abs(lz); if (px < pz) nlx = (lx < 0 ? -1 : 1) * (c.hx + r); else nlz = (lz < 0 ? -1 : 1) * (c.hz + r); }
    else { const d = Math.sqrt(d2); nlx = qx + ox / d * r; nlz = qz + oz / d * r; }
    x = c.x + nlx * c.c + nlz * c.s; z = c.z - nlx * c.s + nlz * c.c;
  }
  return [x, z];
}
// highest walkable surface under (x,z) reachable from feet height
function groundAt(x, z, feet, stepH) {
  let g = terrainH(x, z); const lim = feet + stepH + 1e-3;
  for (const c of W.colliders) {
    if (!c.on || c.y1 > lim || c.y1 <= g) continue;
    if (c.t === 1) { if (c.walk && Math.hypot(x - c.x, z - c.z) < c.r + .05) g = c.y1; continue; }
    const dx = x - c.x, dz = z - c.z; if (Math.abs(dx) + Math.abs(dz) > c.hx + c.hz + 1) continue;
    const lx = dx * c.c - dz * c.s, lz = dx * c.s + dz * c.c;
    if (Math.abs(lx) <= c.hx + .08 && Math.abs(lz) <= c.hz + .08) g = c.y1;
  }
  return g;
}

// ---------------------------------------------------------------- materials
const GLSL_NOISE = `
float hash21(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
float vn2(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash21(i),hash21(i+vec2(1.,0.)),f.x),mix(hash21(i+vec2(0.,1.)),hash21(i+vec2(1.,1.)),f.x),f.y);}
float fbm2(vec2 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*vn2(p);p=p*2.03+7.1;a*=.5;}return s;}
`;
const WIND = {
  grass: `float ww_=transformed.y; vec2 ph_=vec2(0.);
#ifdef USE_INSTANCING
 ph_=instanceMatrix[3].xz*0.35;
 transformed*=1.0-smoothstep(uVegFar*0.7,uVegFar,distance(instanceMatrix[3].xyz,cameraPosition));
#endif
 transformed.x+=ww_*ww_*(sin(uTime*1.6+ph_.x+ph_.y)*0.34+sin(uTime*3.1+ph_.x*2.3)*0.1);
 transformed.z+=ww_*ww_*cos(uTime*1.3+ph_.y*1.7)*0.25;`,
  tree: `float ww_=max(transformed.y-1.5,0.0)*0.012; vec2 ph_=transformed.xz*0.3;
#ifdef USE_INSTANCING
 ph_+=instanceMatrix[3].xz*0.2;
#endif
 transformed.x+=ww_*sin(uTime*1.1+ph_.x); transformed.z+=ww_*cos(uTime*0.9+ph_.y);
 transformed.y+=ww_*0.5*sin(uTime*2.3+ph_.x*3.0+transformed.y);`,
  ivy: `vec2 ph_=transformed.xy*1.3;
#ifdef USE_INSTANCING
 ph_+=instanceMatrix[3].xz;
#endif
 transformed.z+=0.035*sin(uTime*1.7+ph_.x*2.0+ph_.y)*(-transformed.y);`,
};
const FRAG = {
  stone: `float n_=fbm2(vWPos.xz*0.42+vWPos.y*0.31); float n2_=fbm2(vWPos.xz*2.3+vWPos.yy*1.7);
 diffuseColor.rgb*=0.86+0.28*n2_;
 float up_=smoothstep(0.15,0.85,vWNrm.y);
 float m_=clamp((up_*0.95+0.16)*smoothstep(0.5,0.66,n_*0.72+n2_*0.28+uMoss*0.14-0.04),0.,1.)*clamp(uMoss,0.,1.);
 diffuseColor.rgb=mix(diffuseColor.rgb,vec3(0.13,0.2,0.06)*(0.6+0.9*n2_),m_);`,
  foliage: `float n_=vn2(vWPos.xz*3.1+vWPos.y*2.3); float n2_=vn2(vWPos.xy*9.1+vWPos.z*7.3);
 diffuseColor.rgb*=0.84+0.3*n_+0.12*n2_; totalEmissiveRadiance+=diffuseColor.rgb*0.24;`,
  grass: `totalEmissiveRadiance+=diffuseColor.rgb*0.16;`,
  terrain: `diffuseColor.rgb*=0.78+0.44*fbm2(vWPos.xz*1.9);`,
};
function patchStd(mat, key, o) {
  mat.onBeforeCompile = sh => {
    sh.uniforms.uTime = uTime; sh.uniforms.uVegFar = uVegFar; sh.uniforms.uMoss = { value: o.moss || 0 };
    sh.vertexShader = sh.vertexShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vWPos; varying vec3 vWNrm; uniform float uTime; uniform float uVegFar;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\n' + (o.wind ? WIND[o.wind] : ''))
      .replace('#include <project_vertex>', `#include <project_vertex>
 vec4 wp_=vec4(transformed,1.0); vec3 wn_=objectNormal;
#ifdef USE_INSTANCING
 wp_=instanceMatrix*wp_; wn_=mat3(instanceMatrix)*wn_;
#endif
 vWPos=(modelMatrix*wp_).xyz; vWNrm=normalize(mat3(modelMatrix)*wn_);`);
    sh.fragmentShader = sh.fragmentShader
      .replace('#include <common>', '#include <common>\nvarying vec3 vWPos; varying vec3 vWNrm; uniform float uMoss;\n' + GLSL_NOISE)
      .replace('#include <color_fragment>', '#include <color_fragment>\n' + (FRAG[o.frag] || ''))
      .replace('#include <normal_fragment_begin>', '#include <normal_fragment_begin>\n' + (o.noflip ? '#ifdef DOUBLE_SIDED\n normal*=faceDirection;\n#endif\n' : ''));
  };
  mat.customProgramCacheKey = () => key;
  return mat;
}
const MATS = {}, TEX = {};
function buildMaterials(texSize) {
  TEX.stone = makeStoneTex(texSize); TEX.bark = makeBarkTex(texSize / 2); TEX.ground = makeGroundTex(texSize / 2);
  TEX.glow = glowTex(); TEX.script = scriptTex(); TEX.leaf = leafTex(texSize);
  for (const k of Object.keys(GLYPHS)) TEX['g_' + k] = glyphTex(k);
  const st = (key, moss, rough) => patchStd(new T.MeshStandardMaterial({ map: TEX.stone.map, normalMap: TEX.stone.normalMap, normalScale: new T.Vector2(.6, .6), vertexColors: true, roughness: rough, metalness: 0 }), key, { moss, frag: 'stone' });
  MATS.stone = st('stoneA', 1.0, .93); MATS.stoneT = st('stoneB', .3, .6); MATS.stoneS = st('stoneC', .12, .9);
  MATS.terrain = patchStd(new T.MeshStandardMaterial({ map: TEX.ground.map, normalMap: TEX.ground.normalMap, normalScale: new T.Vector2(.3, .3), vertexColors: true, roughness: 1 }), 'terrain', { frag: 'terrain' });
  MATS.bark = patchStd(new T.MeshStandardMaterial({ map: TEX.bark.map, normalMap: TEX.bark.normalMap, vertexColors: true, roughness: .95 }), 'bark', { moss: .7, frag: 'stone', wind: 'tree' });
  MATS.leaf = patchStd(new T.MeshLambertMaterial({ vertexColors: true, map: TEX.leaf, alphaTest: .42, side: T.DoubleSide }), 'leaf', { frag: 'foliage', wind: 'tree', noflip: true });
  MATS.grass = patchStd(new T.MeshLambertMaterial({ vertexColors: true, side: T.DoubleSide }), 'grass', { wind: 'grass', frag: 'grass', noflip: true });
  MATS.ivy = patchStd(new T.MeshLambertMaterial({ vertexColors: true, side: T.DoubleSide }), 'ivy', { wind: 'ivy', frag: 'grass', noflip: true });
  MATS.glowInst = new T.MeshBasicMaterial({ vertexColors: true });          // unlit HDR (mushrooms, bulbs)
  MATS.metal = new T.MeshStandardMaterial({ color: '#c9a04c', roughness: .42, metalness: .75, emissive: '#3a2608', emissiveIntensity: .6 });
  MATS.lily = new T.MeshLambertMaterial({ vertexColors: true });
  MATS.dark = new T.MeshStandardMaterial({ color: '#16181a', roughness: .8 });
}
const TINT = { court: '#a4a696', forest: '#959a8a', temple: '#6f8f8b', sanct: '#97a3ba' };
const MATFOR = { court: 'stone', forest: 'stone', temple: 'stoneT', sanct: 'stoneS' };

// ---------------------------------------------------------------- static batching & instancing
function S(region, mat, g) { const k = region + ':' + mat; (W.batch[k] || (W.batch[k] = [])).push(g); }
function finalizeBatches() {
  for (const k of Object.keys(W.batch)) {
    const mat = k.split(':')[1], g = mergeGeoms(W.batch[k]); g.computeBoundingSphere();
    const m = new T.Mesh(g, MATS[mat]); m.castShadow = m.receiveShadow = true; m.matrixAutoUpdate = false; W.scene.add(m);
  }
  W.batch = {};
}
function I(kind, x, y, z, yaw = 0, s = 1, color = null, sy = null) { (W.inst[kind] || (W.inst[kind] = [])).push({ x, y, z, yaw, s, sy: sy == null ? s : sy, color }); }
const uVegFar = { value: 62 };
const VEG = { cell: 24, chunks: [], far: { grass: 0, fern: 0, flower: 0, bush: 150, ivy: 120, mush: 120, bulb: 120 } };   // 0 = follows uVegFar
// Instances are grouped into spatial cells so that the renderer (and the shadow pass) can frustum-cull them, and so
// distant cells can be skipped or swapped to a low-detail mesh. defs: kind -> {geom, mat, cast, recv, colored, lod}
function finalizeInstances(defs) {
  const d = new T.Object3D(), cc = new T.Color(); W.instMeshes = {};
  for (const k of Object.keys(defs)) {
    const list = W.inst[k] || [], def = defs[k]; if (!list.length) continue;
    def.geom.computeBoundingSphere(); const gr = def.geom.boundingSphere.radius + def.geom.boundingSphere.center.length();
    const cs = k.startsWith('tree') || k === 'bush' ? 40 : VEG.cell, cells = new Map(); for (const e of list) { const key = Math.floor(e.x / cs) + ',' + Math.floor(e.z / cs); (cells.get(key) || cells.set(key, []).get(key)).push(e); }
    const agg = W.instMeshes[k] = { count: list.length, chunks: [] };
    for (const part of cells.values()) {
      const build = geom => { const m = new T.InstancedMesh(geom, def.mat, part.length);
        part.forEach((e, i) => { d.position.set(e.x, e.y, e.z); d.rotation.set(0, e.yaw, 0); d.scale.set(e.s, e.sy, e.s); d.updateMatrix(); m.setMatrixAt(i, d.matrix); if (def.colored) m.setColorAt(i, e.color ? cc.set(e.color) : cc.setRGB(1, 1, 1)); });
        m.castShadow = !!def.cast; m.receiveShadow = def.recv !== false; m.userData.full = part.length; m.matrixAutoUpdate = false; W.scene.add(m); return m; };
      let cx = 0, cy = 0, cz = 0; for (const e of part) { cx += e.x; cy += e.y; cz += e.z; } cx /= part.length; cy /= part.length; cz /= part.length;
      let rad = 0; for (const e of part) rad = Math.max(rad, Math.hypot(e.x - cx, e.y - cy, e.z - cz) + gr * Math.max(e.s, e.sy));
      const bs = new T.Sphere(new V3(cx, cy, cz), rad), hi = build(def.geom), lo = def.lod ? build(def.lod) : null;
      hi.boundingSphere = bs; hi.frustumCulled = true; if (lo) { lo.boundingSphere = bs; lo.frustumCulled = true; lo.visible = false; }
      const ch = { kind: k, hi, lo, c: bs.center, r: rad, tree: k.startsWith('tree') }; VEG.chunks.push(ch); agg.chunks.push(ch);
    }
  }
  W.updaters.push(updateVegetation);
}
// distance culling + level of detail, re-evaluated a few cells per frame is unnecessary: the list is short
function updateVegetation() {
  const cam = R.camera.position, lodD = R.preset.lod, vf = uVegFar.value;
  for (const ch of VEG.chunks) {
    const dist = Math.hypot(ch.c.x - cam.x, ch.c.y - cam.y, ch.c.z - cam.z) - ch.r;
    if (ch.tree) { const far = dist > lodD; ch.hi.visible = !far || !ch.lo; if (ch.lo) ch.lo.visible = far; }
    else { const f = VEG.far[ch.kind] || vf * 1.02; ch.hi.visible = dist < f; }
  }
}

// ---------------------------------------------------------------- tweens / misc runtime helpers
function tween(dur, fn, done) { W.tweens.push({ t: 0, dur, fn, done }); }
function updateTweens(dt) {
  for (let i = W.tweens.length - 1; i >= 0; i--) { const w = W.tweens[i]; w.t += dt; const k = Math.min(1, w.t / w.dur); w.fn(k * k * (3 - 2 * k), k); if (k >= 1) { W.tweens.splice(i, 1); if (w.done) w.done(); } }
}
let LOGHOOK = null;
function addInter(o) { if (o.on === undefined) o.on = true; if (!o.reach) o.reach = 3.0; const idx = W.inter.length, u = o.use; o.use = function () { if (LOGHOOK) LOGHOOK(idx, o); return u.apply(o, arguments); }; W.inter.push(o); return o; }
function glow(x, y, z, hex, power = 1, range = 9) { const g = { pos: new V3(x, y, z), color: new T.Color(hex), power, range, on: true }; W.glows.push(g); return g; }
