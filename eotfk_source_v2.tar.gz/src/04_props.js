// ============================================================================
// Prop factories: masonry, columns, arches, statues, trees, plants, crystals,
// tablets, pickups, spirits, doors, levers
// ============================================================================
function stoneG(reg, g, y0, o = {}) {   // colour + UV a world-space stone geometry and queue it for batching
  const tint = col(o.tint || TINT[reg]), v = (o.v || 1) * (.84 + .26 * RND()), hgt = o.aoH || 1.6;
  paint(g, (x, y) => { const ao = lerp(.72, 1, sstep(y0 - .1, y0 + hgt, y)); return [tint[0] * v * ao, tint[1] * v * ao, tint[2] * v * ao]; });
  boxUV(g); S(reg, o.mat || MATFOR[reg], g);
}
function stone(reg, x, y, z, sx, sy, sz, o = {}) {
  const g = blockGeom(sx, sy, sz, o.chip == null ? .08 : o.chip, SEEDC++);
  if (o.rz) g.rotateZ(o.rz); if (o.rx) g.rotateX(o.rx); if (o.yaw) g.rotateY(o.yaw);
  g.translate(x, y + sy / 2, z); stoneG(reg, g, y, o);
  return o.col === false ? null : addBox(x, z, sx / 2, sz / 2, y, y + sy, o.yaw || 0);
}
function cyl(reg, x, y, z, r0, r1, h, o = {}) {
  const g = new T.CylinderGeometry(r1, r0, h, o.seg || 14, 1), p = g.attributes.position, so = SEEDC++ * 3.7;
  for (let i = 0; i < p.count; i++) { const px = p.getX(i), pz = p.getZ(i), k = 1 + (vnoise(px * 3 + so, pz * 3 + p.getY(i) * 2) - .5) * (o.chip == null ? .08 : o.chip); p.setX(i, px * k); p.setZ(i, pz * k); }
  g.computeVertexNormals(); if (o.rz) g.rotateZ(o.rz); if (o.yaw) g.rotateY(o.yaw); g.translate(x, y + (o.rz ? 0 : h / 2), z); stoneG(reg, g, y, o);
}
function column(reg, x, y, z, r, h, o = {}) {
  const keep = o.broken == null ? 1 : o.broken, he = h * keep;
  stone(reg, x, y, z, r * 2.7, .35, r * 2.7, { col: false, tint: o.tint });
  let yy = y + .35; const n = Math.max(1, Math.round(he / 1.15)), dh = (he - .35) / n;
  for (let i = 0; i < n; i++) { const rr = r * (1 - .1 * i / Math.max(1, Math.round(h / 1.15))); cyl(reg, x + (RND() - .5) * .05, yy, z + (RND() - .5) * .05, rr, rr * .97, dh - .02, { tint: o.tint, yaw: RND() * 6 }); yy += dh; }
  if (keep >= 1) { cyl(reg, x, yy, z, r * .95, r * 1.35, .3, { tint: o.tint }); stone(reg, x, yy + .3, z, r * 2.9, .3, r * 2.9, { col: false, tint: o.tint }); }
  return addCyl(x, z, r * 1.2, y, y + he + (keep >= 1 ? .6 : 0));
}
function fallenDrum(reg, x, z, r, len, yaw, o = {}) {
  const y = (o.y == null ? terrainH(x, z) : o.y) + r * .8;
  cyl(reg, x, y, z, r, r * .96, len, { rz: Math.PI / 2, yaw, tint: o.tint });
  addBox(x, z, len / 2, r * .9, y - r, y + r * .8, yaw);
}
function arch(reg, x, y, z, w, h, d, yaw, o = {}) {
  const t = o.t || .95, c = Math.cos(yaw), s = Math.sin(yaw), R0 = w / 2 + t / 2, n = 9;
  const L = (lx, ly, lz) => [x + lx * c + lz * s, y + ly, z - lx * s + lz * c];
  for (const sd of [-1, 1]) { if (o.broken && sd === o.broken) { const p = L(sd * R0, 0, 0); stone(reg, p[0], y, p[2], t, h * .45, d, { yaw, tint: o.tint }); continue; } const p = L(sd * R0, 0, 0); stone(reg, p[0], y, p[2], t, h, d, { yaw, tint: o.tint }); stone(reg, p[0], y + h, p[2], t * 1.2, .28, d * 1.1, { yaw, col: false, tint: o.tint }); }
  const al = Math.PI * R0 / n * 1.04;
  for (let k = 0; k < n; k++) {
    const a = Math.PI * (k + .5) / n; if (o.broken && ((o.broken === 1 && k < 5) || (o.broken === -1 && k > 3))) continue;
    const g = blockGeom(al, t * (k === 4 ? 1.25 : 1), d * (k === 4 ? 1.08 : 1), .06, SEEDC++); g.rotateZ(a + Math.PI / 2); g.translate(Math.cos(a) * R0, h + .28 + Math.sin(a) * R0, 0); g.rotateY(yaw); g.translate(x, y, z); stoneG(reg, g, y + h, { tint: o.tint, aoH: .1 });
  }
  if (!o.broken) addBox(x, z, R0 + t / 2, d / 2, y + h, y + h + R0 + t, yaw);
}
function ruinWall(reg, x0, z0, x1, z1, hMax, o = {}) {
  const dx = x1 - x0, dz = z1 - z0, len = Math.hypot(dx, dz), yaw = Math.atan2(-dz, dx), ux = dx / len, uz = dz / len, th = o.th || 1.1;
  const yb = (o.y == null ? Math.min(terrainH(x0, z0), terrainH(x1, z1), terrainH((x0 + x1) / 2, (z0 + z1) / 2)) : o.y) - .35;
  let yy = yb, course = 0; const minH = o.minH || 2.7, so = SEEDC * 1.37;
  while (yy < yb + hMax) {
    const ch = .85 + RND() * .3; let a = course % 2 ? -RND() * .8 : 0;
    while (a < len - .2) {
      const bl = Math.min(1.5 + RND() * 1.3, len - a + .3), mid = a + bl / 2, colH = Math.max(minH, hMax * (.35 + .85 * vnoise(mid * .22 + so, so)));
      if (yy - yb < colH) stone(reg, x0 + ux * mid, yy, z0 + uz * mid, bl - .04, ch, th * (.92 + RND() * .14), { yaw, col: false, tint: o.tint, aoH: yy === yb ? 1.4 : .01 });
      a += bl;
    }
    yy += ch; course++;
  }
  addBox((x0 + x1) / 2, (z0 + z1) / 2, len / 2, th / 2, yb - 2, yb + minH + .2, yaw);
}
function rock(reg, x, z, s, o = {}) {
  const y = o.y == null ? terrainH(x, z) : o.y, g = blobGeom(s, 1, SEEDC++, o.sq || .7, .32, true); g.rotateY(RND() * 6); g.translate(x, y + s * (o.lift == null ? .25 : o.lift), z);
  stoneG(reg, g, y, { tint: o.tint, aoH: s }); if (s > .9 && o.col !== false) addCyl(x, z, s * .8, y - 1, y + s * .9);
}
function rubble(reg, x, z, n, spread, o = {}) {
  for (let i = 0; i < n; i++) { const a = RND() * TAU, d = RND() * spread, px = x + Math.cos(a) * d, pz = z + Math.sin(a) * d, s = .25 + RND() * .45; stone(reg, px, (o.y == null ? terrainH(px, pz) : o.y) - s * .25, pz, s * (1 + RND()), s, s * (1 + RND() * .6), { yaw: RND() * 6, rz: (RND() - .5) * .5, col: false, chip: .12, tint: o.tint }); }
}
function statue(reg, x, z, yaw, o = {}) {
  const y = o.y == null ? terrainH(x, z) - .15 : o.y, s = o.s || 1;
  stone(reg, x, y, z, 1.5 * s, .7 * s, 1.5 * s, { yaw, col: false });
  const pts = [[.56, 0], [.6, .12], [.44, .55], [.34, 1.3], [.43, 1.78], [.3, 1.98], [.2, 2.04], [.27, 2.22], [.29, 2.42], [.2, 2.6], [0, 2.68]].map(p => new T.Vector2(p[0] * s, p[1] * s));
  const g = new T.LatheGeometry(pts, 9).toNonIndexed(); g.computeVertexNormals(); g.scale(1, 1, .78); g.rotateY(yaw); g.translate(x, y + .7 * s, z); stoneG(reg, g, y, { aoH: 3 });
  const f = blockGeom(.2 * s, .5 * s, .06 * s, .01, SEEDC++); f.translate(0, 2.33 * s, .25 * s); f.rotateY(yaw); f.translate(x, y + .7 * s, z); stoneG(reg, f, y, { v: .45 });   // shadowed face slit
  addCyl(x, z, .75 * s, y, y + 3.3 * s);
}
function dynStone(g, reg) { const t = col(TINT[reg]); paint(g, () => t); boxUV(g); return g; }

// ---------------------------------------------------------------- trees and plants
function treeGeoms(seed, o, lod = 0) {   // lod 1: same silhouette from the same random sequence, far fewer triangles
  const r = rng(seed), h = o.h, rad = o.r, wood = [], leaves = [], ph = r() * TAU, lean = (r() - .5) * .22, nT = 8, tp = [];
  for (let i = 0; i <= nT; i++) { const t = i / nT; tp.push(new V3(Math.sin(t * 2.4 + ph) * rad * 1.3 * t + lean * h * t * t, -.7 + t * (h * .62 + .7), Math.cos(t * 1.8 + ph) * rad * 1.3 * t)); }
  wood.push(tubeGeom(lod ? tp.filter((_, i) => i % 2 === 0) : tp, t => rad * (1 - .6 * t) + rad * .95 * Math.pow(1 - t, 7), lod ? 5 : 8, .35));
  const nR = o.roots || 5;
  for (let k = 0; k < nR; k++) {
    const a = k / nR * TAU + r() * .7, L = rad * (o.rootLen || 4) * (.7 + .6 * r()), bend = (r() - .5) * 1.4, pts = [];
    for (let i = 0; i <= 6; i++) { const t = i / 6, aa = a + bend * t * t, d = rad * .25 + L * t; pts.push(new V3(Math.cos(aa) * d, rad * 2.1 * Math.pow(1 - t, 2.2) - .32 * t + Math.sin(t * 9 + k) * .05 * rad, Math.sin(aa) * d)); }
    if (!lod) wood.push(tubeGeom(pts, t => rad * (.52 - .44 * t), 5, .35));
  }
  const pal = o.pal.map(col), crown = o.crown;
  const cores = [];
  const leaf = (c, rr) => {
    const pc = pal[Math.floor(r() * pal.length)], v = .8 + r() * .4, tint = [pc[0] * v, pc[1] * v, pc[2] * v], rc = rng(seed * 3 + leaves.length * 7 + 1);
    leaves.push(leafCards(c.x, c.y, c.z, rr * 1.04, lod ? Math.max(7, Math.round(rr * 3.6)) : Math.max(12, Math.round(rr * 7.5)), rc, tint, .8, lod ? 1.45 : 1.12));
    // dark inner mass so the crown is never see-through (rendered with the trunk)
    const g = blobGeom(rr * .66, lod ? 0 : 1, seed * 3 + leaves.length * 7, .78, .2); g.translate(c.x, c.y - rr * .05, c.z); paint(g, (x, y, z, nx, ny) => { const k = .2 + .16 * Math.max(0, ny); return [pc[0] * k, pc[1] * k * 1.05, pc[2] * k]; }); cores.push(g);
  };
  const top = tp[nT], nB = o.branches || 4;
  for (let k = 0; k < nB; k++) {
    const a = k / nB * TAU + r() * .9, base = tp[Math.min(nT, Math.round((.5 + .45 * r()) * nT))], len = crown * (.75 + .5 * r());
    const end = new V3(base.x + Math.cos(a) * len, base.y + len * (.3 + .45 * r()), base.z + Math.sin(a) * len), mid = base.clone().lerp(end, .5); mid.y += len * .14;
    wood.push(tubeGeom([base, mid, end], t => rad * (.36 - .28 * t), lod ? 3 : 5, .35)); leaf(end, crown * (.5 + .3 * r()));
  }
  leaf(new V3(top.x, top.y + crown * .25, top.z), crown * .78);
  for (let k = 0; k < (o.fill || 3); k++) { const a = r() * TAU; leaf(new V3(top.x + Math.cos(a) * crown * .6, top.y - crown * .1 + r() * crown * .5, top.z + Math.sin(a) * crown * .6), crown * (.45 + .25 * r())); }
  const w = mergeGeoms(wood); const bc = col('#8a745c'); paint(w, (x, y) => { const k = .55 + .45 * sstep(0, 2.5, y); return [bc[0] * k, bc[1] * k, bc[2] * k]; });
  return { wood: mergeGeoms([w].concat(cores)), leaves: mergeGeoms(leaves) };
}
function grassClumpGeom(seed, blades = 10, hgt = .36, spread = .3) {
  const r = rng(seed), P = [], N = [], C = [], c0 = col('#2c5218'), c1 = col('#9cc446');
  for (let b = 0; b < blades; b++) {
    const bx = (r() - .5) * 2 * spread, bz = (r() - .5) * 2 * spread, a = r() * TAU, h = hgt * (.55 + .9 * r()), w = .014 + .012 * r(), lx = Math.cos(a) * h * .35 * r(), lz = Math.sin(a) * h * .35 * r();
    const px = -Math.sin(a) * w, pz = Math.cos(a) * w;
    const v = [[bx - px, 0, bz - pz], [bx + px, 0, bz + pz], [bx - px * .6 + lx * .4, h * .55, bz - pz * .6 + lz * .4], [bx + px * .6 + lx * .4, h * .55, bz + pz * .6 + lz * .4], [bx + lx, h, bz + lz]];
    for (const i of [0, 1, 3, 0, 3, 2, 2, 3, 4]) { P.push(...v[i]); N.push(Math.cos(a) * .25, 1, Math.sin(a) * .25); const t = v[i][1] / h; C.push(lerp(c0[0], c1[0], t), lerp(c0[1], c1[1], t), lerp(c0[2], c1[2], t)); }
  }
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(P, 3)); g.setAttribute('normal', new T.Float32BufferAttribute(N, 3)); g.setAttribute('color', new T.Float32BufferAttribute(C, 3)); return g;
}
function fernGeom(seed) {
  const r = rng(seed), P = [], N = [], C = [], c0 = col('#16381a'), c1 = col('#4f9a3a');
  for (let f = 0; f < 9; f++) {
    const a = f / 9 * TAU + r() * .4, L = .7 + r() * .5, ca = Math.cos(a), sa = Math.sin(a), seg = 5; let prev = null;
    for (let i = 0; i <= seg; i++) {
      const t = i / seg, d = L * t, y = Math.sin(t * 2.2) * L * .55 * (1 - t * .25), w = .16 * Math.sin(Math.PI * Math.min(1, t * 1.1 + .08)) + .01;
      const cur = [[ca * d - sa * w, y, sa * d + ca * w], [ca * d + sa * w, y, sa * d - ca * w], t];
      if (prev) for (const q of [[prev[0], prev[2]], [prev[1], prev[2]], [cur[1], t], [prev[0], prev[2]], [cur[1], t], [cur[0], t]]) { P.push(...q[0]); N.push(ca * .2, 1, sa * .2); C.push(lerp(c0[0], c1[0], q[1]), lerp(c0[1], c1[1], q[1]), lerp(c0[2], c1[2], q[1])); }
      prev = cur;
    }
  }
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(P, 3)); g.setAttribute('normal', new T.Float32BufferAttribute(N, 3)); g.setAttribute('color', new T.Float32BufferAttribute(C, 3)); return g;
}
function flowerGeom(seed) {
  const r = rng(seed), gs = [];
  for (let i = 0; i < 6; i++) { const x = (r() - .5) * .5, z = (r() - .5) * .5, h = .22 + r() * .3; const st = new T.CylinderGeometry(.008, .012, h, 3).translate(x, h / 2, z); paint(st, () => [.1, .28, .08]); const hd = new T.OctahedronGeometry(.026 + r() * .016).scale(1, .6, 1).translate(x, h, z); paint(hd, () => [1.5, 1.5, 1.5]); gs.push(st, hd); }
  return mergeGeoms(gs);
}
function bushGeom(seed) {
  const r = rng(seed), gs = [], pal = ['#2f6a2a', '#3f7f2e', '#28583a'].map(col);
  for (let i = 0; i < 4; i++) { const rr = .5 + r() * .35, pc = pal[i % 3]; gs.push(leafCards((r() - .5) * .9, .4 + r() * .3, (r() - .5) * .9, rr, 11, r, pc, .78, 1.15)); }
  const core = blobGeom(.62, 0, seed, .6, .2); core.translate(0, .38, 0); core.deleteAttribute('uv'); core.setAttribute('uv', new T.BufferAttribute(new Float32Array(core.attributes.position.count * 2).fill(.25), 2)); paint(core, () => [.03, .07, .03]); gs.push(core);
  return mergeGeoms(gs);
}
function ivyGeom(seed) {   // hanging curtain of leaves; local +z faces outwards, y from 0 downwards
  const r = rng(seed), P = [], N = [], C = [], pal = ['#2d6a22', '#3f8a2c', '#1f4f24', '#5a9a34'].map(col);
  for (let i = 0; i < 120; i++) {
    const strand = Math.floor(r() * 9), sx = -1 + strand / 8 * 2 + (r() - .5) * .22, dep = Math.pow(r(), 1.6) * (1.4 + (strand * 7 % 5) * .28);
    const x = sx + Math.sin(dep * 3 + strand) * .08, y = -dep, z = .05 + r() * .14, s = .1 + r() * .1, tilt = (r() - .5) * 1.2, pc = pal[Math.floor(r() * 4)], v = .7 + r() * .6;
    const ct = Math.cos(tilt), stt = Math.sin(tilt), q = (lx, ly, lz) => [x + lx * ct - ly * stt, y + lx * stt + ly * ct, z + lz];
    const v0 = q(0, s * .9, 0), v1 = q(-s * .75, 0, .05), v2 = q(s * .75, 0, .05), v3 = q(0, -s * 1.3, .1);
    for (const p of [v0, v1, v2, v1, v3, v2]) { P.push(...p); N.push(0, .35, 1); C.push(pc[0] * v, pc[1] * v, pc[2] * v); }
  }
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(P, 3)); g.setAttribute('normal', new T.Float32BufferAttribute(N, 3)); g.setAttribute('color', new T.Float32BufferAttribute(C, 3)); return g;
}
function mushroomGeom(seed) {
  const r = rng(seed), gs = [];
  for (let i = 0; i < 4; i++) { const x = (r() - .5) * .5, z = (r() - .5) * .5, h = .12 + r() * .28, cr = .07 + r() * .1; const st = new T.CylinderGeometry(cr * .25, cr * .32, h, 5).translate(x, h / 2, z); paint(st, () => [.16, .16, .16]); const cap = new T.SphereGeometry(cr, 8, 4, 0, TAU, 0, Math.PI / 2).scale(1, .75, 1).translate(x, h, z); paint(cap, (px, py) => { const k = .55 + 1.2 * (py - h) / (cr * .75); return [k, k, k]; }); gs.push(st, cap); }
  return mergeGeoms(gs);
}
function bulbGeom(seed) {
  const r = rng(seed), gs = [];
  for (let i = 0; i < 3; i++) { const a = r() * TAU, h = .45 + r() * .5, lx = Math.cos(a) * .25, lz = Math.sin(a) * .25; const st = tubeGeom([new V3(0, 0, 0), new V3(lx * .4, h * .6, lz * .4), new V3(lx, h, lz), new V3(lx * 1.25, h * .9, lz * 1.25)], t => .014 - .006 * t, 4); paint(st, () => [.03, .09, .05]); const b = new T.SphereGeometry(.032 + r() * .018, 7, 5).scale(1, 1.5, 1).translate(lx * 1.25, h * .86, lz * 1.25); paint(b, () => [1.2, 1.2, 1.2]); gs.push(st, b); }
  return mergeGeoms(gs);
}

// ---------------------------------------------------------------- crystals & glowing things
const _cm = {};
function crystalMat(hex, ei) { const k = hex + ei; return _cm[k] || (_cm[k] = new T.MeshStandardMaterial({ color: hex, emissive: hex, emissiveIntensity: ei, roughness: .22, flatShading: true })); }
function crystal(x, y, z, s, hex, o = {}) {
  const mat = o.own ? new T.MeshStandardMaterial({ color: hex, emissive: hex, emissiveIntensity: o.ei || 2, roughness: .22, flatShading: true }) : crystalMat(hex, o.ei || 2);
  const m = new T.Mesh(crystalGeom(.26 * s, 1.5 * s), mat); m.position.set(x, y, z); m.rotation.set((o.tilt == null ? (RND() - .5) * .5 : o.tilt), RND() * 6, (o.tilt == null ? (RND() - .5) * .5 : 0)); W.scene.add(m);
  const halo = o.halo === false ? null : makeHalo(hex, s * 3.2, .55); if (halo) m.add(halo);
  const gl = o.light === false ? null : glow(x, y, z, hex, o.power || .8, o.range || 9);
  if (o.float) { const ph = RND() * 6, amp = o.float; W.updaters.push((dt, t) => { m.position.y = y + Math.sin(t * .7 + ph) * amp; m.rotation.y += dt * .35; if (gl) gl.pos.y = m.position.y; }); }
  return { mesh: m, mat, gl, halo };
}
function crystalCluster(x, y, z, hex, n = 3, s = 1, o = {}) {
  for (let i = 0; i < n; i++) { const a = RND() * TAU, d = i ? .18 * s + RND() * .3 * s : 0, sc = s * (i ? .4 + RND() * .45 : 1); const c = crystal(x + Math.cos(a) * d, y + sc * .45, z + Math.sin(a) * d, sc, hex, { light: i === 0 && o.light !== false, halo: i === 0, power: o.power, range: o.range, ei: o.ei }); c.mesh.rotation.x = Math.cos(a) * .45 * (i ? 1 : .2); c.mesh.rotation.z = -Math.sin(a) * .45 * (i ? 1 : .2); }
}
function glyphPlane(tex, size, hex, bright = 1.6) {
  const m = new T.Mesh(new T.PlaneGeometry(size, size), new T.MeshBasicMaterial({ map: TEX[tex], color: new T.Color(hex).multiplyScalar(bright), transparent: true, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide }));
  m.userData.base = new T.Color(hex); return m;
}
function setGlyph(m, hex, bright) { m.material.color.set(hex).multiplyScalar(bright); }

// ---------------------------------------------------------------- interactive props
function tablet(reg, x, z, yaw, noteId, o = {}) {
  const y = o.y == null ? terrainH(x, z) : o.y, s = Math.sin(yaw), c = Math.cos(yaw), note = NOTES[noteId];
  stone(reg, x, y - .25, z, 1.55, 2.2, .36, { yaw, chip: .11 }); stone(reg, x, y - .25, z, 1.95, .4, .7, { yaw, col: false });
  const gp = new T.Mesh(new T.PlaneGeometry(1.15, 1.55), new T.MeshBasicMaterial({ map: TEX.script, color: new T.Color(o.hex || '#8fe6ff').multiplyScalar(1.5), transparent: true, blending: T.AdditiveBlending, depthWrite: false }));
  gp.position.set(x + s * .2, y + 1.05, z + c * .2); gp.rotation.y = yaw; W.scene.add(gp);
  W.updaters.push((dt, t) => { gp.material.opacity = .65 + .35 * Math.sin(t * 1.3 + x); });
  return addInter({ pos: new V3(x + s * .35, y + 1.15, z + c * .35), label: 'Read — ' + note.title, use() { G.readNote(noteId); } });
}
function pickup(obj, x, y, z, label, hex, onTake, o = {}) {
  obj.position.set(x, y, z); W.scene.add(obj); const gl = glow(x, y, z, hex, .5, 6), ph = RND() * 6;
  const it = addInter({ pos: new V3(x, y, z), label, prio: .6, reach: o.reach || 3, on: o.on !== false, use() { it.on = false; it.taken = true; obj.visible = false; gl.on = false; burst(it.pos, hex, 46, 2.6, 1.3); onTake(); } });
  obj.visible = it.on; gl.on = it.on;
  W.updaters.push((dt, t) => { if (obj.visible) { obj.position.y = y + Math.sin(t * 1.4 + ph) * .07; obj.rotation.y += dt * .9; } });
  it.show = () => { it.on = true; obj.visible = true; gl.on = true; }; it.obj = obj; return it;
}
function relicMesh(hex) {
  const g = new T.Group(), m = new T.Mesh(new T.OctahedronGeometry(.26, 0).scale(.75, 1.5, .75), new T.MeshStandardMaterial({ color: hex, emissive: hex, emissiveIntensity: 3.2, roughness: .15, flatShading: true }));
  const sh = new T.Mesh(new T.OctahedronGeometry(.36, 0).scale(.75, 1.5, .75), new T.MeshBasicMaterial({ color: hex, wireframe: true, transparent: true, opacity: .35 })); sh.rotation.y = .6;
  g.add(m, sh, makeHalo(hex, 2.2, .7)); return g;
}
function keyMesh(hex) {
  const g = new T.Group(), mat = new T.MeshStandardMaterial({ color: hex, emissive: hex, emissiveIntensity: .7, roughness: .35, metalness: .8 });
  const bow = new T.Mesh(new T.TorusGeometry(.11, .03, 6, 14), mat); bow.position.y = .2;
  const sh = new T.Mesh(new T.CylinderGeometry(.025, .025, .4, 6), mat); sh.position.y = -.08;
  const t1 = new T.Mesh(new T.BoxGeometry(.11, .04, .03), mat); t1.position.set(.06, -.22, 0); const t2 = t1.clone(); t2.position.y = -.14;
  g.add(bow, sh, t1, t2, makeHalo(hex, 1.2, .5)); g.rotation.z = .5; return g;
}
function lensMesh() {
  const g = new T.Group(), ring = new T.Mesh(new T.TorusGeometry(.2, .035, 6, 20), new T.MeshStandardMaterial({ color: '#c9a14a', metalness: .9, roughness: .3 }));
  const gl = new T.Mesh(new T.CylinderGeometry(.19, .19, .03, 20).rotateX(Math.PI / 2), new T.MeshStandardMaterial({ color: '#bff', emissive: '#7fe9ff', emissiveIntensity: 1.6, transparent: true, opacity: .75, roughness: .05 }));
  g.add(ring, gl, makeHalo('#7fe9ff', 1.3, .5)); return g;
}
function sealMesh(hex) {
  const g = new T.Group(), d = new T.Mesh(new T.CylinderGeometry(.17, .17, .045, 16).rotateX(Math.PI / 2), new T.MeshStandardMaterial({ color: '#d9b25a', emissive: hex, emissiveIntensity: .9, metalness: .85, roughness: .3 }));
  const gp = glyphPlane('g_ring', .3, hex, 2); gp.position.z = .03; g.add(d, gp, makeHalo(hex, 1.1, .45)); return g;
}
function pedestal(reg, x, y, z, h = 1, r = .32) { cyl(reg, x, y, z, r * 1.35, r * 1.2, .16, { seg: 8 }); cyl(reg, x, y + .16, z, r, r * .9, h - .3, { seg: 8 }); cyl(reg, x, y + h - .14, z, r * 1.05, r * 1.3, .14, { seg: 8 }); addCyl(x, z, r * 1.3, y, y + h); }
function spirit(x, z, name, hex, linesFn, o = {}) {
  const y = o.y == null ? terrainH(x, z) : o.y, g = new T.Group(), mat = new T.MeshBasicMaterial({ color: new T.Color(hex).multiplyScalar(.9), transparent: true, opacity: .34, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide });
  const robe = new T.Mesh(new T.LatheGeometry([[.05, 0], [.5, .1], [.4, .6], [.27, 1.25], [.36, 1.52], [.16, 1.66]].map(p => new T.Vector2(p[0], p[1])), 14), mat);
  const head = new T.Mesh(new T.SphereGeometry(.17, 12, 8), mat); head.position.y = 1.82;
  const hood = new T.Mesh(new T.SphereGeometry(.24, 12, 8, 0, TAU, 0, 1.9), mat); hood.position.y = 1.84; hood.rotation.x = -.35;
  const halo = makeHalo(hex, 3.4, .5); halo.position.y = 1.2; g.add(robe, head, hood, halo); g.position.set(x, y + .25, z); W.scene.add(g);
  const gl = glow(x, y + 1.4, z, hex, .7, 8); let tb = 0;
  W.updaters.push((dt, t) => { g.position.y = y + .3 + Math.sin(t * .9 + x) * .1; g.rotation.y = Math.atan2(P.pos.x - x, P.pos.z - z); mat.opacity = .28 + .1 * Math.sin(t * 2.1 + z); tb += dt; if (tb > .35 && P.pos.distanceToSquared(g.position) < 900) { tb = 0; burst(new V3(x + (Math.random() - .5) * .6, y + .4 + Math.random() * 1.4, z + (Math.random() - .5) * .6), hex, 1, .15, 2.2, .35, .05); } });
  return addInter({ pos: new V3(x, y + 1.5, z), reach: 3.6, label: 'Speak with ' + name, use() { AU.sfx('spirit'); UI.dialog(name, linesFn()); G.flag('spoke_' + name); } });
}
function slabDoor(reg, x, y, z, sx, sy, sz, yaw, glyph, hex) {
  const m = new T.Mesh(dynStone(blockGeom(sx, sy, sz, .05, SEEDC++), reg), MATS[MATFOR[reg]]); m.position.set(x, y + sy / 2, z); m.rotation.y = yaw; m.castShadow = m.receiveShadow = true; W.scene.add(m);
  const col_ = addBox(x, z, sx / 2, sz / 2, y - 1, y + sy, yaw); let gp = null;
  if (glyph) for (const sd of [-1, 1]) { gp = glyphPlane(glyph, Math.min(sx, sy) * .5, hex || '#8fe6ff', 1.3); gp.position.set(0, .2, sd * (sz / 2 + .02)); m.add(gp); }
  const d = { mesh: m, col: col_, opened: false, open(dur = 3.4) { if (d.opened) return; d.opened = true; AU.sfx('stone', dur); tween(dur, k => { m.position.y = y + sy / 2 - k * (sy + .15); col_.y1 = y + sy * (1 - k); R.shake = .025 * Math.sin(k * Math.PI); }, () => { col_.on = false; R.shake = 0; }); } };
  return d;
}
function lever(reg, x, y, z, yaw, label, onPull) {
  stone(reg, x, y, z, .6, .5, .6, { yaw, col: false }); addCyl(x, z, .4, y, y + .6);
  const piv = new T.Group(); piv.position.set(x, y + .5, z); piv.rotation.y = yaw; W.scene.add(piv);
  const arm = new T.Mesh(new T.CylinderGeometry(.035, .045, .9, 6).translate(0, .45, 0), MATS.dark); const knob = new T.Mesh(new T.SphereGeometry(.09, 8, 6), crystalMat('#ffb347', 1.6)); knob.position.y = .92; piv.add(arm, knob); piv.rotation.x = -.7;
  const it = addInter({ pos: new V3(x, y + 1.1, z), label, use() { AU.sfx('lever'); const a = piv.rotation.x, b = -a; tween(.5, k => { piv.rotation.x = lerp(a, b, k); }); onPull(it); } });
  return it;
}
