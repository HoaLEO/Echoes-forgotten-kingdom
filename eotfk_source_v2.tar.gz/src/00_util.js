// ============================================================================
// Echoes of the Forgotten Kingdom — utilities, noise, procedural textures, geometry helpers
// ============================================================================
const T = THREE;
const V3 = T.Vector3;
const clamp = (x, a, b) => x < a ? a : x > b ? b : x;
const lerp = (a, b, t) => a + (b - a) * t;
const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const TAU = Math.PI * 2;

function rng(seed) {
  let s = seed >>> 0;
  return () => { s = s + 0x6D2B79F5 | 0; let t = Math.imul(s ^ s >>> 15, 1 | s); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
function hash2(x, y) {
  let h = Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
function vnoise(x, y) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  return lerp(lerp(hash2(xi, yi), hash2(xi + 1, yi), u), lerp(hash2(xi, yi + 1), hash2(xi + 1, yi + 1), u), v);
}
function fbm(x, y, o = 4) { let a = .5, f = 1, s = 0, n = 0; for (let i = 0; i < o; i++) { s += a * vnoise(x * f + i * 17.3, y * f - i * 9.1); n += a; a *= .5; f *= 2.03; } return s / n; }
// tiling noise for textures (period p in lattice cells)
function tileNoise(x, y, p) {
  const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const w = (a, b) => hash2(((a % p) + p) % p + p * 31, ((b % p) + p) % p + p * 7);
  return lerp(lerp(w(xi, yi), w(xi + 1, yi), u), lerp(w(xi, yi + 1), w(xi + 1, yi + 1), u), v);
}
function tileFbm(u, v, base, oct) { let a = .5, s = 0, n = 0, p = base; for (let i = 0; i < oct; i++) { s += a * tileNoise(u * p, v * p, p); n += a; a *= .5; p *= 2; } return s / n; }

const _c = new T.Color();
function col(hex) { _c.set(hex); return [_c.r, _c.g, _c.b]; }   // sRGB hex -> linear rgb triple

// ---------------------------------------------------------------- textures
function finishTex(canvas, srgb, rep) {
  const t = new T.CanvasTexture(canvas);
  t.wrapS = t.wrapT = rep === false ? T.ClampToEdgeWrapping : T.RepeatWrapping;
  if (srgb) t.colorSpace = T.SRGBColorSpace;
  t.anisotropy = 4;
  return t;
}
// Build albedo + normal map from a height function. hf(u,v)->0..1, cf(h,u,v)->[r,g,b] 0..255
function makeSurface(size, hf, cf, ns = 2) {
  const H = new Float32Array(size * size);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) H[y * size + x] = hf(x / size, y / size);
  const ca = document.createElement('canvas'), cn = document.createElement('canvas');
  ca.width = ca.height = cn.width = cn.height = size;
  const xa = ca.getContext('2d'), xn = cn.getContext('2d');
  const ia = xa.createImageData(size, size), inn = xn.createImageData(size, size);
  const k = ns * size / 16;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const i = y * size + x, h = H[i];
    const dx = H[y * size + (x + 1) % size] - H[y * size + (x + size - 1) % size];
    const dy = H[((y + 1) % size) * size + x] - H[((y + size - 1) % size) * size + x];
    let nx = -dx * k, ny = dy * k, nz = 1; const l = Math.hypot(nx, ny, nz); nx /= l; ny /= l; nz /= l;
    const c = cf(h, x / size, y / size);
    ia.data[i * 4] = c[0]; ia.data[i * 4 + 1] = c[1]; ia.data[i * 4 + 2] = c[2]; ia.data[i * 4 + 3] = 255;
    inn.data[i * 4] = (nx * .5 + .5) * 255; inn.data[i * 4 + 1] = (ny * .5 + .5) * 255; inn.data[i * 4 + 2] = (nz * .5 + .5) * 255; inn.data[i * 4 + 3] = 255;
  }
  xa.putImageData(ia, 0, 0); xn.putImageData(inn, 0, 0);
  return { map: finishTex(ca, true), normalMap: finishTex(cn, false) };
}
function makeStoneTex(size) {
  const r = rng(11);
  return makeSurface(size, (u, v) => {
    const a = tileFbm(u, v, 9, 5);
    const ridge = 1 - Math.abs(2 * tileFbm(u + .37, v + .11, 5, 4) - 1);
    const crack = Math.pow(ridge, 14);
    const pit = Math.max(0, tileNoise(u * 48, v * 48, 48) - .78) * 1.6;
    return clamp(a * .7 + .22 - crack * .45 - pit * .6, 0, 1);
  }, (h, u, v) => {
    const warm = tileFbm(u + .5, v + .2, 2, 3) - .5;
    const g = 204 + (h - .5) * 105 + (r() - .5) * 12;
    return [clamp(g + warm * 26, 0, 255), clamp(g + warm * 8, 0, 255), clamp(g - warm * 22, 0, 255)];
  }, 1.15);
}
function makeBarkTex(size) {
  const r = rng(23);
  return makeSurface(size, (u, v) => {
    let s = 0, a = .5, n = 0, pu = 12, pv = 2;
    for (let i = 0; i < 4; i++) { s += a * tileNoise(u * pu, v * pv, pu > pv ? pu * 8 : pv * 8); n += a; a *= .5; pu *= 2; pv *= 2; }
    s /= n; const ridge = 1 - Math.abs(2 * s - 1);
    return clamp(Math.pow(ridge, 1.6) * .9 + tileFbm(u, v, 8, 3) * .2, 0, 1);
  }, (h, u, v) => {
    const g = 105 + h * 125 + (r() - .5) * 12;
    return [clamp(g * 1.05, 0, 255), clamp(g * .86, 0, 255), clamp(g * .68, 0, 255)];
  }, 3);
}
function makeGroundTex(size) {
  const r = rng(5);
  return makeSurface(size, (u, v) => clamp(tileFbm(u, v, 6, 5) * .8 + tileNoise(u * 64, v * 64, 64) * .25, 0, 1),
    (h) => { const g = 208 + (h - .5) * 90 + (r() - .5) * 18; return [clamp(g, 0, 255), clamp(g, 0, 255), clamp(g * .97, 0, 255)]; }, 1.6);
}

// ---- glyphs (drawn in a unit box -0.5..0.5) ----
const GLYPHS = {
  sun(c) { c.beginPath(); c.arc(0, 0, .15, 0, TAU); c.stroke(); for (let i = 0; i < 8; i++) { const a = i / 8 * TAU; c.beginPath(); c.moveTo(Math.cos(a) * .22, Math.sin(a) * .22); c.lineTo(Math.cos(a) * (i % 2 ? .31 : .37), Math.sin(a) * (i % 2 ? .31 : .37)); c.stroke(); } },
  moon(c) { c.beginPath(); c.arc(0, 0, .3, .55, TAU - .55); c.stroke(); c.beginPath(); c.arc(.17, 0, .22, 2.25, TAU - 2.25, false); c.stroke(); },
  star(c) { c.beginPath(); for (let i = 0; i < 14; i++) { const a = i / 14 * TAU - Math.PI / 2, r = i % 2 ? .13 : .34; c[i ? 'lineTo' : 'moveTo'](Math.cos(a) * r, Math.sin(a) * r); } c.closePath(); c.stroke(); c.beginPath(); c.arc(0, 0, .035, 0, TAU); c.stroke(); },
  tree(c) { c.beginPath(); c.moveTo(0, .34); c.lineTo(0, -.1); c.stroke(); for (const s of [-1, 1]) { c.beginPath(); c.moveTo(0, .05); c.quadraticCurveTo(s * .2, 0, s * .26, -.2); c.stroke(); c.beginPath(); c.moveTo(0, -.1); c.quadraticCurveTo(s * .1, -.25, s * .12, -.36); c.stroke(); c.beginPath(); c.moveTo(0, .28); c.quadraticCurveTo(s * .12, .3, s * .22, .38); c.stroke(); } c.beginPath(); c.moveTo(0, -.1); c.lineTo(0, -.36); c.stroke(); },
  wave(c) { for (let j = -1; j <= 1; j++) { c.beginPath(); for (let i = 0; i <= 24; i++) { const x = -.34 + i / 24 * .68, y = j * .17 + Math.sin(i / 24 * TAU * 1.5) * .06; c[i ? 'lineTo' : 'moveTo'](x, y); } c.stroke(); } },
  eye(c) { c.beginPath(); c.moveTo(-.36, 0); c.quadraticCurveTo(0, -.3, .36, 0); c.quadraticCurveTo(0, .3, -.36, 0); c.stroke(); c.beginPath(); c.arc(0, 0, .1, 0, TAU); c.stroke(); },
  ring(c) { c.beginPath(); c.arc(0, 0, .36, 0, TAU); c.stroke(); c.beginPath(); c.arc(0, 0, .27, 0, TAU); c.stroke(); for (let i = 0; i < 12; i++) { const a = i / 12 * TAU; c.beginPath(); c.moveTo(Math.cos(a) * .27, Math.sin(a) * .27); c.lineTo(Math.cos(a) * .36, Math.sin(a) * .36); c.stroke(); } },
  gate(c) { c.beginPath(); c.moveTo(-.22, .36); c.lineTo(-.22, -.08); c.arc(0, -.08, .22, Math.PI, 0); c.lineTo(.22, .36); c.stroke(); c.beginPath(); c.moveTo(0, -.02); c.lineTo(.08, .12); c.lineTo(0, .26); c.lineTo(-.08, .12); c.closePath(); c.stroke(); },
};
function glyphTex(name, size = 256) {
  const c = document.createElement('canvas'); c.width = c.height = size; const x = c.getContext('2d');
  x.translate(size / 2, size / 2); x.scale(size, size);
  x.strokeStyle = '#fff'; x.lineCap = 'round'; x.lineJoin = 'round';
  x.shadowColor = '#fff'; x.shadowBlur = size * .07; x.lineWidth = .05; GLYPHS[name](x);
  x.shadowBlur = 0; x.lineWidth = .03; GLYPHS[name](x);
  return finishTex(c, true, false);
}
function scriptTex() {   // rows of carved runes for inscription tablets
  const c = document.createElement('canvas'); c.width = 256; c.height = 384; const x = c.getContext('2d'); const r = rng(99);
  x.strokeStyle = '#fff'; x.lineCap = 'round'; x.lineJoin = 'round';
  const rune = (ox, oy, w, h) => {   // a stem plus 1-3 branches / bowls on a 3x4 lattice: reads as an alphabet rather than noise
    const px = i => ox + i * w / 2, py = j => oy + j * h / 3; x.beginPath(); const stem = Math.floor(r() * 3); x.moveTo(px(stem), py(0)); x.lineTo(px(stem), py(3));
    const n = 1 + Math.floor(r() * 3); for (let k = 0; k < n; k++) { const j0 = Math.floor(r() * 4), i1 = (stem + 1 + Math.floor(r() * 2)) % 3, j1 = clamp(j0 + (r() < .5 ? -1 : 1), 0, 3); x.moveTo(px(stem), py(j0)); if (r() < .28) x.quadraticCurveTo(px(i1), py(j0), px(i1), py(j1)); else x.lineTo(px(i1), py(j1)); }
    x.stroke(); if (r() < .16) { x.beginPath(); x.arc(px(1), py(3) + 3, 1.2, 0, TAU); x.stroke(); }
  };
  for (const pass of [0, 1]) { const rr = rng(99); x.shadowColor = '#fff'; x.shadowBlur = pass ? 0 : 7; x.lineWidth = pass ? 2 : 2.6; x.globalAlpha = pass ? 1 : .55;
    for (let row = 0; row < 9; row++) { let cx = 30; const y = 34 + row * 36; while (cx < 222) { if (rr() < .16) { cx += 13; continue; } rune(cx, y, 10, 21); cx += 17.5; } } }
  x.globalAlpha = 1; x.shadowBlur = 0; x.lineWidth = 1.6; x.strokeRect(14, 14, 228, 356);
  return finishTex(c, true, false);
}
function leafTex(size = 512) {   // 2x2 atlas of leaf sprays (alpha cut-out); colour is near-white so vertex / instance colour tints it
  const c = document.createElement('canvas'); c.width = c.height = size; const x = c.getContext('2d'), r = rng(4711), h = size / 2;
  for (let q = 0; q < 4; q++) {
    const ox = (q % 2) * h, oy = (q >> 1) * h; x.save(); x.beginPath(); x.rect(ox + 2, oy + 2, h - 4, h - 4); x.clip(); x.translate(ox + h / 2, oy + h / 2);
    const leaves = []; for (let i = 0; i < 110; i++) { const a = r() * TAU, d = Math.pow(r(), .6) * h * .44; leaves.push([Math.cos(a) * d, Math.sin(a) * d, a + (r() - .5) * 1.6, h * (.055 + .04 * r()), r()]); }
    leaves.sort((p, q2) => p[4] - q2[4]);
    for (const [lx, ly, la, ls, v] of leaves) {
      x.save(); x.translate(lx, ly); x.rotate(la); const l = 150 + Math.floor(v * 105), g = x.createLinearGradient(-ls, 0, ls, 0);
      g.addColorStop(0, `rgb(${l * .72 | 0},${l * .8 | 0},${l * .62 | 0})`); g.addColorStop(1, `rgb(${l | 0},${l | 0},${l * .86 | 0})`); x.fillStyle = g;
      x.beginPath(); x.moveTo(-ls, 0); x.quadraticCurveTo(0, -ls * (q % 2 ? .62 : .46), ls * 1.15, 0); x.quadraticCurveTo(0, ls * (q % 2 ? .62 : .46), -ls, 0); x.fill();
      x.strokeStyle = 'rgba(40,60,30,.5)'; x.lineWidth = Math.max(1, size / 420); x.beginPath(); x.moveTo(-ls * .9, 0); x.lineTo(ls * 1.05, 0); x.stroke(); x.restore();
    }
    x.restore();
  }
  const t = new T.CanvasTexture(c); t.colorSpace = T.SRGBColorSpace; t.anisotropy = 4; t.wrapS = t.wrapT = T.ClampToEdgeWrapping; return t;
}
// foliage shell: n textured cards spread over a squashed sphere, shaded with the sphere's normals so the crown reads as one soft volume
function leafCards(cx, cy, cz, rr, n, r, pc, squash = .82, sizeK = 1) {
  const P = new Float32Array(n * 18), N = new Float32Array(n * 18), U = new Float32Array(n * 12), C = new Float32Array(n * 18), ga = 2.399963;
  for (let i = 0; i < n; i++) {
    const yy = 1 - (i + .5) / n * 1.82, rad = Math.sqrt(Math.max(0, 1 - yy * yy)), th = i * ga + r() * .9; let dx = Math.cos(th) * rad, dy = yy, dz = Math.sin(th) * rad;
    const dist = rr * (.62 + .42 * r()), px = cx + dx * dist, py = cy + dy * dist * squash, pz = cz + dz * dist, s = rr * (.5 + .34 * r()) * sizeK;
    // card plane: faces outwards with a random tilt
    let nx = dx + (r() - .5) * .9, ny = dy + (r() - .5) * .9 + .25, nz = dz + (r() - .5) * .9, l = Math.hypot(nx, ny, nz) || 1; nx /= l; ny /= l; nz /= l;
    let tx = ny * 0 - nz * 1, ty = 0, tz = nx * 1 - 0; if (Math.abs(ny) > .92) { tx = 1; ty = 0; tz = 0; } const ro = r() * TAU;
    let bx = ny * tz - nz * ty, by = nz * tx - nx * tz, bz = nx * ty - ny * tx; l = Math.hypot(tx, ty, tz) || 1; tx /= l; ty /= l; tz /= l; l = Math.hypot(bx, by, bz) || 1; bx /= l; by /= l; bz /= l;
    const co = Math.cos(ro), si = Math.sin(ro), ux = (tx * co + bx * si) * s, uy = (ty * co + by * si) * s, uz = (tz * co + bz * si) * s, vx = (bx * co - tx * si) * s, vy = (by * co - ty * si) * s, vz = (bz * co - tz * si) * s;
    const q = Math.floor(r() * 4), u0 = (q % 2) * .5, v0 = (q >> 1) * .5, corners = [[-1, -1], [1, -1], [1, 1], [-1, -1], [1, 1], [-1, 1]];
    let sx = dx, sy = dy + .32, sz = dz; l = Math.hypot(sx, sy, sz) || 1; sx /= l; sy /= l; sz /= l;
    const k = (.74 + .56 * Math.max(0, dy * .8 + .35)) * (.86 + .28 * r());
    for (let v = 0; v < 6; v++) { const o = i * 18 + v * 3, a = corners[v][0], b = corners[v][1];
      P[o] = px + ux * a + vx * b; P[o + 1] = py + uy * a + vy * b; P[o + 2] = pz + uz * a + vz * b; N[o] = sx; N[o + 1] = sy; N[o + 2] = sz;
      C[o] = pc[0] * k; C[o + 1] = pc[1] * k; C[o + 2] = pc[2] * k; U[i * 12 + v * 2] = u0 + (a * .5 + .5) * .5; U[i * 12 + v * 2 + 1] = v0 + (b * .5 + .5) * .5; }
  }
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(P, 3)); g.setAttribute('normal', new T.BufferAttribute(N, 3)); g.setAttribute('uv', new T.BufferAttribute(U, 2)); g.setAttribute('color', new T.BufferAttribute(C, 3)); return g;
}
function glowTex() {
  const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
  const g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(.18, 'rgba(255,255,255,.55)'); g.addColorStop(.45, 'rgba(255,255,255,.14)'); g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 128, 128); return finishTex(c, true, false);
}

// ---------------------------------------------------------------- geometry helpers
function ensureColor(g, r = 1, gg = 1, b = 1) {
  if (!g.attributes.color) { const n = g.attributes.position.count, a = new Float32Array(n * 3); for (let i = 0; i < n; i++) { a[i * 3] = r; a[i * 3 + 1] = gg; a[i * 3 + 2] = b; } g.setAttribute('color', new T.BufferAttribute(a, 3)); }
  return g;
}
function paint(g, fn) {   // fn(x,y,z,nx,ny,nz,i) -> [r,g,b]
  const p = g.attributes.position, nrm = g.attributes.normal, n = p.count, a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { const c = fn(p.getX(i), p.getY(i), p.getZ(i), nrm.getX(i), nrm.getY(i), nrm.getZ(i), i); a[i * 3] = c[0]; a[i * 3 + 1] = c[1]; a[i * 3 + 2] = c[2]; }
  g.setAttribute('color', new T.BufferAttribute(a, 3)); return g;
}
function mergeGeoms(list) {
  const gs = list.map(g => g.index ? g.toNonIndexed() : g); let n = 0; for (const g of gs) n += g.attributes.position.count;
  const P = new Float32Array(n * 3), N = new Float32Array(n * 3), U = new Float32Array(n * 2), C = new Float32Array(n * 3); let o = 0;
  for (const g of gs) {
    const c = g.attributes.position.count;
    P.set(g.attributes.position.array.subarray(0, c * 3), o * 3);
    if (g.attributes.normal) N.set(g.attributes.normal.array.subarray(0, c * 3), o * 3);
    if (g.attributes.uv) U.set(g.attributes.uv.array.subarray(0, c * 2), o * 2);
    if (g.attributes.color) C.set(g.attributes.color.array.subarray(0, c * 3), o * 3); else C.fill(1, o * 3, (o + c) * 3);
    o += c;
  }
  const out = new T.BufferGeometry();
  out.setAttribute('position', new T.BufferAttribute(P, 3)); out.setAttribute('normal', new T.BufferAttribute(N, 3));
  out.setAttribute('uv', new T.BufferAttribute(U, 2)); out.setAttribute('color', new T.BufferAttribute(C, 3));
  return out;
}
function boxUV(g, s = .22) {   // world-space box projection so texel density is constant everywhere
  const p = g.attributes.position, n = g.attributes.normal, uv = new Float32Array(p.count * 2);
  for (let i = 0; i < p.count; i++) {
    const ax = Math.abs(n.getX(i)), ay = Math.abs(n.getY(i)), az = Math.abs(n.getZ(i)); let u, v;
    if (ay >= ax && ay >= az) { u = p.getX(i); v = p.getZ(i); } else if (ax >= az) { u = p.getZ(i); v = p.getY(i); } else { u = p.getX(i); v = p.getY(i); }
    uv[i * 2] = u * s; uv[i * 2 + 1] = v * s;
  }
  g.setAttribute('uv', new T.BufferAttribute(uv, 2)); return g;
}
// weathered stone block: box with chipped edges
function blockGeom(sx, sy, sz, chip = .07, seed = 1) {
  const n = s => Math.max(1, Math.min(4, Math.round(s / 1.3)));
  const g = new T.BoxGeometry(sx, sy, sz, n(sx), n(sy), n(sz)), p = g.attributes.position;
  const hx = sx / 2, hy = sy / 2, hz = sz / 2, so = seed * 7.13;
  chip = Math.min(chip, Math.min(sx, sy, sz) * .22);
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const ex = Math.abs(Math.abs(x) - hx) < 1e-4, ey = Math.abs(Math.abs(y) - hy) < 1e-4, ez = Math.abs(Math.abs(z) - hz) < 1e-4;
    const e = ex + ey + ez, nz = vnoise(x * 2.3 + so + y * 1.7, z * 2.1 - so * .5 - y * .9);
    if (e >= 2) { const k = chip * (.3 + 1.9 * nz) * (e === 3 ? 1.7 : 1); if (ex) x -= Math.sign(x) * Math.min(k, hx * .3); if (ey) y -= Math.sign(y) * Math.min(k, hy * .3); if (ez) z -= Math.sign(z) * Math.min(k, hz * .3); }
    else { const k = chip * .7 * (nz - .5); if (ex) x += Math.sign(x) * Math.min(k, hx * .2); if (ey) y += Math.sign(y) * Math.min(k, hy * .2); if (ez) z += Math.sign(z) * Math.min(k, hz * .2); }
    p.setXYZ(i, x, y, z);
  }
  g.computeVertexNormals(); return g;
}
// tube swept along points with varying radius (trunks, roots, ribs)
function tubeGeom(pts, radFn, rs = 7, uvScale = .5) {
  const n = pts.length, pos = [], uv = [], idx = []; let N = new V3(), len = 0; const t = new V3(), B = new V3();
  for (let i = 0; i < n; i++) {
    t.subVectors(pts[Math.min(i + 1, n - 1)], pts[Math.max(i - 1, 0)]).normalize();
    if (i === 0) { N.set(0, 1, 0); if (Math.abs(t.y) > .9) N.set(1, 0, 0); N.cross(t).normalize(); }
    else N.addScaledVector(t, -N.dot(t)).normalize();
    B.crossVectors(t, N); if (i > 0) len += pts[i].distanceTo(pts[i - 1]);
    const r = radFn(i / (n - 1));
    for (let j = 0; j <= rs; j++) { const a = j / rs * TAU, c = Math.cos(a) * r, s = Math.sin(a) * r; pos.push(pts[i].x + N.x * c + B.x * s, pts[i].y + N.y * c + B.y * s, pts[i].z + N.z * c + B.z * s); uv.push(j / rs * 2, len * uvScale); }
  }
  for (let i = 0; i < n - 1; i++) for (let j = 0; j < rs; j++) { const a = i * (rs + 1) + j, b = a + rs + 1; idx.push(a, a + 1, b, b, a + 1, b + 1); }
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new T.Float32BufferAttribute(uv, 2)); g.setIndex(idx); g.computeVertexNormals(); return g;
}
// organic blob (foliage crowns, rocks)
function blobGeom(r, detail, seed, squash = .8, amp = .25, flat = false) {
  const g = new T.IcosahedronGeometry(1, detail), p = g.attributes.position, nn = new Float32Array(p.count * 3);
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const d = 1 + amp * 2 * (vnoise(x * 1.9 + seed * 3.3 + z * .7, y * 1.9 + z * 2.3 - seed) - .5);
    p.setXYZ(i, x * r * d, y * r * d * squash, z * r * d);
    const l = Math.hypot(x, y * 1.25, z); nn[i * 3] = x / l; nn[i * 3 + 1] = y * 1.25 / l; nn[i * 3 + 2] = z / l;
  }
  if (flat) g.computeVertexNormals(); else g.setAttribute('normal', new T.BufferAttribute(nn, 3));
  return g;
}
function crystalGeom(r, h) {   // hexagonal prism with pointed ends, faceted
  const g = mergeGeoms([new T.CylinderGeometry(r, r * .85, h * .5, 6, 1, true), new T.ConeGeometry(r, h * .32, 6, 1, true).translate(0, h * .41, 0), new T.ConeGeometry(r * .85, h * .2, 6, 1, true).rotateX(Math.PI).translate(0, -h * .35, 0)]);
  g.computeVertexNormals(); return g;
}
