// ============================================================================
// Audio — everything is synthesised with the Web Audio API (no audio files)
// ============================================================================
const AU = {
  ctx: null, ready: false, birdT: 2, dripT: 3,
  init() {
    if (AU.ctx) { if (AU.ctx.state === 'suspended') AU.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    let c; try { c = AU.ctx = new AC(); } catch (e) { return; }
    const m = AU.master = c.createGain(); m.gain.value = OPT.volume; m.connect(c.destination);
    // generated reverb impulse
    const len = c.sampleRate * 2.8, ir = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
    const rv = AU.rev = c.createConvolver(); rv.buffer = ir; const rg = c.createGain(); rg.gain.value = .5; rv.connect(rg); rg.connect(m);
    // noise buffers
    const mk = brown => { const b = c.createBuffer(1, c.sampleRate * 3, c.sampleRate), d = b.getChannelData(0); let l = 0; for (let i = 0; i < d.length; i++) { const w = Math.random() * 2 - 1; if (brown) { l = (l + .02 * w) / 1.02; d[i] = l * 3.5; } else d[i] = w; } return b; };
    AU.white = mk(false); AU.brown = mk(true);
    const loop = (buf, type, f, q) => { const s = c.createBufferSource(); s.buffer = buf; s.loop = true; const fl = c.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = q; const g = c.createGain(); g.gain.value = 0; s.connect(fl); fl.connect(g); g.connect(m); s.start(); return { g, fl }; };
    AU.wind = loop(AU.brown, 'bandpass', 380, .5); AU.leaves = loop(AU.white, 'highpass', 3200, .4); AU.water = loop(AU.white, 'bandpass', 760, .8); AU.water2 = loop(AU.brown, 'lowpass', 260, .3);
    // slow gusting
    const lfo = c.createOscillator(); lfo.frequency.value = .09; const lg = c.createGain(); lg.gain.value = 140; lfo.connect(lg); lg.connect(AU.wind.fl.frequency); lfo.start();
    // crystal hum
    const hg = AU.hum = c.createGain(); hg.gain.value = 0; hg.connect(m); hg.connect(rv);
    for (const [f, v] of [[196, .5], [196.9, .5], [392.6, .22], [588.4, .1]]) { const o = c.createOscillator(); o.type = 'sine'; o.frequency.value = f; const g = c.createGain(); g.gain.value = v; o.connect(g); g.connect(hg); o.start(); }
    // mysterious pad
    const pg = AU.pad = c.createGain(); pg.gain.value = 0; const pf = c.createBiquadFilter(); pf.type = 'lowpass'; pf.frequency.value = 520; pf.Q.value = .7; pf.connect(pg); pg.connect(m); pg.connect(rv);
    AU.padOsc = [0, 1, 2, 3].map(i => { const o = c.createOscillator(); o.type = i % 2 ? 'triangle' : 'sawtooth'; o.frequency.value = 110; const g = c.createGain(); g.gain.value = i % 2 ? .5 : .16; const l = c.createOscillator(); l.frequency.value = .05 + i * .037; const lg2 = c.createGain(); lg2.gain.value = 1.6; l.connect(lg2); lg2.connect(o.detune); l.start(); o.connect(g); g.connect(pf); o.start(); return o; });
    AU.ready = true;
  },
  setVolume(v) { if (AU.master) AU.master.gain.setTargetAtTime(v, AU.ctx.currentTime, .05); },
  tone(f, dur, vol, o = {}) {
    const c = AU.ctx, t = c.currentTime + (o.delay || 0), os = c.createOscillator(), g = c.createGain(); os.type = o.type || 'sine'; os.frequency.setValueAtTime(f, t); if (o.to) os.frequency.exponentialRampToValueAtTime(o.to, t + dur);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + (o.att || .01)); g.gain.exponentialRampToValueAtTime(.0005, t + dur); os.connect(g); g.connect(AU.master); if (o.rev !== false) g.connect(AU.rev); os.start(t); os.stop(t + dur + .05);
  },
  noise(dur, vol, o = {}) {
    const c = AU.ctx, t = c.currentTime + (o.delay || 0), s = c.createBufferSource(); s.buffer = o.brown ? AU.brown : AU.white; s.loop = true; const fl = c.createBiquadFilter(); fl.type = o.type || 'bandpass'; fl.frequency.setValueAtTime(o.f || 800, t); if (o.to) fl.frequency.exponentialRampToValueAtTime(o.to, t + dur); fl.Q.value = o.q || 1;
    const g = c.createGain(); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + (o.att || .005)); if (o.hold) g.gain.setValueAtTime(vol, t + dur - o.hold); g.gain.exponentialRampToValueAtTime(.0005, t + dur);
    s.connect(fl); fl.connect(g); g.connect(AU.master); if (o.rev) g.connect(AU.rev); s.start(t, Math.random() * 2); s.stop(t + dur + .05);
  },
  sfx(name, a) {
    if (typeof SAVE !== 'undefined' && SAVE.replaying) return;
    if (!AU.ready) return; const T_ = AU.tone, N = AU.noise, r = Math.random;
    switch (name) {
      case 'step': if (a === 'water') { N(.28, .13, { f: 900 + r() * 500, to: 300, q: .8 }); N(.2, .06, { f: 2600, q: .6, delay: .05 }); } else if (a === 'stone') { N(.09, .1, { f: 1500 + r() * 500, q: 1.2 }); N(.12, .12, { type: 'lowpass', f: 190, brown: true }); } else { N(.14, .075, { f: 2600 + r() * 1400, q: .5 }); N(.12, .09, { type: 'lowpass', f: 150, brown: true }); } break;
      case 'jump': N(.12, .05, { f: 500, to: 1200, q: .7 }); break;
      case 'land': N(.16, .16, { type: 'lowpass', f: 220, brown: true }); break;
      case 'pickup': [660, 880, 1320].forEach((f, i) => T_(f, .5, .09, { delay: i * .07, type: 'triangle' })); break;
      case 'relic': [392, 523.3, 659.3, 784, 1046.5].forEach((f, i) => { T_(f, 2.2, .1, { delay: i * .14 }); T_(f * 2.005, 1.8, .03, { delay: i * .14 + .02 }); }); break;
      case 'page': N(.22, .07, { f: 2400, to: 5200, q: .6 }); N(.12, .04, { f: 1200, q: .8, delay: .1 }); break;
      case 'deny': T_(160, .22, .1, { type: 'triangle', to: 120, rev: false }); break;
      case 'key': N(.05, .12, { f: 3200, q: 3 }); N(.07, .14, { f: 1800, q: 3, delay: .16 }); T_(220, .3, .06, { delay: .16, type: 'triangle' }); break;
      case 'place': T_(261.6, 1.6, .12); T_(523.3, 1.8, .08, { delay: .05 }); T_(784, 2.0, .05, { delay: .12 }); N(.3, .08, { type: 'lowpass', f: 300, brown: true }); break;
      case 'stone': { const d = a || 3; N(d, .34, { type: 'lowpass', f: 150, brown: true, att: .3, hold: .4, rev: true }); N(d, .07, { f: 420, q: 2.5, att: .2, hold: .3 }); for (let i = 0; i < d * 5; i++) N(.07, .05, { f: 500 + r() * 900, q: 2, delay: r() * d }); N(.4, .3, { type: 'lowpass', f: 110, brown: true, delay: d - .1, rev: true }); break; }
      case 'lever': N(.08, .14, { f: 1400, q: 2 }); T_(140, .3, .12, { type: 'triangle', to: 90, delay: .05 }); break;
      case 'rune': { const f = [293.7, 349.2, 440, 523.3, 587.3][a || 0]; T_(f, 2.4, .13); T_(f * 2, 1.8, .05); T_(f * 3.01, 1.2, .025); break; }
      case 'wrong': T_(110, .9, .16, { type: 'sawtooth', to: 70 }); T_(116.5, .9, .12, { type: 'sawtooth', to: 74 }); N(.5, .12, { type: 'lowpass', f: 200, brown: true }); break;
      case 'solve': [261.6, 329.6, 392, 523.3, 659.3, 784, 1046.5].forEach((f, i) => T_(f, 3.2 - i * .2, .085, { delay: i * .11 })); T_(130.8, 3.5, .12, { type: 'triangle' }); break;
      case 'spirit': T_(523.3, 1.8, .05, { to: 659.3 }); T_(784, 1.6, .03, { delay: .15, to: 698.5 }); N(1.2, .02, { f: 3000, q: 4, rev: true, att: .3 }); break;
      case 'beam': T_(1174.7, 1.6, .06); T_(880, 2.2, .06, { to: 1760 }); N(.8, .05, { f: 5000, q: 2, rev: true }); break;
      case 'mirror': N(.4, .1, { f: 600, to: 900, q: 3, att: .05 }); T_(1568, .5, .035, { delay: .35 }); break;
      case 'grab': N(.1, .14, { type: 'lowpass', f: 260, brown: true }); break;
      case 'thud': N(.2, .2, { type: 'lowpass', f: 140, brown: true }); break;
      case 'drag': N(.42, .13, { type: 'lowpass', f: 210 + r() * 70, brown: true, att: .08 }); N(.3, .035, { f: 700 + r() * 500, q: 2, att: .05 }); break;
      case 'plate': N(.15, .16, { type: 'lowpass', f: 180, brown: true }); T_(392, 1.2, .08, { delay: .05 }); break;
      case 'ui': T_(880, .12, .03, { type: 'triangle', rev: false }); break;
      case 'finale': { [65.4, 98, 130.8, 196].forEach((f, i) => T_(f, 13, .11, { type: i % 2 ? 'triangle' : 'sawtooth', att: 4 })); [523.3, 659.3, 784, 987.8, 1046.5, 1318.5, 1568].forEach((f, i) => T_(f, 6, .06, { delay: 4.5 + i * .55 })); N(13, .12, { f: 300, to: 3200, q: .8, att: 9, rev: true }); AU.sfx('stone', 5); break; }
    }
  },
  update(dt, w, indoor, nearGlow) {
    if (!AU.ready) return; const c = AU.ctx, t = c.currentTime, set = (g, v) => g.gain.setTargetAtTime(v, t, .6), play = G.mode === 'title' ? .5 : 1;
    set(AU.wind.g, (.035 + .05 * w.court + .03 * w.forest + .16 * w.sanct) * (1 - .7 * indoor) * play);
    set(AU.leaves.g, (.02 * w.forest + .008 * w.court) * play);
    const pd = Math.hypot(P.pos.x - POND.x, P.pos.z - POND.z), wat = Math.max(w.temple, sstep(16, 5, pd) * .7);
    set(AU.water.g, .03 * wat * play); set(AU.water2.g, .12 * wat * play);
    set(AU.hum, .05 * sstep(9, 1.5, nearGlow) * play); set(AU.pad, .042);
    const root = w.temple > .5 ? 69.3 : w.sanct > .5 ? 110 : w.forest > .5 ? 87.3 : 73.4, iv = w.temple > .5 ? [1, 1.498, 2.378, 3] : w.sanct > .5 ? [1, 1.5, 2.52, 3.36] : [1, 1.498, 2.245, 2.997];
    AU.padOsc.forEach((o, i) => o.frequency.setTargetAtTime(root * iv[i], t, 2.5));
    if (G.mode !== 'play') return;
    AU.birdT -= dt; if (AU.birdT < 0) { AU.birdT = 1.5 + Math.random() * 6; const amt = w.forest + w.court * .6; if (Math.random() < amt) { const f = 2200 + Math.random() * 2400, n = 2 + Math.floor(Math.random() * 4); for (let i = 0; i < n; i++) AU.tone(f * (1 + Math.random() * .2), .09 + Math.random() * .08, .022, { delay: i * (.11 + Math.random() * .05), to: f * (1.15 + Math.random() * .5), type: 'sine' }); } }
    AU.dripT -= dt; if (AU.dripT < 0) { AU.dripT = .8 + Math.random() * 3.5; if (indoor > .5 || (w.temple > .6 && Math.random() < .4)) AU.tone(1300 + Math.random() * 900, .16, .035, { to: 600 }); }
  },
};
