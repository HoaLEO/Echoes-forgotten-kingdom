// ============================================================================
// Renderer, HDR post-processing (bloom + ACES), sky, environment grading, particles
// ============================================================================
const PRESETS = {
  low: { scale: .6, shadow: 1024, msaa: 0, grass: .3, motes: .5, bloom: 4, vegFar: 40, lod: 28 },
  medium: { scale: .8, shadow: 2048, msaa: 2, grass: .6, motes: .8, bloom: 5, vegFar: 52, lod: 50 },
  high: { scale: 1, shadow: 2048, msaa: 4, grass: 1, motes: 1, bloom: 5, vegFar: 64, lod: 72 },
  ultra: { scale: 1.3, shadow: 4096, msaa: 4, grass: 1, motes: 1, bloom: 6, vegFar: 85, lod: 110 },
};
const UPH = { value: 800 };
const SUN = new V3(-.42, .74, .52).normalize();
const R = { preset: PRESETS.high, presetName: 'high', fade: 0, fadeColor: new T.Color(0, 0, 0), exposureMul: 1, bloomMul: 1, shake: 0 };

const ENV = {   // per-region atmosphere
  court: { fog: '#9db8a4', dens: .0105, sky: '#bcd6ea', gnd: '#66744c', hemi: 1.2, sunC: '#ffe6c0', sun: 3.2, zen: '#3f7fc4', hor: '#cfe2e4', exp: 1.25, cloud: 1, night: 0 },
  forest: { fog: '#5d9c84', dens: .019, sky: '#9fd0a8', gnd: '#3f6034', hemi: 1.5, sunC: '#fff2c4', sun: 3.5, zen: '#3b86b8', hor: '#b9e0cf', exp: 1.42, cloud: 1, night: 0 },
  temple: { fog: '#27504f', dens: .016, sky: '#a4d8d2', gnd: '#4f5c50', hemi: 1.55, sunC: '#d8fff0', sun: 2.6, zen: '#2a7896', hor: '#6cc4b8', exp: 1.6, cloud: .5, night: 0 },
  sanct: { fog: '#3d5f9e', dens: .0075, sky: '#9fc0ff', gnd: '#44527a', hemi: 1.75, sunC: '#c4d8ff', sun: 2.5, zen: '#0b1840', hor: '#4d7ccc', exp: 1.3, cloud: .45, night: 1 },   // blue twilight: moonlight + crystal light
};
const envCur = { fog: new T.Color(), dens: .01, sky: new T.Color(), gnd: new T.Color(), hemi: 1, sunC: new T.Color(), sun: 3, zen: new T.Color(), hor: new T.Color(), exp: 1, cloud: 1, night: 0 };
const _envT = { fog: new T.Color(), sky: new T.Color(), gnd: new T.Color(), sunC: new T.Color(), zen: new T.Color(), hor: new T.Color() };
for (const k of Object.keys(ENV)) for (const f of ['fog', 'sky', 'gnd', 'sunC', 'zen', 'hor']) ENV[k][f] = new T.Color(ENV[k][f]);

function regionWeights(x, y, z) {
  const s = sstep(5, 18, y), t = sstep(26, 38, x) * sstep(-30, -24, z) * (1 - s), f = sstep(-20, -32, x) * (1 - s);
  return { sanct: s, temple: t, forest: f, court: Math.max(0, 1 - s - t - f) };
}

const FS_VERT = 'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}';
function fsMat(frag, uniforms) { return new T.ShaderMaterial({ uniforms, vertexShader: FS_VERT, fragmentShader: frag, depthTest: false, depthWrite: false }); }

function initRenderer(canvas) {
  const r = R.renderer = new T.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance', alpha: false });
  r.shadowMap.enabled = true; r.shadowMap.type = T.PCFSoftShadowMap; r.toneMapping = T.NoToneMapping; r.info.autoReset = true;
  R.camera = new T.PerspectiveCamera(72, 1, .08, 1400); R.camera.rotation.order = 'YXZ';
  const sc = W.scene; sc.fog = new T.FogExp2(0x9db8a4, .01);
  R.hemi = new T.HemisphereLight(0xffffff, 0x444444, 1); sc.add(R.hemi);
  const sun = R.sun = new T.DirectionalLight(0xffffff, 3); sun.castShadow = true;
  const s = sun.shadow; s.camera.left = s.camera.bottom = -52; s.camera.right = s.camera.top = 52; s.camera.near = 1; s.camera.far = 260; s.bias = -.0004; s.normalBias = .06;
  sc.add(sun); sc.add(sun.target);
  R.points = []; for (let i = 0; i < 6; i++) { const p = new T.PointLight(0xffffff, 0, 12, 2); sc.add(p); R.points.push(p); }
  // sky dome
  R.skyU = { uZen: { value: new T.Color() }, uHor: { value: new T.Color() }, uSun: { value: SUN }, uSunCol: { value: new T.Color() }, uTime, uCloud: { value: 1 }, uNight: { value: 0 } };
  const sky = R.sky = new T.Mesh(new T.SphereGeometry(900, 32, 16), new T.ShaderMaterial({
    uniforms: R.skyU, side: T.BackSide, depthWrite: false, fog: false,
    vertexShader: 'varying vec3 vDir;void main(){vDir=position;vec4 p=projectionMatrix*modelViewMatrix*vec4(position,1.);gl_Position=p.xyww;}',
    fragmentShader: `varying vec3 vDir;uniform vec3 uZen,uHor,uSun,uSunCol;uniform float uTime,uCloud,uNight;${GLSL_NOISE}
void main(){vec3 d=normalize(vDir);float h=max(d.y,0.);vec3 c=mix(uHor,uZen,pow(h,.55));
float s=max(dot(d,uSun),0.);c+=uSunCol*(pow(s,700.)*14.+pow(s,28.)*.45+pow(s,4.)*.12);
vec2 p=d.xz/(d.y+.2)*1.3+uTime*.006;float cl=fbm2(p*1.3)+.5*fbm2(p*3.1+3.);
cl=smoothstep(.72,1.2,cl)*smoothstep(0.,.22,d.y)*uCloud;
if(uNight>.01){vec3 q=d*190.;vec3 iq=floor(q);float hs=fract(sin(dot(iq,vec3(12.9898,78.233,37.719)))*43758.5453);float tw=.6+.4*sin(uTime*2.+hs*90.);
float st=step(.9972,hs)*smoothstep(.75,.2,length(fract(q)-.5))*tw*smoothstep(.02,.3,d.y);c+=vec3(.75,.88,1.)*st*2.6*uNight*(1.-cl);
float band=fbm2(d.xz*2.2+vec2(uTime*.01,0.))*smoothstep(.1,.7,d.y)*smoothstep(.45,.0,abs(d.x*.6+d.z*.8));c+=vec3(.12,.3,.55)*band*.5*uNight;}
c=mix(c,mix(mix(uHor*1.1,vec3(1.,.97,.9)*1.5,.55+.45*s),uHor*.9+uSunCol*.25*s,uNight),cl*.8);
if(d.y<0.)c=mix(c,uHor*.75,clamp(-d.y*5.,0.,1.));
gl_FragColor=vec4(c,1.);}` }));
  sky.frustumCulled = false; sky.renderOrder = -10; sc.add(sky);
  // far peaks for the mountaintop vista
  const pg = []; const rr = rng(77);
  for (let i = 0; i < 34; i++) {   // two staggered rings of ridged, snow-capped peaks
    const near = i % 2, a = i / 34 * TAU + rr() * .25, d = (near ? 250 : 420) + rr() * 170, h = (near ? 55 : 110) + rr() * (near ? 70 : 150), rad = (near ? 60 : 95) + rr() * 80;
    const g = new T.ConeGeometry(rad, h, 11, 6), p = g.attributes.position;
    for (let k = 0; k < p.count; k++) { const x = p.getX(k), y = p.getY(k), z = p.getZ(k), t = (y / h + .5), rd = 1 + (vnoise(x * .03 + i * 7, z * .03 + y * .02) - .5) * 1.1 * (1 - t * .5) + (vnoise(x * .09 + i, z * .09) - .5) * .35; p.setXYZ(k, x * rd + (vnoise(y * .05, i * 3.1) - .5) * 30 * t, y * (1 + (vnoise(x * .02 + i, z * .02) - .5) * .25), z * rd + (vnoise(i * 5.3, y * .05) - .5) * 30 * t); }
    g.translate(Math.cos(a) * d, h / 2 - 24, -40 + Math.sin(a) * d); const gn = g.toNonIndexed(); gn.computeVertexNormals();
    paint(gn, (x, y, z, nx, ny) => { const snow = sstep(h * .42, h * .7, y + 24 + (vnoise(x * .05, z * .05) - .5) * 30) * sstep(.25, .6, ny), k = .5 + .32 * sstep(-24, h, y); return [k + snow * .75, k + snow * .8, k * 1.06 + snow * .9]; }); pg.push(gn);
  }
  const peaks = R.peaks = new T.Mesh(mergeGeoms(pg), new T.MeshLambertMaterial({ vertexColors: true, fog: false })); sc.add(peaks);
  // post chain
  const hf = r.capabilities.isWebGL2 && (r.extensions.has('EXT_color_buffer_float') || r.extensions.has('EXT_color_buffer_half_float'));
  R.rtType = hf ? T.HalfFloatType : T.UnsignedByteType;
  R.fsScene = new T.Scene(); R.fsCam = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  R.fsQuad = new T.Mesh(new T.PlaneGeometry(2, 2), null); R.fsQuad.frustumCulled = false; R.fsScene.add(R.fsQuad);
  R.mPre = fsMat(`varying vec2 vUv;uniform sampler2D tMap;uniform vec2 uPx;uniform float uTh;
void main(){vec3 c=(texture2D(tMap,vUv+uPx*vec2(-.5,-.5)).rgb+texture2D(tMap,vUv+uPx*vec2(.5,-.5)).rgb+texture2D(tMap,vUv+uPx*vec2(-.5,.5)).rgb+texture2D(tMap,vUv+uPx*vec2(.5,.5)).rgb)*.25;
c=min(c,vec3(24.));float br=max(c.r,max(c.g,c.b));float k=uTh*.5;float so=clamp(br-uTh+k,0.,2.*k);so=so*so/(4.*k+1e-4);
gl_FragColor=vec4(c*max(so,br-uTh)/max(br,1e-4),1.);}`, { tMap: { value: null }, uPx: { value: new T.Vector2() }, uTh: { value: 1.05 } });
  R.mDown = fsMat(`varying vec2 vUv;uniform sampler2D tMap;uniform vec2 uPx;
void main(){vec3 c=texture2D(tMap,vUv).rgb*4.;c+=texture2D(tMap,vUv+uPx*vec2(-1.,-1.)).rgb+texture2D(tMap,vUv+uPx*vec2(1.,-1.)).rgb+texture2D(tMap,vUv+uPx*vec2(-1.,1.)).rgb+texture2D(tMap,vUv+uPx*vec2(1.,1.)).rgb;gl_FragColor=vec4(c/8.,1.);}`, { tMap: { value: null }, uPx: { value: new T.Vector2() } });
  R.mUp = fsMat(`varying vec2 vUv;uniform sampler2D tMap,tAdd;uniform vec2 uPx;
void main(){vec3 c=texture2D(tMap,vUv).rgb*4.;
c+=(texture2D(tMap,vUv+uPx*vec2(-1.,0.)).rgb+texture2D(tMap,vUv+uPx*vec2(1.,0.)).rgb+texture2D(tMap,vUv+uPx*vec2(0.,-1.)).rgb+texture2D(tMap,vUv+uPx*vec2(0.,1.)).rgb)*2.;
c+=texture2D(tMap,vUv+uPx*vec2(-1.,-1.)).rgb+texture2D(tMap,vUv+uPx*vec2(1.,-1.)).rgb+texture2D(tMap,vUv+uPx*vec2(-1.,1.)).rgb+texture2D(tMap,vUv+uPx*vec2(1.,1.)).rgb;
gl_FragColor=vec4(c/16.+texture2D(tAdd,vUv).rgb,1.);}`, { tMap: { value: null }, tAdd: { value: null }, uPx: { value: new T.Vector2() } });
  R.mFinal = fsMat(`varying vec2 vUv;uniform sampler2D tScene,tBloom;uniform float uExp,uBloom,uFade,uTime;uniform vec3 uFadeC;
vec3 aces(vec3 v){v=mat3(.59719,.076,.0284,.35458,.90834,.13383,.04823,.01566,.83777)*v;
vec3 a=v*(v+.0245786)-.000090537;vec3 b=v*(.983729*v+.4329510)+.238081;v=a/b;
return clamp(mat3(1.60475,-.10208,-.00327,-.53108,1.10813,-.07276,-.07367,-.00605,1.07602)*v,0.,1.);}
float h1(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
void main(){vec3 c=texture2D(tScene,vUv).rgb+texture2D(tBloom,vUv).rgb*uBloom;c*=uExp;
c=aces(c*1.15);float l=dot(c,vec3(.2126,.7152,.0722));c=mix(vec3(l),c,1.12);c=pow(c,vec3(1.04));
vec2 q=vUv-.5;c*=1.-dot(q,q)*.62;
c=pow(c,vec3(1./2.2));c=mix(c,uFadeC,uFade);c+=(h1(vUv*917.+uTime)-.5)*.012;
gl_FragColor=vec4(c,1.);}`, { tScene: { value: null }, tBloom: { value: null }, uExp: { value: 1 }, uBloom: { value: .7 }, uFade: { value: 0 }, uFadeC: { value: R.fadeColor }, uTime });
  applyPreset(R.presetName);
}
function applyPreset(name) {
  R.presetName = name; const p = R.preset = PRESETS[name], r = R.renderer;
  r.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  const s = R.sun.shadow; if (s.mapSize.x !== p.shadow) { s.mapSize.set(p.shadow, p.shadow); if (s.map) { s.map.dispose(); s.map = null; } }
  resizeRenderer();
  uVegFar.value = p.vegFar;
  if (W.instMeshes) for (const k of ['grass', 'fern', 'flower']) { const a = W.instMeshes[k]; if (a) for (const ch of a.chunks) ch.hi.count = Math.max(1, Math.ceil(ch.hi.userData.full * (k === 'grass' ? p.grass : Math.min(1, p.grass + .3)))); }
  if (W.motes) for (const m of W.motes) m.geometry.setDrawRange(0, Math.floor(m.userData.full * p.motes));
}
function resizeRenderer() {
  const r = R.renderer, p = R.preset, cw = window.innerWidth, ch = window.innerHeight, dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  r.setSize(cw, ch, false);
  const w = Math.max(64, Math.round(cw * dpr * p.scale)), h = Math.max(64, Math.round(ch * dpr * p.scale));
  R.camera.aspect = cw / ch; R.camera.updateProjectionMatrix();
  if (R.rt) R.rt.dispose(); if (R.bl) for (const b of R.bl) { b.d.dispose(); b.u.dispose(); }
  R.rt = new T.WebGLRenderTarget(w, h, { type: R.rtType, samples: p.msaa, depthBuffer: true });
  R.bl = []; let bw = w, bh = h;
  for (let i = 0; i < p.bloom; i++) { bw = Math.max(2, bw >> 1); bh = Math.max(2, bh >> 1); const o = { type: R.rtType, depthBuffer: false }; R.bl.push({ d: new T.WebGLRenderTarget(bw, bh, o), u: new T.WebGLRenderTarget(bw, bh, o), w: bw, h: bh }); }
  R.w = w; R.h = h;
}
function runPass(mat, target) { R.fsQuad.material = mat; R.renderer.setRenderTarget(target); R.renderer.render(R.fsScene, R.fsCam); }
function renderFrame() {
  const r = R.renderer;
  r.setRenderTarget(R.rt); r.render(W.scene, R.camera);
  const bl = R.bl;
  R.mPre.uniforms.tMap.value = R.rt.texture; R.mPre.uniforms.uPx.value.set(1 / R.w, 1 / R.h); runPass(R.mPre, bl[0].d);
  for (let i = 1; i < bl.length; i++) { R.mDown.uniforms.tMap.value = bl[i - 1].d.texture; R.mDown.uniforms.uPx.value.set(1 / bl[i - 1].w, 1 / bl[i - 1].h); runPass(R.mDown, bl[i].d); }
  let prev = bl[bl.length - 1].d;
  for (let i = bl.length - 2; i >= 0; i--) { R.mUp.uniforms.tMap.value = prev.texture; R.mUp.uniforms.tAdd.value = bl[i].d.texture; R.mUp.uniforms.uPx.value.set(1 / prev.width, 1 / prev.height); runPass(R.mUp, bl[i].u); prev = bl[i].u; }
  const f = R.mFinal.uniforms; f.tScene.value = R.rt.texture; f.tBloom.value = prev.texture; f.uExp.value = envCur.exp * R.exposureMul; f.uBloom.value = .16 * R.bloomMul; f.uFade.value = R.fade;
  runPass(R.mFinal, null);
}

// ---- per-frame atmosphere + lights
const _v = new V3();
function updateEnvironment(dt, px, py, pz, indoor) {
  const w = regionWeights(px, py, pz), k = 1 - Math.exp(-dt * 1.6);
  for (const f of ['fog', 'sky', 'gnd', 'sunC', 'zen', 'hor']) { const c = _envT[f].setRGB(0, 0, 0); for (const rg in w) { const e = ENV[rg][f], ww = w[rg]; c.r += e.r * ww; c.g += e.g * ww; c.b += e.b * ww; } envCur[f].lerp(c, dt > 5 ? 1 : k); }
  for (const f of ['dens', 'hemi', 'sun', 'exp', 'cloud', 'night']) { let v = 0; for (const rg in w) v += ENV[rg][f] * w[rg]; if (f === 'hemi') v *= 1 - .3 * indoor; if (f === 'exp') v *= 1 + .3 * indoor; envCur[f] = dt > 5 ? v : lerp(envCur[f], v, k); }
  const sc = W.scene; sc.fog.color.copy(envCur.fog); sc.fog.density = envCur.dens;
  R.hemi.color.copy(envCur.sky); R.hemi.groundColor.copy(envCur.gnd); R.hemi.intensity = envCur.hemi;
  R.sun.color.copy(envCur.sunC); R.sun.intensity = envCur.sun;
  R.skyU.uZen.value.copy(envCur.zen); R.skyU.uHor.value.copy(envCur.hor); R.skyU.uSunCol.value.copy(envCur.sunC); R.skyU.uCloud.value = envCur.cloud; R.skyU.uNight.value = envCur.night; if (R.peaks) R.peaks.material.color.copy(envCur.fog).lerp(envCur.zen, .3).multiplyScalar(1.5);
  // shadow frustum follows the player on a coarse grid (stable shadows)
  const gx = Math.round(px / 4) * 4, gz = Math.round(pz / 4) * 4, gy = Math.round(py / 4) * 4;
  R.sun.target.position.set(gx, gy, gz); R.sun.position.set(gx, gy, gz).addScaledVector(SUN, 130); R.sun.target.updateMatrixWorld();
  R.sky.position.copy(R.camera.position);
  // nearest glow sources drive the pooled point lights
  const cam = R.camera.position, list = W.glows;
  for (const g of list) g._d = g.on ? g.pos.distanceToSquared(cam) / (g.power + .2) : 1e12;
  list.sort((a, b) => a._d - b._d);
  for (let i = 0; i < R.points.length; i++) {
    const p = R.points[i], g = list[i];
    if (!g || !g.on || g._d > 2500) { p.intensity = 0; continue; }
    p.position.copy(g.pos); p.color.copy(g.color); p.distance = g.range; p.intensity = g.power * 22 * (.9 + .1 * Math.sin(W.time * 2.3 + i * 1.7));
  }
}

// ---------------------------------------------------------------- particles
W.motes = [];
function makeMotes(count, sample, hex, size) {   // sample(i)->[x,y,z]
  const P = new Float32Array(count * 3), A = new Float32Array(count * 4), rr = rng(count * 13 + 5);
  for (let i = 0; i < count; i++) { const p = sample(rr); P[i * 3] = p[0]; P[i * 3 + 1] = p[1]; P[i * 3 + 2] = p[2]; A[i * 4] = .4 + rr(); A[i * 4 + 1] = rr(); A[i * 4 + 2] = .5 + rr(); A[i * 4 + 3] = .35 + rr() * .65; }
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(P, 3)); g.setAttribute('aRnd', new T.BufferAttribute(A, 4));
  const m = new T.Points(g, new T.ShaderMaterial({
    uniforms: { uTime, uColor: { value: new T.Color(hex) }, uSize: { value: size }, uH: UPH }, transparent: true, depthWrite: false, blending: T.AdditiveBlending,
    vertexShader: `attribute vec4 aRnd;uniform float uTime,uSize,uH;varying float vA;
void main(){vec3 p=position+vec3(sin(uTime*aRnd.x*.5+aRnd.y*6.28)*1.6,sin(uTime*.33*aRnd.z+aRnd.w*6.28)*.9,cos(uTime*aRnd.y*.45+aRnd.x*6.28)*1.6);
vec4 mv=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*mv;float d=-mv.z;
gl_PointSize=uSize*aRnd.w*uH/max(d,.5);vA=(.45+.55*sin(uTime*2.*aRnd.z+aRnd.y*40.))*smoothstep(70.,35.,d)*smoothstep(.4,1.6,d);}`,
    fragmentShader: `uniform vec3 uColor;varying float vA;void main(){vec2 q=gl_PointCoord-.5;float r=length(q);float a=smoothstep(.5,0.,r);gl_FragColor=vec4(uColor*a*a*vA,1.);}` }));
  m.frustumCulled = false; m.userData.full = count; W.scene.add(m); W.motes.push(m); return m;
}
// CPU burst pool (pickups, puzzle feedback, finale)
const BURST = { n: 600, i: 0 };
function initBursts() {
  const n = BURST.n; BURST.p = new Float32Array(n * 3); BURST.c = new Float32Array(n * 3); BURST.s = new Float32Array(n); BURST.v = new Float32Array(n * 3); BURST.life = new Float32Array(n); BURST.max = new Float32Array(n);
  const g = new T.BufferGeometry(); g.setAttribute('position', new T.BufferAttribute(BURST.p, 3)); g.setAttribute('color', new T.BufferAttribute(BURST.c, 3)); g.setAttribute('aS', new T.BufferAttribute(BURST.s, 1));
  BURST.mesh = new T.Points(g, new T.ShaderMaterial({ uniforms: { uH: UPH }, transparent: true, depthWrite: false, blending: T.AdditiveBlending, vertexColors: true,
    vertexShader: 'attribute float aS;uniform float uH;varying vec3 vC;void main(){vC=color;vec4 mv=modelViewMatrix*vec4(position,1.);gl_Position=projectionMatrix*mv;gl_PointSize=aS*uH/max(-mv.z,.5);}',
    fragmentShader: 'varying vec3 vC;void main(){float a=smoothstep(.5,0.,length(gl_PointCoord-.5));gl_FragColor=vec4(vC*a*a,1.);}' }));
  BURST.mesh.frustumCulled = false; W.scene.add(BURST.mesh);
}
function burst(pos, hex, count = 40, speed = 2.5, life = 1.4, up = 1.2, size = .09) {
  _c.set(hex); for (let k = 0; k < count; k++) {
    const i = BURST.i = (BURST.i + 1) % BURST.n, a = Math.random() * TAU, e = Math.acos(2 * Math.random() - 1), s = speed * (.3 + Math.random());
    BURST.p[i * 3] = pos.x; BURST.p[i * 3 + 1] = pos.y; BURST.p[i * 3 + 2] = pos.z;
    BURST.v[i * 3] = Math.sin(e) * Math.cos(a) * s; BURST.v[i * 3 + 1] = Math.cos(e) * s + up; BURST.v[i * 3 + 2] = Math.sin(e) * Math.sin(a) * s;
    BURST.c[i * 3] = _c.r * 3; BURST.c[i * 3 + 1] = _c.g * 3; BURST.c[i * 3 + 2] = _c.b * 3; BURST.life[i] = BURST.max[i] = life * (.5 + Math.random()); BURST.s[i] = size * (.5 + Math.random());
  }
}
function updateBursts(dt) {
  const b = BURST; let any = false;
  for (let i = 0; i < b.n; i++) {
    if (b.life[i] <= 0) continue; any = true; b.life[i] -= dt;
    b.v[i * 3 + 1] -= 1.2 * dt; const dmp = 1 - dt * .9;
    b.p[i * 3] += b.v[i * 3] * dt; b.p[i * 3 + 1] += b.v[i * 3 + 1] * dt; b.p[i * 3 + 2] += b.v[i * 3 + 2] * dt; b.v[i * 3] *= dmp; b.v[i * 3 + 2] *= dmp;
    if (b.life[i] <= 0) b.s[i] = 0; else { const f = 1 - dt * 1.4 / b.max[i]; b.c[i * 3] *= f; b.c[i * 3 + 1] *= f; b.c[i * 3 + 2] *= f; }
  }
  if (any || b.dirty) { const a = b.mesh.geometry.attributes; a.position.needsUpdate = a.color.needsUpdate = a.aS.needsUpdate = true; b.dirty = any; }
}
// light shafts (sun through canopy / roof openings)
let SHAFT_MAT = null; const SHAFTS = [];
function shaft(x, y, z, h, w, hex, alpha) {
  const q = new T.Quaternion().setFromUnitVectors(new V3(0, 1, 0), SUN);
  for (let k = 0; k < 2; k++) { const g = new T.PlaneGeometry(w, h, 1, 1).translate(0, h / 2, 0).rotateY(k * Math.PI / 2 + x).applyQuaternion(q).translate(x, y, z); const c = col(hex); paint(g, () => [c[0] * alpha, c[1] * alpha, c[2] * alpha]); SHAFTS.push(g); }
}
function finalizeShafts() {
  if (!SHAFTS.length) return;
  const m = new T.Mesh(mergeGeoms(SHAFTS), new T.ShaderMaterial({ uniforms: { uTime }, transparent: true, depthWrite: false, blending: T.AdditiveBlending, side: T.DoubleSide, vertexColors: true,
    vertexShader: 'varying vec2 vUv;varying vec3 vC;varying float vD;void main(){vUv=uv;vC=color;vec4 mv=modelViewMatrix*vec4(position,1.);vD=-mv.z;gl_Position=projectionMatrix*mv;}',
    fragmentShader: `varying vec2 vUv;varying vec3 vC;varying float vD;uniform float uTime;${GLSL_NOISE}
void main(){float a=smoothstep(0.,.3,vUv.x)*smoothstep(1.,.7,vUv.x)*smoothstep(0.,.25,vUv.y)*smoothstep(1.,.45,vUv.y);
a*=.55+.45*vn2(vec2(vUv.x*5.+uTime*.07,vUv.y*1.5-uTime*.05));a*=smoothstep(1.5,9.,vD)*smoothstep(90.,50.,vD);gl_FragColor=vec4(vC*a,1.);}` }));
  m.frustumCulled = false; m.renderOrder = 5; W.scene.add(m);
}
function makeHalo(hex, size, opacity = .8) {
  const s = new T.Sprite(new T.SpriteMaterial({ map: TEX.glow, color: hex, transparent: true, opacity, blending: T.AdditiveBlending, depthWrite: false, fog: false }));
  s.scale.setScalar(size); return s;
}
