// ============================================================================
// First-person controller, input, interaction picking
// ============================================================================
const KEYS = {};
const P = {
  pos: new V3(0, 0, 16), vel: new V3(), yaw: 0, pitch: 0, onGround: true, r: .36, h: 1.75, eye: 1.62, stepH: .55,
  camY: 0, bob: 0, stepAcc: 0, inWater: false, grab: null, safe: new V3(0, 0, 16), safeT: 0, frozen: false, moved: 0,
};
const OPT = { sens: 1, invertY: false, fov: 72, volume: .8, preset: 'high', guide: true };
try { Object.assign(OPT, JSON.parse(localStorage.getItem('eotfk_opts') || '{}')); } catch (e) { }
function saveOpts() { try { localStorage.setItem('eotfk_opts', JSON.stringify(OPT)); } catch (e) { } }

function surfaceAt(x, y, z) {
  for (const w of W.water) if (x > w.x0 && x < w.x1 && z > w.z0 && z < w.z1 && y < w.y - .08) return 'water';
  if (y > terrainH(x, z) + .04) return 'stone';
  if (Math.abs(x) < 19 && Math.abs(z) < 19) return 'stone';
  if (y > 27.5 || x > 26) return 'stone';
  return 'grass';
}
function tryMove(dx, dz) {
  const ox = P.pos.x, oz = P.pos.z, feet = P.pos.y;
  let [nx, nz] = resolveCircle(ox + dx, oz + dz, P.r, feet + P.stepH, feet + P.h, P.grab && P.grab.col);
  const d = Math.hypot(nx - ox, nz - oz); if (d < 1e-6) return false;
  if (!inPlay(nx, nz) && inPlay(ox, oz)) return false;                                  // edge of the explorable world
  const tO = terrainH(ox, oz), tN = terrainH(nx, nz);
  if (tN - tO > 1.15 * d + .02 && tN > feet + .02) return false;                       // too steep to climb
  if (P.onGround && feet <= tO + .12 && tO - tN > 1.7 * d + .05) return false;          // refuse to walk off cliffs
  P.pos.x = nx; P.pos.z = nz; return true;
}
function updatePlayer(dt) {
  if (P.frozen) return;
  let fx = 0, fz = 0;
  if (KEYS.KeyW) fz -= 1; if (KEYS.KeyS) fz += 1; if (KEYS.KeyA) fx -= 1; if (KEYS.KeyD) fx += 1;
  // keyboard look (arrow keys) — fallback when the mouse cannot be captured
  { const k = 1.9 * dt * OPT.sens; if (KEYS.ArrowLeft) P.yaw += k; if (KEYS.ArrowRight) P.yaw -= k; if (KEYS.ArrowUp) P.pitch = clamp(P.pitch + k * .7, -1.5, 1.5); if (KEYS.ArrowDown) P.pitch = clamp(P.pitch - k * .7, -1.5, 1.5); }
  const l = Math.hypot(fx, fz); if (l > 0) { fx /= l; fz /= l; }
  const sprint = (KEYS.ShiftLeft || KEYS.ShiftRight) && fz < 0 && !P.grab;
  let sp = sprint ? 7.0 : 4.3; if (P.inWater) sp *= .62; if (P.grab) sp *= .5;
  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  const wx = (fx * cy + fz * sy) * sp, wz = (-fx * sy + fz * cy) * sp;
  const acc = P.onGround ? 11 : 2.5, k = 1 - Math.exp(-acc * dt);
  P.vel.x = lerp(P.vel.x, wx, k); P.vel.z = lerp(P.vel.z, wz, k);
  if (KEYS.Space && P.onGround && !P.grab) { P.vel.y = 6.7; P.onGround = false; AU.sfx('jump'); }
  // horizontal move in substeps with sliding
  const dist = Math.hypot(P.vel.x, P.vel.z) * dt, n = Math.max(1, Math.ceil(dist / .18)), sx = P.vel.x * dt / n, sz = P.vel.z * dt / n;
  const bx = P.pos.x, bz = P.pos.z;
  for (let i = 0; i < n; i++) { if (!tryMove(sx, sz)) { const a = tryMove(sx, 0), b = tryMove(0, sz); if (!a && !b) { P.vel.x *= .5; P.vel.z *= .5; break; } } }
  const movedD = Math.hypot(P.pos.x - bx, P.pos.z - bz);
  // vertical
  const wasGround = P.onGround;
  P.pos.y += P.vel.y * dt - 10.5 * dt * dt; P.vel.y -= 21 * dt;   // exact integration: jump height is frame-rate independent
  const g = groundAt(P.pos.x, P.pos.z, Math.max(P.pos.y, P.pos.y - P.vel.y * dt), P.stepH);
  if (P.pos.y <= g) { if (!wasGround && P.vel.y < -7) AU.sfx('land'); P.pos.y = g; P.vel.y = 0; P.onGround = true; }
  else if (wasGround && P.vel.y <= 0 && P.pos.y - g < P.stepH) { P.pos.y = g; P.vel.y = 0; P.onGround = true; }
  else P.onGround = false;
  // water + footsteps
  P.inWater = surfaceAt(P.pos.x, P.pos.y, P.pos.z) === 'water';
  if (P.onGround && movedD > 1e-4) { P.stepAcc += movedD; P.bob += movedD * (sprint ? 1.25 : 1.5); P.moved += movedD; if (P.stepAcc > (sprint ? 2.5 : 1.9)) { P.stepAcc = 0; AU.sfx('step', surfaceAt(P.pos.x, P.pos.y, P.pos.z)); } }
  // safety net
  P.safeT += dt;
  if (P.onGround && P.safeT > 1.5) { P.safeT = 0; P.safe.copy(P.pos); }
  if (!(P.pos.y > -30) || P.pos.y < terrainH(P.pos.x, P.pos.z) - 4 || Math.abs(P.pos.x) > 125 || P.pos.z > 60 || P.pos.z < -158) { P.pos.copy(P.safe); P.vel.set(0, 0, 0); }
}
function updateCamera(dt) {
  const c = R.camera;
  P.camY = Math.abs(P.camY - P.pos.y) > 3 ? P.pos.y : lerp(P.camY, P.pos.y, 1 - Math.exp(-dt * 16));
  const bob = P.onGround ? Math.sin(P.bob * 3.3) * .035 : 0;
  c.position.set(P.pos.x, P.camY + P.eye + bob, P.pos.z);
  if (R.shake > 0) { c.position.x += (Math.random() - .5) * R.shake; c.position.y += (Math.random() - .5) * R.shake; }
  c.rotation.set(P.pitch, P.yaw, 0);
  if (c.fov !== OPT.fov) { c.fov = OPT.fov; c.updateProjectionMatrix(); }
}
function lookAt2D(x, z) { P.yaw = Math.atan2(-(x - P.pos.x), -(z - P.pos.z)); }
// ---- interaction picking: nearest target in a cone in front of the camera
const _f = new V3(), _d = new V3();
function pickInter() {
  const c = R.camera; c.getWorldDirection(_f); let best = null, bs = -1e9;
  for (const o of W.inter) {
    if (!o.on) continue; _d.subVectors(o.pos, c.position); const d = _d.length(); if (d > o.reach) continue;
    const dot = _d.dot(_f) / Math.max(d, 1e-3); if (dot < (d < 1.3 ? .35 : .78)) continue;
    const s = dot * 3 - d * .25 + (o.prio || 0); if (s > bs) { bs = s; best = o; }
  }
  return best;
}
