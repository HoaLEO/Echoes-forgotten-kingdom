// ============================================================================
// Game data and state: items, notes, inventory, objectives
// ============================================================================
const ITEMS = {
  frag_root: { name: 'Fragment of the Root', cat: 'Relic Fragments', icon: 'relic', hex: '#7dff9a', desc: 'One third of the Heartstone of Elvareth, entrusted to the Gardeners of the Whispering Forest. It is warm, and smells faintly of rain on moss. The Echo Gate will know it.' },
  frag_tide: { name: 'Fragment of the Tide', cat: 'Relic Fragments', icon: 'relic', hex: '#6fe6ff', desc: 'One third of the Heartstone, kept by the Tide-Keepers behind a door that only light could open. Hold it to your ear and you hear a slow sea.' },
  frag_sky: { name: 'Fragment of the Sky', cat: 'Relic Fragments', icon: 'relic', hex: '#ffd070', desc: 'One third of the Heartstone, raised by the Astronomers to the top of the world. Tiny points of light drift inside it like a remembered night.' },
  key_verdant: { name: 'Verdant Key', cat: 'Ancient Keys', icon: 'key', hex: '#8fe88a', desc: 'A bronze key overgrown with living moss; its teeth are cut like waves. The Gardeners held it in trust for the Tide-Keepers. It opens the temple door in the east wall of the Courtyard.' },
  key_star: { name: 'Star Key', cat: 'Ancient Keys', icon: 'key', hex: '#cfd8ff', desc: 'A silver key whose bow is a seven-pointed star. It opens the barred stair in the north wall of the Courtyard, which climbs to the Celestial Sanctuary.' },
  lens: { name: 'Crystal Lens', cat: 'Puzzle Items', icon: 'lens', hex: '#7fe9ff', desc: 'A disc of flawless prism-glass in a brass ring. The lamp in the Chamber of Mirrors is blind without it.' },
  seal_king: { name: 'Seal of the Last King', cat: 'Hidden Artifacts', icon: 'seal', hex: '#ffcf7a', desc: 'A royal seal of gold. Around the rim: “I did not flee. I carried them.”' },
  seal_garden: { name: 'Seal of the Gardener', cat: 'Hidden Artifacts', icon: 'seal', hex: '#8fe88a', desc: 'A seal pressed with a single leaf. The Gardeners marked each tree they planted with it; the forest is their signature.' },
  seal_tide: { name: 'Seal of the Tide-Keeper', cat: 'Hidden Artifacts', icon: 'seal', hex: '#6fe6ff', desc: 'A seal the colour of deep water. The Keepers let the temple flood on purpose: “What the tide guards, no thief can carry.”' },
  seal_astro: { name: 'Seal of the Astronomer', cat: 'Hidden Artifacts', icon: 'seal', hex: '#d9b8ff', desc: 'A seal engraved with the sky as it stood on the night of the Sealing. The Astronomers swore the stars would keep the count of years.' },
};
const NOTES = {
  founding: { title: 'The Founding Stone', cat: 'Lore', text: 'Here stood ELVARETH, kingdom of the three callings: Root, Tide and Sky.\n\nWhen the Withering came upon the land, the Last King opened the Echo Gate and led his people through it into the quiet beyond the world.\n\nHe broke the Heartstone in three, that none unworthy might follow: one fragment to the Gardeners of the Forest, one to the Keepers of the drowned Temple, one to the Astronomers upon the mountain.\n\nReturn the three to the Gate, traveller, and the echoes will answer.' },
  templedoor: { title: 'Inscription at the Temple Door', cat: 'Clues', text: 'The door of the Tide-Keepers answers only the VERDANT KEY.\n\nThe Gardeners keep it for us in the western forest — down the narrow path the blue caps light, where the stone watcher is looking.' },
  stairgate: { title: 'Inscription at the Barred Stair', cat: 'Clues', text: 'The stair to the stars is barred by the STAR KEY.\n\nIt lies in the hidden vault of the Sunken Temple. No hand opens that vault. Only light does.' },
  cellar: { title: "A Warden's Scratched Note", cat: 'Clues', text: 'To whoever keeps the watch after me:\n\nThe King\'s cellar is behind the eye in the south wall. It opens to the hand that finds the iron branch — look among the roots behind the elder tree, in the corner where the morning comes last.' },
  crypt: { title: "The King's Cellar", cat: 'Lore', text: 'They will say I abandoned the land. Let them.\n\nThe Withering takes what is rooted, what flows and what shines — it took the harvest, then the river, then the lamps. It cannot take an echo.\n\nSo I have made us into one. On the far side of the Gate we are safe, and we are waiting. I leave the way open to anyone patient enough to gather what I scattered.' },
  song: { title: 'The Song of Seasons', cat: 'Clues', text: 'Carved at the edge of the rune glade:\n\nFirst the ROOT, that drinks in the dark.\nThen the WAVE, that comes to feed it.\nThen the SUN, that raises it green.\nThen the MOON, that grants it rest.\nLast the STAR, that remembers all.\n\nWake the stones as the seasons wake the world, and the bud will open.' },
  lament: { title: "The Gardener's Lament", cat: 'Lore', text: 'We planted ten thousand trees to hold the Withering back, and it worked — here. Only here.\n\nWhen the King asked for volunteers to stay behind and hide the fragment, every Gardener raised a hand. The forest was the only child we had.\n\nIf you take the fragment, take it gently. The trees are listening.' },
  lamp: { title: 'Stele of the Causeway', cat: 'Clues', text: 'Pilgrim: the lamp of the temple is blind without its LENS.\n\nThe Keepers stored the lens in the low vault. From the great hall, take the south door and go down; do not mind the water.' },
  mirrors: { title: 'Rule of the Chamber of Mirrors', cat: 'Clues', text: 'Seat the lens in the lamp. Then turn the mirrors until the light walks:\n\nfirst NORTH,\nthen EAST,\nthen SOUTH, into the Eye.\n\nStone drinks light — a beam that meets a pillar goes no further. One mirror in this room has never been needed.' },
  keepers: { title: "Tide-Keepers' Ledger", cat: 'Lore', text: 'Third year of the Withering. The river no longer reaches the sea, so we have brought the sea to the temple instead and let the lower halls drown.\n\nThe fragment is sealed in the north vault behind the Eye. The Star Key lies with it; the Astronomers asked us to hide their key, as the Gardeners hide ours. No calling holds its own lock. That was the King\'s idea, and it is a good one.' },
  tide: { title: 'The Vault Behind the Eye', cat: 'Lore', text: 'If you are reading this, you made the light walk. Good.\n\nTake the fragment, and take the Star Key up the mountain. The Astronomers will make you move the sky with your own hands before they give up theirs. They always did love a ceremony.' },
  astrolabe: { title: 'The Astrolabe Stone', cat: 'Clues', text: 'Set the heavens as they stood on the night of the Sealing.\n\nThree star-stones lie scattered on this summit: SUN, MOON and STAR. Three plates wait around the orrery, and each plate bears its sign.\n\nTake hold of a stone and walk it to its own plate. Any stone will wake a plate — but only the true sky opens the orrery.\n\nShould a stone be lost to you, the Rune of Return will call them all home.' },
  lastnight: { title: "The Astronomer's Last Entry", cat: 'Lore', text: 'Final night. The King has gone through with the last of the children. From up here the Gate is a single green spark in the courtyard.\n\nWe have fixed the orrery to that sky, so the fragment will only come down for someone who can read it.\n\nI wonder who you are. I wonder how long it has been. Tell them, when you see them, that we kept counting.' },
};
const G = {
  mode: 'title', inv: {}, notes: [], flags: {}, placed: {}, time: 0, region: '',
  has(id) { return !!G.inv[id]; },
  give(id) { G.inv[id] = true; const it = ITEMS[id]; AU.sfx(it.icon === 'relic' ? 'relic' : 'pickup'); UI.toast('Obtained — ' + it.name, 'item'); UI.refresh(); },
  take(id) { delete G.inv[id]; UI.refresh(); },
  flag(k) { if (!G.flags[k]) { G.flags[k] = true; UI.refresh(); } },
  readNote(id) { const n = NOTES[id]; AU.sfx('page'); const isNew = !G.notes.includes(id); if (isNew) G.notes.push(id); UI.read(n.title, n.text, isNew ? 'Recorded in your journal — ' + n.cat : ''); UI.refresh(); },
  fragCount() { let c = 0; for (const f of ['frag_root', 'frag_tide', 'frag_sky']) if (G.inv[f] || G.placed[f]) c++; return c; },
  placedCount() { return Object.keys(G.placed).length; },
  secrets() { let c = 0; for (const k in G.inv) if (ITEMS[k].cat === 'Hidden Artifacts') c++; return c; },
  objectives() {
    const got = f => !!(G.inv[f] || G.placed[f]), F = G.flags;
    return [
      { t: 'Explore the Forgotten Courtyard and read the Founding Stone', d: G.notes.includes('founding') || G.fragCount() > 0 },
      { t: 'Whispering Forest — wake the rune stones and recover the Fragment of the Root', d: got('frag_root') },
      { t: 'Find the Verdant Key and open the temple door in the east wall', d: !!F.door_temple },
      { t: 'Sunken Temple — guide the light into the Eye and recover the Fragment of the Tide', d: got('frag_tide') },
      { t: 'Open the barred stair in the north wall with the Star Key', d: !!F.door_stair },
      { t: 'Celestial Sanctuary — align the star-stones and recover the Fragment of the Sky', d: got('frag_sky') },
      { t: 'Return to the Echo Gate and set the three fragments in their sockets', d: G.placedCount() === 3 },
      { t: 'Awaken the Echo Gate', d: !!F.finale },
    ];
  },
};
