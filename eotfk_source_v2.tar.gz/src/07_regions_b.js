// ============================================================================
// Regions (part B): the Sunken Temple, the Celestial Sanctuary, global scenery
// ============================================================================
// axis-aligned masonry wall made of coursed blocks, one collider
function wall(rg, x0, z0, x1, z1, y0, h, th, o = {}) {
  const alongX = Math.abs(x1 - x0) > Math.abs(z1 - z0), len = alongX ? Math.abs(x1 - x0) : Math.abs(z1 - z0), cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
  const nc = Math.max(1, Math.round(h / 2.3)), ch = h / nc;
  for (let c = 0; c < nc; c++) { const nb = Math.max(1, Math.round(len / 3.2)), bl = len / nb; for (let b = 0; b < nb; b++) { const off = -len / 2 + (b + .5) * bl, t = th * (c === 0 ? 1.08 : .96 + RND() * .06); stone(rg, alongX ? cx + off : cx, y0 + c * ch, alongX ? cz : cz + off, alongX ? bl - .03 : t, ch - .03, alongX ? t : bl - .03, { col: false, chip: .07, aoH: c === 0 ? 1.6 : .01, v: o.v }); } }
  const core = new T.BoxGeometry(alongX ? len : th * .55, h - .1, alongX ? th * .55 : len).translate(cx, y0 + h / 2, cz); paint(core, () => [.02, .035, .035]); S(rg, MATFOR[rg], core);   // light-tight core behind the chipped blocks
  addBox(cx, cz, alongX ? len / 2 : th / 2, alongX ? th / 2 : len / 2, y0, y0 + h);
}
const LIGHT = { mirrors: [], on: false, solved: false, hold: 0, segs: [] };
function buildTemple() {
  const rg = 'temple', F = TFLOOR, B = -2.3, th = (x, z) => terrainH(x, z);
  // approach
  for (let i = 0; i < 9; i++) { const x = 23.4 + i * 1.25; stone(rg, x, th(x, 0) - .14, 0, 1.15, .2, 4.8 - (i % 3) * .3, { col: false, chip: .06, aoH: .01 }); }
  ruinWall(rg, 23.2, -5.6, 33, -7, 4.4); ruinWall(rg, 23.2, 5.6, 33, 7, 3.8);
  makeWater(28, 100, -24, 24, WATER_Y, '#17786f', 55.5);
  // causeway
  for (const [x0, x1, top] of [[32.6, 34.8, -1.62], [34.8, 37, -1.36], [37, 41.6, F], [41.95, 46, F], [47.75, 51.6, F], [51.95, 55.6, F]]) stone(rg, (x0 + x1) / 2, top - .7, 0, x1 - x0, .7, 3.4, { chip: .12 });
  stone(rg, 46.9, -2.25, 1.6, 2.2, .5, 2.8, { rz: .32, yaw: .5, col: false, chip: .14 });
  stone(rg, 44, B, -3.1, 2.8, F - B, 2.8, { chip: .12 }); tablet(rg, 44, -3.5, 0, 'lamp', { y: F });
  const brk = [.5, 1, .3, 1, .75, 1]; let bi = 0;
  for (const z of [-8.5, 8.5]) for (const x of [37.5, 43.5, 49.5]) { column(rg, x, B, z, .62, 7.4, { broken: brk[bi++] }); crystalCluster(x + .9, -1.9, z + (z < 0 ? .8 : -.8), '#49f0d0', 2, .55, { light: false }); }
  fallenDrum(rg, 40.6, -11.2, .58, 2.8, .4, { y: -2.1 }); statue(rg, 53.4, -6.4, -Math.PI / 2, { y: -2.2, s: 1.45 }); statue(rg, 53.4, 6.4, -Math.PI / 2, { y: -2.2, s: 1.45 });
  glow(43.5, -1.2, -7.5, '#49f0d0', .8, 14); glow(43.5, -1.2, 7.5, '#49f0d0', .8, 14); crystalCluster(40.4, F, -1.2, '#49f0d0', 2, .5, { power: .5 }); crystalCluster(50, F, 1.2, '#49f0d0', 2, .5, { power: .5 }); crystalCluster(54.6, -2, -10.6, '#3fb8ff', 3, 1.1, { power: .7 }); crystalCluster(54.6, -2, 10.6, '#3fb8ff', 3, 1.1, { power: .7 });
  for (let i = 0; i < 26; i++) { const x = 33 + RND() * 21, z = (RND() < .5 ? -1 : 1) * (2.6 + RND() * 11), g = new T.CylinderGeometry(.16 + RND() * .16, .16, .02, 9).translate(x, WATER_Y + .02, z); const c = col(RND() < .5 ? '#1f5a34' : '#2c7040'); paint(g, () => c); S(rg, 'lily', g); }
  pedestal(rg, 51.6, -2.3, 12.6, .75, .3); pickup(sealMesh('#6fe6ff'), 51.6, -1.3, 12.6, 'Take the sunken seal', '#6fe6ff', () => G.give('seal_tide'));
  rock(rg, 35, -12.5, 1.4, { y: -2.2 }); rock(rg, 36, 12, 1.2, { y: -2.2 }); rock(rg, 49, -13.2, 1.0, { y: -2.2 });
  // ---- facade + great hall (interior x 56.5..74.5, z -9..9)
  const WT = 6.4 - B;
  wall(rg, 56, -10, 56, -1.9, B, WT, 1); wall(rg, 56, 1.9, 56, 10, B, WT, 1); stone(rg, 56, F + 3.5, 0, 1.15, 6.4 - F - 3.5, 3.9, { col: false });
  for (const z of [-7.6, -3.6, 3.6, 7.6]) column(rg, 54.5, B, z, .7, 8.6);
  stone(rg, 55, 6.4, 0, 3.6, .9, 21.5, { col: false }); stone(rg, 55, 7.3, 0, 2.6, 1.3, 13, { col: false, chip: .2 });
  wall(rg, 55.5, -9.5, 76, -9.5, B, WT, 1); wall(rg, 55.5, 9.5, 63.4, 9.5, B, WT, 1); wall(rg, 66.6, 9.5, 76, 9.5, B, WT, 1); stone(rg, 65, F + 2.9, 9.5, 3.3, 6.4 - F - 2.9, 1.05, { col: false });
  wall(rg, 75.25, -11.2, 75.25, -1.9, B, 7.2 - B, 1.5); wall(rg, 75.25, 1.9, 75.25, 11.2, B, 7.2 - B, 1.5); stone(rg, 75.25, F + 3.5, 0, 1.55, 7.2 - F - 3.5, 3.9, { col: false });
  stone(rg, 58, B, 0, 5, F - B, 18.2); stone(rg, 65.25, B, -5.15, 9.5, F - B, 7.7); stone(rg, 65.25, B, 5.15, 9.5, F - B, 7.7); stone(rg, 72.25, B, 0, 4.5, F - B, 18.2); stone(rg, 75.25, B, 0, 1.6, F - B, 3.8);
  stone(rg, 65.3, F - .42, 0, 1.9, .42, 2.7, { chip: .1 });
  for (const z of [-5, 5]) for (const x of [60, 65, 70]) column(rg, x, F, z, .52, 7.4);
  stone(rg, 65.75, 6.4, -5.6, 20.6, .7, 8.9, { col: false }); stone(rg, 65.75, 6.4, 5.6, 20.6, .7, 8.9, { col: false });
  stone(rg, 58.4, 6.4, 0, 5.8, .7, 2.4, { col: false }); stone(rg, 65.25, 6.4, 0, 3.1, .7, 2.4, { col: false }); stone(rg, 72.6, 6.4, 0, 6.8, .7, 2.4, { col: false });
  shaft(66.75, F - .5, -5.27, 11, 2.2, '#bfffee', .22); shaft(72.25, F - .5, -5.27, 11, 2.2, '#bfffee', .22);
  crystalCluster(57.6, F, -8, '#49f0d0', 3, .9, { power: .7 }); crystalCluster(73.4, F, 8, '#49f0d0', 3, .9, { power: .7 }); crystalCluster(57.6, F, 8, '#3fb8ff', 2, .7, { light: false });
  spirit(61.6, 5.6, 'Keeper Maru', '#7ff0e0', () => LIGHT.solved
    ? ['The Eye is open. I had forgotten that sound.', 'The Star Key in the vault is not ours — we kept it for the Astronomers. Take it to the barred stair in the courtyard\'s north wall.']
    : LIGHT.on ? ['The lamp sees again. Now teach the light to walk.', 'North, then east, then south into the Eye. Turn each mirror until the beam leaves it the way you need.', 'And mind the pillar. Stone drinks light.']
      : ['Wet feet and a living voice. Welcome to what is left of the tide.', 'Beyond the east door is the Chamber of Mirrors. Its lamp is blind — the lens is in the low vault, through the south door of this hall and down.', 'Bring the lens to the lamp. Then we shall see what you are made of.'], { y: F });
  // ---- south corridor and the lens vault (flooded)
  stone(rg, 65, B, 9.5, 3.2, F - B, 1.1); stone(rg, 65, B, 11, 3.2, .95, 2); stone(rg, 65, B, 13.25, 3.2, .7, 2.6); stone(rg, 65, B, 18.2, 12.6, .68, 7.6);
  wall(rg, 62.9, 10, 62.9, 13.8, B, 5, 1); wall(rg, 67.1, 10, 67.1, 13.8, B, 5, 1); wall(rg, 58, 14.1, 63.4, 14.1, B, 5, .9); wall(rg, 66.6, 14.1, 72, 14.1, B, 5, .9);
  wall(rg, 58.4, 14, 58.4, 22.4, B, 5, .9); wall(rg, 71.6, 14, 71.6, 22.4, B, 5, .9); wall(rg, 58, 22, 72, 22, B, 5, .9);
  stone(rg, 65, 2.5, 12, 5.4, .6, 4.6, { col: false }); stone(rg, 65, 2.5, 18.2, 14.4, .6, 8.8, { col: false });
  pedestal(rg, 65, -1.62, 19.8, 1.05, .32); pickup(lensMesh(), 65, -.2, 19.8, 'Take the Crystal Lens', '#7fe9ff', () => G.give('lens'));
  tablet(rg, 60.3, 20.6, 2.2, 'keepers', { y: -1.62, hex: '#7ff0e0' }); crystalCluster(69.8, -1.62, 20.4, '#49f0d0', 3, .8, { power: .6 }); crystalCluster(60, -1.62, 15.6, '#3fb8ff', 2, .6, { power: .4 });
  // ---- chamber of mirrors (interior x 76..96, z -10..10)
  const CT = 7.2 - B;
  wall(rg, 75.5, -10.6, 84.4, -10.6, B, CT, 1.2); wall(rg, 87.6, -10.6, 97.2, -10.6, B, CT, 1.2); stone(rg, 86, F + 3.4, -10.6, 3.3, 7.2 - F - 3.4, 1.25, { col: false });
  wall(rg, 75.5, 10.6, 97.2, 10.6, B, CT, 1.2); wall(rg, 96.6, -11.2, 96.6, 11.2, B, CT, 1.2);
  stone(rg, 86, B, 0, 20, F - B, 20.2);
  stone(rg, 80, 7.2, 0, 10, .7, 22.6, { col: false }); stone(rg, 92.1, 7.2, 0, 10.2, .7, 22.6, { col: false }); stone(rg, 86, 7.2, -6.15, 2, .7, 10.3, { col: false }); stone(rg, 86, 7.2, 6.15, 2, .7, 10.3, { col: false });
  shaft(90.7, F - .5, -5.8, 12, 1.9, '#bfffee', .2);
  column(rg, 89, F, 4, .55, 8.2); column(rg, 80, F, -4, .55, 8.2);
  tablet(rg, 77.3, -3.4, Math.PI / 2, 'mirrors', { y: F, hex: '#7ff0e0' });
  crystalCluster(95, F, 9, '#3fb8ff', 3, .9, { power: .6 }); crystalCluster(77, F, 9, '#3fb8ff', 3, .8, { power: .6 }); crystalCluster(95, F, -9, '#49f0d0', 3, .8, { power: .6 }); crystalCluster(77.2, F, -8.8, '#49f0d0', 2, .7, { power: .5 });
  buildLightPuzzle(rg, F);
  // ---- hidden vault behind the Eye (interior x 82..90, z -19..-11.2)
  stone(rg, 86, B, -10.6, 3.2, F - B, 1.3); stone(rg, 86, B, -15.2, 8.2, F - B, 8);
  wall(rg, 81.5, -19.6, 81.5, -11.2, B, 5.6, 1); wall(rg, 90.5, -19.6, 90.5, -11.2, B, 5.6, 1); wall(rg, 81, -19.5, 91, -19.5, B, 5.6, 1); stone(rg, 86, 3.3, -15.4, 10.2, .6, 9.4, { col: false });
  pedestal(rg, 86, F, -17, 1.05, .34); pedestal(rg, 88.7, F, -13.6, .9, .28);
  LIGHT.relic = pickup(relicMesh('#6fe6ff'), 86, F + 1.6, -17, 'Take the Fragment of the Tide', '#6fe6ff', () => { G.give('frag_tide'); UI.toast('A slow sea moves inside the stone. The second fragment is yours.', 'good'); }, { on: false });
  LIGHT.key = pickup(keyMesh('#cfd8ff'), 88.7, F + 1.35, -13.6, 'Take the Star Key', '#cfd8ff', () => G.give('key_star'), { on: false });
  tablet(rg, 83.1, -16.6, Math.PI / 2, 'tide', { y: F, hex: '#7ff0e0' }); crystalCluster(89.2, F, -18.4, '#49f0d0', 3, .8, { power: .5 }); crystalCluster(82.8, F, -12.2, '#49f0d0', 2, .6, { light: false });
  makeMotes(340, r => [32 + r() * 64, -1.2 + r() * 4.5, -14 + r() * 28], '#7fffe0', .045);
}
function buildLightPuzzle(rg, F) {
  const L = LIGHT, BY = F + 1.35;
  L.y = BY; L.origin = [78.75, 4]; L.target = [92, 5, .55]; L.blockers = [[89, 4, .68], [80, -4, .68]]; L.bounds = [76, 96, -10, 10];
  // lamp
  stone(rg, 78, F, 4, 1.1, .95, 1.1, { chip: .1 }); stone(rg, 78, F + .95, 4, .8, .85, .8, { col: false, chip: .08 });
  const lampLens = lensMesh(); lampLens.position.set(78.45, BY, 4); lampLens.rotation.y = Math.PI / 2; lampLens.visible = false; W.scene.add(lampLens);
  const lampGlow = glow(78.9, BY, 4, '#9ff4ff', 0, 8);
  const lamp = addInter({ pos: new V3(78.3, BY, 4), reach: 3.2, get label() { return L.on ? '' : G.has('lens') ? 'Seat the Crystal Lens in the lamp' : 'Examine the blind lamp'; },
    use() { if (L.on) return; if (!G.has('lens')) { UI.toast('A stone lamp with an empty ring where a lens should sit. Without it the light cannot leave.', 'hint'); AU.sfx('deny'); return; }
      G.take('lens'); L.on = true; lamp.on = false; lampLens.visible = true; lampGlow.power = .8; AU.sfx('place'); AU.sfx('beam'); burst(lamp.pos, '#9ff4ff', 50, 2.5, 1.2); UI.toast('The lens catches a light that was never quite gone. A beam leaps across the chamber.', 'good'); G.flag('lamp_lit'); } });
  // mirrors: [x, z, initial step]; angle = step * 45deg, mirror line direction u = (cos a, sin a) in (x,z)
  const mm = new T.MeshStandardMaterial({ color: '#bfeef2', metalness: .95, roughness: .1, emissive: '#1d7f8a', emissiveIntensity: .22 });
  const fm = MATS.metal;
  for (const [x, z, k0] of [[84, 4, 0], [84, -5, 1], [92, -5, 2], [88, -1, 0]]) {
    cyl(rg, x, F, z, .42, .36, .85, { seg: 8 }); addCyl(x, z, .5, F, F + .85);
    const g = new T.Group(); g.position.set(x, F + .85, z);
    // crystal reflector: a faceted hexagonal pane in a bronze ring, each with its own hue (the beam takes the colour of the last pane it left)
    const hue = ['#ff6ad5', '#6fe6ff', '#ffb347', '#b08cff'][L.mirrors.length], hc = new T.Color(hue);
    const cmat = new T.MeshStandardMaterial({ color: hc.clone().lerp(new T.Color('#ffffff'), .55), metalness: .85, roughness: .12, emissive: hc, emissiveIntensity: .55, flatShading: true });
    const post = new T.Mesh(new T.CylinderGeometry(.07, .11, .34, 6).translate(0, .12, 0), fm), plate = new T.Mesh(new T.CylinderGeometry(.9, .9, .07, 6).rotateX(Math.PI / 2).rotateZ(Math.PI / 6).scale(1, .72, 1).translate(0, .78, 0), cmat),
      frame = new T.Mesh(new T.TorusGeometry(.95, .045, 5, 6).rotateZ(Math.PI / 6).scale(1, .72, 1).translate(0, .78, 0), fm), fin = new T.Mesh(new T.OctahedronGeometry(.11, 0).scale(1, 1.8, 1).translate(0, 1.6, 0), new T.MeshBasicMaterial({ color: hc.clone().multiplyScalar(2.6) }));
    const foot = new T.Mesh(new T.TorusGeometry(.4, .04, 5, 8).rotateX(Math.PI / 2).translate(0, .02, 0), fm);
    g.add(post, plate, frame, fin, foot); g.rotation.y = -k0 * Math.PI / 4; W.scene.add(g); glow(x, F + 1.7, z, hue, .32, 5);
    const m = { x, z, k: k0, a: k0 * Math.PI / 4, g, spin: false, hue: hc };
    m.inter = addInter({ pos: new V3(x, F + 1.5, z), reach: 3, label: 'Turn the mirror', use() { if (L.solved || m.spin) return; m.spin = true; m.k++; const a0 = m.a, a1 = m.k * Math.PI / 4; AU.sfx('mirror'); tween(.45, k => { m.a = lerp(a0, a1, k); g.rotation.y = -m.a; }, () => { m.a = a1; m.spin = false; }); } });
    L.mirrors.push(m);
  }
  // the Eye (target)
  pedestal(rg, 92, F, 5, .95, .34); const eye = crystal(92, BY + .05, 5, 1.1, '#3a6a70', { own: true, ei: .25, light: false, tilt: 0 }); eye.halo.material.opacity = .15;
  const eyeGlow = glow(92, BY, 5, '#9ff4ff', 0, 10); L.eye = eye; L.eyeGlow = eyeGlow;
  // beam visuals
  const cm = new T.MeshBasicMaterial({ color: new T.Color(2.4, 5.5, 6.5) }), hm = new T.MeshBasicMaterial({ color: new T.Color(.25, .8, 1), transparent: true, opacity: .32, blending: T.AdditiveBlending, depthWrite: false });
  for (let i = 0; i < 8; i++) { const c = new T.Mesh(new T.CylinderGeometry(.03, .03, 1, 6).rotateX(Math.PI / 2), cm.clone()), h = new T.Mesh(new T.CylinderGeometry(.11, .11, 1, 8).rotateX(Math.PI / 2), hm.clone()); c.visible = h.visible = false; const sp = makeHalo('#9ff4ff', .9, .9); sp.visible = false; W.scene.add(c, h, sp); L.segs.push({ c, h, sp }); }
  L.hitGlow = glow(0, BY, 0, '#9ff4ff', 0, 7);
  L.door = slabDoor(rg, 86, F - .2, -10.6, 3.2, 3.6, .7, 0, 'g_eye', '#7ff0e0');
  W.updaters.push(dt => updateLight(dt));
}
// geometric beam tracing: ray vs mirror segments / pillar circles / target circle / room walls
function traceBeam() {
  const L = LIGHT, pts = [[L.origin[0], L.origin[1]]]; let ox = L.origin[0], oz = L.origin[1], dx = 1, dz = 0, hit = false, last = null;
  for (let b = 0; b < 8; b++) {
    let bt = 1e9, kind = null, mir = null;
    for (const m of L.mirrors) { if (m === last) continue; const ux = Math.cos(m.a), uz = Math.sin(m.a), den = dx * uz - dz * ux; if (Math.abs(den) < 1e-5) continue; const wx = m.x - ox, wz = m.z - oz, t = (wx * uz - wz * ux) / den, s = (wx * dz - wz * dx) / den; if (t > 1e-3 && Math.abs(s) <= .9 && t < bt) { bt = t; kind = 'm'; mir = m; } }
    const circ = (cx, cz, r, k) => { const fx = ox - cx, fz = oz - cz, bq = fx * dx + fz * dz, cq = fx * fx + fz * fz - r * r, disc = bq * bq - cq; if (disc < 0) return; const t = -bq - Math.sqrt(disc); if (t > 1e-3 && t < bt) { bt = t; kind = k; mir = null; } };
    for (const c of L.blockers) circ(c[0], c[1], c[2], 'b'); circ(L.target[0], L.target[1], L.target[2], 't');
    const [x0, x1, z0, z1] = L.bounds; for (const t of [dx > 0 ? (x1 - ox) / dx : dx < 0 ? (x0 - ox) / dx : 1e9, dz > 0 ? (z1 - oz) / dz : dz < 0 ? (z0 - oz) / dz : 1e9]) if (t > 1e-3 && t < bt) { bt = t; kind = 'w'; mir = null; }
    ox += dx * bt; oz += dz * bt; pts.push([ox, oz]);
    if (kind === 't') { hit = true; break; } if (kind !== 'm') break;
    const ux = Math.cos(mir.a), uz = Math.sin(mir.a), nx = -uz, nz = ux, dn = dx * nx + dz * nz; dx -= 2 * dn * nx; dz -= 2 * dn * nz; last = mir;
  }
  return { pts, hit };
}
function updateLight(dt) {
  const L = LIGHT; if (!L.on) return;
  const r = traceBeam(), n = r.pts.length - 1;
  for (let i = 0; i < L.segs.length; i++) {
    const s = L.segs[i], vis = i < n; s.c.visible = s.h.visible = s.sp.visible = vis; if (!vis) continue;
    const a = r.pts[i], b = r.pts[i + 1], len = Math.hypot(b[0] - a[0], b[1] - a[1]);
    for (const m of [s.c, s.h]) { m.position.set((a[0] + b[0]) / 2, L.y, (a[1] + b[1]) / 2); m.scale.set(1, 1, len); m.rotation.y = Math.atan2(b[0] - a[0], b[1] - a[1]); }
    s.sp.position.set(b[0], L.y, b[1]);
    // colour: white-cyan from the lamp, then the hue of the reflector the segment leaves
    let hue = null; if (i > 0) for (const m of L.mirrors) if (Math.hypot(m.x - a[0], m.z - a[1]) < 1.05) hue = m.hue;
    if (hue) { s.c.material.color.copy(hue).multiplyScalar(3.4).addScalar(1.1); s.h.material.color.copy(hue); s.sp.material.color.copy(hue); } else { s.c.material.color.setRGB(2.4, 5.5, 6.5); s.h.material.color.setRGB(.25, .8, 1); s.sp.material.color.set('#9ff4ff'); }
  }
  const e = r.pts[Math.min(n, 2)]; L.hitGlow.pos.set(e[0], L.y, e[1]); L.hitGlow.power = .5;
  if (L.solved) return;
  const steady = r.hit && !L.mirrors.some(m => m.spin);
  L.hold = steady ? L.hold + dt : 0; L.eye.mat.emissiveIntensity = r.hit ? 1.6 + L.hold * 3 : .25; L.eye.mat.emissive.set(r.hit ? '#9ff4ff' : '#3a6a70');
  if (L.hold > .7) {
    L.solved = true; L.eye.mat.emissiveIntensity = 4; L.eye.mat.color.set('#9ff4ff'); L.eye.halo.material.opacity = .8; L.eyeGlow.power = 1; for (const m of L.mirrors) m.inter.on = false;
    AU.sfx('solve'); burst(new V3(L.target[0], L.y, L.target[1]), '#9ff4ff', 110, 4, 2); UI.toast('The Eye drinks the light and opens. In the north wall, a hidden door is moving.', 'good'); G.flag('light_solved');
    later(.9, () => { L.door.open(4); L.relic.show(); L.key.show(); });
  }
}

// ---------------------------------------------------------------- THE CELESTIAL SANCTUARY
const PLATES = { stones: [], plates: [], solved: false, hold: 0 };
function buildSanctuary() {
  const rg = 'sanct', cx = MOUNT.x, cz = MOUNT.z, Y = MOUNT.top, PL = PLATES;
  // the mountain stair: worn steps, way-crystals, invisible guard walls
  for (let i = 0; i < MPATH.length - 1; i++) {
    const a = MPATH[i], b = MPATH[i + 1], dx = b[0] - a[0], dz = b[1] - a[1], len = Math.hypot(dx, dz), ux = dx / len, uz = dz / len, yaw = Math.atan2(-dz, dx);
    for (let d = i === 0 ? 3 : .6; d < len; d += 1.25) { const x = a[0] + ux * d, z = a[1] + uz * d; if (Math.hypot(x - cx, z - cz) < 16.5) break; stone(rg, x, terrainH(x, z) - .17, z, .95, .22, 3.5 + (RND() - .5) * .8, { yaw, col: false, chip: .09, aoH: .01, tint: i < 2 ? TINT.court : TINT.sanct, mat: i < 2 ? 'stone' : 'stoneS' }); }
    const s0 = i === 0 ? 5 : -2.4, s1 = i === MPATH.length - 2 ? len : len + 2.4, mid = (s0 + s1) / 2, hl = (s1 - s0) / 2;
    for (const sd of [-1, 1]) addBox(a[0] + ux * mid - uz * sd * 4.1, a[1] + uz * mid + ux * sd * 4.1, hl, .4, Math.min(a[2], b[2]) - 6, Math.max(a[2], b[2]) + 8, yaw);
    for (let d = 7; d < len - 3; d += 13) { const sd = (Math.round(d / 13) + i) % 2 ? 1 : -1, x = a[0] + ux * d - uz * sd * 2.7, z = a[1] + uz * d + ux * sd * 2.7, y = terrainH(x, z); stone(rg, x, y - .3, z, .5, 1.3, .5, { col: false, chip: .1, tint: TINT.sanct, mat: 'stoneS' }); crystal(x, y + 1.35, z, .55, '#ffc86a', { power: .5, range: 8 }); rock('sanct', x - uz * sd * 1.4, z + ux * sd * 1.4, .7 + RND() * .7, { tint: '#b99a72', mat: 'stoneS' }); }
  }
  arch(rg, 21.6, terrainH(21.6, -28.5) - .3, -28.5, 4.6, 3.8, 1.3, Math.atan2(-18, 16), { tint: TINT.court, mat: 'stone' });
  arch(rg, 26.5, terrainH(26.5, -87.3) - .3, -87.3, 4.6, 4, 1.3, Math.atan2(14, 10), { broken: -1 });
  for (let k = 0; k < 30; k++) { const a = (k + .5) / 30 * TAU; const an = Math.atan2(Math.sin(a), Math.cos(a)); if (an > -.2 && an < .37) continue; addBox(cx + Math.cos(a) * 18, cz + Math.sin(a) * 18, .4, 2.1, Y - 6, Y + 9, -a); }
  // paving rings
  for (let r = 3.6; r < 16.6; r += 1.58) { const n = Math.round(TAU * r / 1.72); for (let k = 0; k < n; k++) { if (RND() < .1 + .25 * sstep(11, 16, r)) continue; const a = (k + (r * 7 % 1)) / n * TAU; stone(rg, cx + Math.cos(a) * r, Y - .1, cz + Math.sin(a) * r, 1.5, .14, 1.56, { yaw: -a, col: false, chip: .05, aoH: .01, v: .8 + .25 * ((Math.round(r / 1.58) % 2)) }); } }
  // astrolabe engraving
  for (const [r, w] of [[4.7, .07], [9.1, .09], [10.4, .05]]) { const m = new T.Mesh(new T.RingGeometry(r - w, r + w, 72).rotateX(-Math.PI / 2), new T.MeshBasicMaterial({ color: new T.Color('#ffc86a').multiplyScalar(1.3), transparent: true, opacity: .8, blending: T.AdditiveBlending, depthWrite: false })); m.position.set(cx, Y + .07, cz); W.scene.add(m); }
  // dais + orrery
  cyl(rg, cx, Y - .1, cz, 3.0, 2.9, .34, { seg: 24 }); cyl(rg, cx, Y + .24, cz, 2.35, 2.25, .22, { seg: 24 }); addCyl(cx, cz, 3.0, Y - 2, Y + .24, { walk: true }); addCyl(cx, cz, 2.35, Y - 2, Y + .46, { walk: true });
  cyl(rg, cx, Y + .46, cz, .55, .42, 1.25, { seg: 10 }); addCyl(cx, cz, .8, Y, Y + 3.4);
  const orr = new T.Group(); orr.position.set(cx, Y + 2.75, cz); W.scene.add(orr); const rings = [];
  for (let i = 0; i < 3; i++) { const m = new T.Mesh(new T.TorusGeometry(.78 + i * .22, .035, 6, 40), MATS.metal); m.rotation.set(i * 1.1, i * .7, 0); m.castShadow = true; orr.add(m); rings.push(m); }
  const cage = new T.Mesh(new T.IcosahedronGeometry(.52, 1), new T.MeshBasicMaterial({ color: new T.Color('#ffc86a').multiplyScalar(1.4), wireframe: true, transparent: true, opacity: .7 })); orr.add(cage);
  const core = relicMesh('#ffd070'); core.scale.setScalar(.8); orr.add(core);
  const orrGlow = glow(cx, Y + 2.75, cz, '#ffd070', .6, 10);
  W.updaters.push((dt, t) => { const sp = PL.solved ? 2.6 : .35; rings[0].rotation.x += dt * sp; rings[1].rotation.y += dt * sp * .8; rings[2].rotation.z += dt * sp * .6; rings[2].rotation.x += dt * sp * .3; cage.rotation.y -= dt * .5; core.rotation.y += dt; });
  PL.relic = pickup(relicMesh('#ffd070'), cx, Y + 2.75, cz, 'Take the Fragment of the Sky', '#ffd070', () => { G.give('frag_sky'); UI.toast('A remembered night turns slowly in your hand. The third fragment is yours.', 'good'); }, { on: false, reach: 4.2 });
  // plates and star-stones
  const defs = [['sun', 7.5, 0, -8.2, 6.6, '#ffb347'], ['moon', -7.5, 0, 7.6, 7.6, '#b8c8ff'], ['star', 0, -7.5, 2.2, 10.9, '#ffe9a0']];
  for (const [name, px, pz, sx, sz, hex] of defs) {
    const x = cx + px, z = cz + pz;
    const pm = new T.Mesh(dynStone(new T.CylinderGeometry(1.08, 1.14, .14, 20), rg), MATS.stoneS); pm.position.set(x, Y + .07, z); pm.receiveShadow = true; W.scene.add(pm);
    const gp = glyphPlane('g_' + name, 1.25, hex, .55); gp.rotation.x = -Math.PI / 2; gp.position.set(x, Y + .16, z); W.scene.add(gp);
    const rg2 = new T.Mesh(new T.RingGeometry(1.0, 1.1, 40).rotateX(-Math.PI / 2), new T.MeshBasicMaterial({ color: hdr(hex, .5), transparent: true, blending: T.AdditiveBlending, depthWrite: false })); rg2.position.set(x, Y + .165, z); W.scene.add(rg2);
    const arm = new T.Mesh(new T.CylinderGeometry(.02, .02, 1.5, 5).rotateZ(Math.PI / 2).translate(.95, 0, 0), MATS.metal); arm.position.set(cx, Y + 1.9, cz); arm.rotation.y = Math.atan2(-pz, px); const orb = glyphPlane('g_' + name, .34, hex, 2); orb.position.set(1.75, 0, 0); orb.rotation.y = Math.PI / 2; arm.add(orb); W.scene.add(arm);
    PL.plates.push({ name, x, z, pm, gp, ring: rg2, hex, gl: glow(x, Y + .5, z, hex, 0, 6), state: -1, y0: Y + .07 });
    // stone
    const sx0 = cx + sx, sz0 = cz + sz, g = new T.Group(); const body = new T.Mesh(dynStone(new T.CylinderGeometry(.56, .62, .95, 10), rg), MATS.stoneS); body.position.y = .475; body.castShadow = body.receiveShadow = true;
    const top = glyphPlane('g_' + name, .85, hex, 1.5); top.rotation.x = -Math.PI / 2; top.position.y = .96; g.add(body, top);
    for (let k = 0; k < 4; k++) { const sgp = glyphPlane('g_' + name, .5, hex, 1.1); sgp.position.set(Math.sin(k * Math.PI / 2) * .625, .5, Math.cos(k * Math.PI / 2) * .625); sgp.rotation.y = k * Math.PI / 2; g.add(sgp); }
    g.position.set(sx0, Y, sz0); W.scene.add(g);
    const st = { name, g, x: sx0, z: sz0, hx: sx0, hz: sz0, col: addCyl(sx0, sz0, .62, Y - 1, Y + .95), top };
    st.inter = addInter({ pos: new V3(sx0, Y + .9, sz0), reach: 2.7, prio: .4, get label() { return P.grab === st ? 'Let go of the ' + name + '-stone' : 'Take hold of the ' + name + '-stone'; }, use() { if (PL.solved) return; if (P.grab === st) { P.grab = null; AU.sfx('thud'); } else { P.grab = st; AU.sfx('grab'); } } });
    PL.stones.push(st);
  }
  PL.Y = Y; W.updaters.push(dt => updatePlates(dt));
  lever(rg, cx + 12.6, Y, cz + 2.2, -Math.PI / 2, 'Touch the Rune of Return', () => { if (PL.solved) return; P.grab = null; for (const s of PL.stones) { burst(new V3(s.x, Y + .5, s.z), '#ffd070', 20, 1.5, 1); s.x = s.hx; s.z = s.hz; } AU.sfx('rune', 2); UI.toast('The star-stones return to where the Astronomers left them.', 'hint'); });
  PL.open = () => { PL.solved = true; P.grab = null; for (const s of PL.stones) s.inter.on = false; AU.sfx('solve'); AU.sfx('stone', 2.5); G.flag('plates_solved'); UI.toast('Sun, Moon and Star stand as they stood on the night of the Sealing. The orrery unlocks.', 'good');
    burst(new V3(cx, Y + 2.75, cz), '#ffd070', 140, 5, 2.4); for (const p of PL.plates) { setGlyph(p.gp, '#9fd8ff', 3); p.ring.material.color.copy(hdr('#9fd8ff', 3)); }
    tween(2.4, k => { cage.scale.setScalar(1 + k * 1.6); cage.material.opacity = .7 * (1 - k); core.scale.setScalar(.8 * (1 - k)); }, () => { cage.visible = core.visible = false; PL.relic.show(); }); };
  // ring of columns, dome ribs, telescope
  const brk = [1, .45, 1, 1, .25, .7, 1, 1, .5, 1, .3, 1];
  for (let k = 0; k < 12; k++) { const a = (k + .5) / 12 * TAU, x = cx + Math.cos(a) * 13, z = cz + Math.sin(a) * 13; column(rg, x, Y - .1, z, .6, 7.2, { broken: brk[k] }); if (brk[k] < .5) rubble(rg, x + Math.cos(a + 1) * 1.6, z + Math.sin(a + 1) * 1.6, 4, 1.1, { y: Y }); }
  for (const k of [0, 2, 3, 6, 7, 9, 11]) { const a = (k + .5) / 12 * TAU, pts = [], full = k % 3 !== 0; for (let i = 0; i <= 10; i++) { const t = i / 10 * (full ? 1 : .55), ang = t * Math.PI / 2, r = 13 * Math.cos(ang); pts.push(new V3(cx + Math.cos(a) * r, Y + 7.7 + Math.sin(ang) * 6.2, cz + Math.sin(a) * r)); } const g = tubeGeom(pts, () => .2, 5, .4); stoneG(rg, g, Y + 7, { aoH: .1 }); }
  stone(rg, cx + 9.6, Y, cz - 9.6, 2.2, 1.3, 2.2, { yaw: .78, chip: .1 }); stone(rg, cx + 9.6, Y + 1.3, cz - 9.6, 1.2, 1.2, 1.2, { yaw: .78, col: false });
  const tel = new T.Group(); tel.position.set(cx + 9.6, Y + 3, cz - 9.6); tel.rotation.set(0, .9, .85);
  const t1 = new T.Mesh(new T.CylinderGeometry(.42, .55, 4.6, 14), MATS.metal), t2 = new T.Mesh(new T.CylinderGeometry(.3, .4, 2.2, 14).translate(0, -3.2, 0), MATS.metal), t3 = new T.Mesh(new T.TorusGeometry(.56, .07, 6, 20).rotateX(Math.PI / 2).translate(0, 2.3, 0), MATS.metal);
  t1.castShadow = t2.castShadow = true; tel.add(t1, t2, t3); W.scene.add(tel);
  pickup(sealMesh('#d9b8ff'), cx + 11.3, Y + .9, cz - 11.3, 'Take the star-engraved seal', '#d9b8ff', () => G.give('seal_astro'));
  // floating crystals
  crystal(cx, Y + 10.2, cz, 3.8, '#7fe9ff', { float: .4, power: 1.6, range: 30, tilt: 0, ei: 3 });
  for (const [dx, dy, dz, s, hex] of [[9, 5.5, 6, 1.5, '#6fb8ff'], [-10, 6.5, -5, 1.8, '#7fe9ff'], [-6, 4.6, 11, 1.2, '#9fa8ff'], [11.5, 7, -3, 1.1, '#7fe9ff'], [-13, 5, 3, 1.4, '#6fb8ff'], [3, 6.5, -13, 1.6, '#9fa8ff']]) crystal(cx + dx, Y + dy, cz + dz, s, hex, { float: .3 + RND() * .3, power: .6, range: 10, tilt: 0 });
  crystalCluster(cx - 11.4, Y, cz - 9.4, '#7fe9ff', 3, 1.3, { power: .7 }); crystalCluster(cx + 4.4, Y, cz + 14.6, '#6fb8ff', 3, .9, { power: .5 });
  // parapet + rubble obstacles
  for (let k = 0; k < 14; k++) { const a0 = (k + .2) / 14 * TAU, a1 = (k + .86) / 14 * TAU; if (k === 0 || k === 13) continue; if (RND() < .2) continue; ruinWall(rg, cx + Math.cos(a0) * 17.2, cz + Math.sin(a0) * 17.2, cx + Math.cos(a1) * 17.2, cz + Math.sin(a1) * 17.2, 1.5 + RND() * 1.4, { y: Y, minH: 1.05, th: .8 }); }
  stone(rg, cx - 4.4, Y, cz + 5.2, 1.8, .9, 1.1, { yaw: .5, chip: .14 }); stone(rg, cx + 4.8, Y, cz - 4.4, 1.4, 1.1, 1.2, { yaw: 1.2, chip: .14 }); fallenDrum(rg, cx - 5.2, cz - 10.2, .55, 2.6, .3, { y: Y });
  tablet(rg, cx + 11.6, cz + 5.6, -2.0, 'astrolabe', { y: Y, hex: '#ffd070' }); tablet(rg, cx - 11.2, cz + 8.2, 2.2, 'lastnight', { y: Y, hex: '#ffd070' });
  spirit(cx + 5.6, cz + 4.6, 'Astronomer Oriel', '#ffe0a0', () => PL.solved
    ? ['There. Exactly as it was. I could weep, if I still had the water for it.', 'Take the fragment down to the Gate. And look up once before you go — they are all still there.']
    : ['You climbed. Good. The sky is better company than the valley.', 'Three star-stones lie on this summit: Sun, Moon, Star. Three plates ring the orrery, each cut with its sign. The orrery\'s own arms point the way.', 'Take hold of a stone and walk — it will follow your hands. Let go when it sits on its plate.', 'A wrong stone will wake a plate, but not the sky. And if a stone gets away from you, the Rune of Return by the east rail calls them home.'], { y: Y });
  for (let i = 0; i < 9; i++) { const a = .5 + i / 9 * (TAU - 1), r = 20.5 + RND() * 4, x = cx + Math.cos(a) * r, z = cz + Math.sin(a) * r; tree('treeD', x, z, .9 + RND() * .5, false, new T.Color(1.5, 1.05, .55)); }
  makeMotes(380, r => { const a = r() * TAU, d = r() * 19; return [cx + Math.cos(a) * d, Y + .5 + r() * 10, cz + Math.sin(a) * d]; }, '#a8e4ff', .06);
  for (let i = 0; i < 7; i++) { const a = i / 7 * TAU + .3; shaft(cx + Math.cos(a) * 9, Y - 1, cz + Math.sin(a) * 9, 22, 5, '#ffe0b0', .055); }
}
function updatePlates(dt) {
  const PL = PLATES, Y = PL.Y, cx = MOUNT.x, cz = MOUNT.z;
  const st = P.grab;
  if (st) {   // the held stone is dragged toward a point in front of the player
    const tx = P.pos.x - Math.sin(P.yaw) * 1.55, tz = P.pos.z - Math.cos(P.yaw) * 1.55; let dx = tx - st.x, dz = tz - st.z; const d = Math.hypot(dx, dz), mv = Math.min(d, 3.4 * dt);
    if (d > 1e-4) { let nx = st.x + dx / d * mv, nz = st.z + dz / d * mv;[nx, nz] = resolveCircle(nx, nz, .62, Y + .1, Y + .9, st.col);
      const rc = Math.hypot(nx - cx, nz - cz); if (rc > 16.4) { nx = cx + (nx - cx) / rc * 16.4; nz = cz + (nz - cz) / rc * 16.4; }
      const pd = Math.hypot(nx - P.pos.x, nz - P.pos.z); if (pd < 1.02) { nx = P.pos.x + (nx - P.pos.x) / Math.max(pd, 1e-3) * 1.02; nz = P.pos.z + (nz - P.pos.z) / Math.max(pd, 1e-3) * 1.02; }
      const moved = Math.hypot(nx - st.x, nz - st.z); st.x = nx; st.z = nz; st.drag = (st.drag || 0) + moved; if (st.drag > 1.1) { st.drag = 0; AU.sfx('drag'); } }
    if (Math.hypot(st.x - P.pos.x, st.z - P.pos.z) > 3.3 || Math.abs(P.pos.y - Y) > 1.2) { P.grab = null; UI.toast('The stone slips from your hands.', 'hint'); }
  }
  let pressed = 0, right = 0;
  for (const s of PL.stones) { s.g.position.x = lerp(s.g.position.x, s.x, 1 - Math.exp(-dt * 18)); s.g.position.z = lerp(s.g.position.z, s.z, 1 - Math.exp(-dt * 18)); s.col.x = s.x; s.col.z = s.z; s.inter.pos.set(s.x, Y + .9, s.z); }
  if (PL.solved) return;
  for (const p of PL.plates) {
    let on = null; for (const s of PL.stones) if (Math.hypot(s.x - p.x, s.z - p.z) < .62) on = s;
    const state = !on ? 0 : on.name === p.name ? 2 : 1;
    if (state) pressed++; if (state === 2) right++;
    if (state !== p.state) { if (p.state !== -1) AU.sfx(state ? 'plate' : 'thud'); p.state = state; const hx = state === 2 ? '#8fffb0' : state === 1 ? '#ff9a4a' : p.hex, k = state ? 2.6 : .55; setGlyph(p.gp, hx, k); p.ring.material.color.copy(hdr(hx, state ? 2.5 : .5)); p.gl.color.set(hx); p.gl.power = state ? .6 : 0; }
    p.pm.position.y = lerp(p.pm.position.y, p.y0 - (state ? .06 : 0), 1 - Math.exp(-dt * 10));
  }
  if (pressed === 3 && right < 3 && !PL.warned) { PL.warned = true; UI.toast('All three plates are awake, but the sky is wrong. Each stone belongs on the plate that bears its sign.', 'bad'); AU.sfx('wrong'); }
  if (pressed < 3) PL.warned = false;
  PL.hold = right === 3 ? PL.hold + dt : 0; if (PL.hold > .6) PL.open();
}

// ---------------------------------------------------------------- global scenery + world assembly
// warm lantern: a waymark and a warm counterpoint to the cool crystals
function lantern(rg, x, z, o = {}) {
  const y = o.y == null ? terrainH(x, z) - .15 : o.y, h = o.h || 1.25, hex = o.hex || '#ffb45a';
  stone(rg, x, y, z, .62, .22, .62, { col: false, yaw: .4 }); cyl(rg, x, y + .2, z, .17, .21, h, {}); stone(rg, x, y + h + .16, z, .5, .1, .5, { col: false, yaw: .4 });
  const f = new T.Mesh(new T.OctahedronGeometry(.15, 0), new T.MeshBasicMaterial({ color: new T.Color(hex).multiplyScalar(3.2) })); f.position.set(x, y + h + .5, z); f.scale.y = 1.5; W.scene.add(f); f.add(makeHalo(hex, 1.9, .5));
  for (const a of [0, 1, 2, 3]) stone(rg, x + Math.cos(a * 1.571 + .4) * .2, y + h + .2, z + Math.sin(a * 1.571 + .4) * .2, .05, .62, .05, { col: false });
  stone(rg, x, y + h + .8, z, .56, .12, .56, { col: false, yaw: .4 });
  const gl = glow(x, y + h + .5, z, hex, o.power || .85, o.range || 10), ph = x * 1.7 + z;
  W.updaters.push((dt, t) => { const k = 1 + .12 * Math.sin(t * 9 + ph) + .08 * Math.sin(t * 23.3 + ph * 2); f.scale.set(k, 1.5 * k, k); gl.power = (o.power || .85) * k; });
  addCyl(x, z, .28, y, y + h + .9);
}
function buildDressing() {
  const th = terrainH, rg = 'forest';
  // --- Whispering Forest: an overgrown gatehouse front beside the trail
  ruinWall(rg, -24.5, 10.2, -31.5, 11.6, 7.4, { th: 1.5, minH: 4.6 }); ruinWall(rg, -33.2, 12, -37, 12.6, 5.2, { th: 1.4, minH: 3.4 });
  column(rg, -26, th(-26, 8.6) - .2, 8.7, .55, 6.4, { broken: .82 }); column(rg, -30.6, th(-30.6, 9.2) - .2, 9.4, .55, 6.4, { broken: .5 }); fallenDrum(rg, -33.4, 8.4, .52, 2.9, -.5);
  for (const [x, yo, z, s] of [[-25.6, 6.6, 9.75, 1.5], [-27.6, 5.6, 9.95, 1.3], [-29.4, 6.9, 10.3, 1.6], [-31, 5.2, 10.7, 1.2], [-34.5, 4.6, 11.4, 1.2], [-36.2, 4.2, 11.7, 1.1]]) ivy(x, th(x, z) + yo, z, Math.PI + .2, s);
  crystalCluster(-28.3, th(-28.3, 8.3), 8.4, '#6fd6ff', 3, .7, { power: .55 }); rubble(rg, -29.5, 7.8, 7, 2.4);
  ruinWall(rg, -84, -9.5, -90, -4, 6.2, { th: 1.4, minH: 3.6 }); ruinWall(rg, -90.5, 9, -86.5, 14.5, 5.6, { th: 1.4, minH: 3.2 });
  for (const [x, yo, z, yaw] of [[-86, 5, -7.2, .8], [-88.4, 5.4, -5.2, .8], [-89, 4.8, 11, 2.2], [-87.6, 4.6, 13, 2.2]]) ivy(x, th(x, z) + yo, z, yaw, 1.4);
  // --- lanterns: every trail is marked, so the way on is always visible through the trees
  const mark = (path, step, off, first = 6) => { for (let k = 0, n = 0; k < path.length - 1; k++) { const a = path[k], b = path[k + 1], L = Math.hypot(b[0] - a[0], b[1] - a[1]); for (let d = k ? step * .5 : first; d < L - 2; d += step, n++) { const t = d / L, sd = n % 2 ? 1 : -1, x = lerp(a[0], b[0], t) - (b[1] - a[1]) / L * off * sd, z = lerp(a[1], b[1], t) + (b[0] - a[0]) / L * off * sd; lantern(rg, x, z); } } };
  mark(FPATH, 12.5, 3.3); mark(GPATH, 9, 2.6, 5);
  lantern(rg, -52.6, 9.4, { hex: '#6fd6ff', power: .6, h: .9 });   // a single cool lamp where the hidden trail leaves the fork
  // --- Forgotten Courtyard: braziers by the gate and the entrance, more hanging growth
  for (const [x, z] of [[-6.9, -12.6], [6.9, -12.6], [-15.6, 15.6], [15.6, 15.2]]) lantern('court', x, z, { y: 0, h: 1.5, power: 1, range: 12 });
  const Wd = 21.5; for (const [x, y, z, yaw, s] of [[-16, 4.6, -Wd + .7, 0, 1.4], [-9.5, 5.2, -Wd + .7, 0, 1.5], [3, 5.4, -Wd + .7, 0, 1.3], [17.5, 4.2, -Wd + .7, 0, 1.3], [Wd - .7, 4.4, -12, -Math.PI / 2, 1.4], [Wd - .7, 4.2, 9, -Math.PI / 2, 1.4], [Wd - .7, 4, 15, -Math.PI / 2, 1.2],
    [-Wd + .7, 4.6, -11, Math.PI / 2, 1.5], [-Wd + .7, 4, 11, Math.PI / 2, 1.3], [0, 4.2, Wd - .7, Math.PI, 1.4], [9, 4, Wd - .7, Math.PI, 1.3], [16, 4.2, Wd - .7, Math.PI, 1.3]]) ivy(x, y, z, yaw, s);
  // --- Sunken Temple: warm braziers against the cold water light, coloured crystal growths
  const F = TFLOOR; for (const [x, z] of [[58.6, -7.6], [58.6, 7.6], [72.4, -7.6], [72.4, 7.6], [77.6, -8.6], [77.6, 8.6], [94.4, -8.6], [94.4, 8.6]]) lantern('temple', x, z, { y: F, h: 1.6, power: 1.1, range: 13 });
  crystalCluster(94.6, F, -3.2, '#ff6ad5', 3, .9, { power: .5 }); crystalCluster(81.2, F, 8.8, '#ffb347', 3, .8, { power: .45 }); crystalCluster(57.4, F, 3.2, '#6fe6ff', 3, 1, { power: .5 }); crystalCluster(74, F, -8.4, '#b08cff', 3, .8, { power: .45 });
  lantern('temple', 36.2, 2.6, { y: terrainH(36.2, 2.6) - .1 }); lantern('temple', 36.2, -2.6, { y: terrainH(36.2, -2.6) - .1 });
  // --- Celestial Sanctuary: standing monoliths on the rim, crystal growths, warm braziers against the blue twilight
  { const cx = MOUNT.x, cz = MOUNT.z, Y = MOUNT.top, rs = rng(4242);
    for (let i = 0; i < 9; i++) { const a = .55 + i / 9 * TAU, x = cx + Math.cos(a) * 17.25, z = cz + Math.sin(a) * 17.25; if (Math.abs(a - TAU) < .5 || a < .3) continue; const h = 4.6 + rs() * 3.6;
      stone('sanct', x, Y - .4, z, 1.25 + rs() * .5, h, .8 + rs() * .3, { yaw: -a + (rs() - .5) * .5, rz: (rs() - .5) * .22, col: false, chip: .16 });
      if (i % 2 === 0) { const gp = glyphPlane('g_' + ['star', 'moon', 'sun', 'ring', 'eye'][(i / 2) % 5 | 0], .9, '#7fe9ff', 1.7); gp.position.set(cx + Math.cos(a) * 16.72, Y + h * .55, cz + Math.sin(a) * 16.72); gp.rotation.y = -a - Math.PI / 2; W.scene.add(gp); } }
    for (const [a, hex, s] of [[1.25, '#7fe9ff', 1.2], [2.75, '#6fb8ff', 1.0], [4.35, '#9fa8ff', 1.1], [5.55, '#7fe9ff', .9]]) crystalCluster(cx + Math.cos(a) * 15.9, Y, cz + Math.sin(a) * 15.9, hex, 3, s, { power: .6 });
    for (const a of [.62, 2.2, 3.75, 5.3]) lantern('sanct', cx + Math.cos(a) * 16.9, cz + Math.sin(a) * 16.9, { y: Y, h: 1.5, power: 1.1, range: 13 });
    // a column of light under the great crystal
    const bm = new T.Mesh(new T.CylinderGeometry(.5, 1.5, 9, 16, 1, true), new T.MeshBasicMaterial({ color: new T.Color('#7fe9ff').multiplyScalar(.9), transparent: true, opacity: .1, blending: T.AdditiveBlending, depthWrite: false, side: T.DoubleSide, fog: false })); bm.position.set(cx, Y + 5, cz); W.scene.add(bm);
    W.updaters.push((dt, t) => { bm.material.opacity = .085 + .035 * Math.sin(t * 1.3); bm.rotation.y = t * .1; });
    makeMotes(220, r => { const a = r() * TAU, d = r() * 4; return [cx + Math.cos(a) * d, Y + .5 + r() * 11, cz + Math.sin(a) * d]; }, '#7fe9ff', .07); }
  // mountain stair waymarks
  for (let i = 1; i < MPATH.length - 1; i++) { const a = MPATH[i], b = MPATH[i + 1], L = Math.hypot(b[0] - a[0], b[1] - a[1]), nx = -(b[1] - a[1]) / L, nz = (b[0] - a[0]) / L; lantern('court', a[0] + nx * 2.6, a[1] + nz * 2.6, { y: terrainH(a[0] + nx * 2.6, a[1] + nz * 2.6) - .15 }); }
}
function scatterScenery() {
  const rr = rng(777), th = terrainH;
  // trees on the hills around the courtyard, temple and lower mountain
  for (let i = 0; i < 2600 && TREES_PLACED.length < 560; i++) {
    const x = -24 + rr() * 140, z = -70 + rr() * 118, d = sdLow(x, z); if (d < 1.2 || d > 20) continue; if (mpathInfo(x, z)[0] < 7.5) continue; if (x > 52 && x < 100 && z > -22 && z < 24) continue;
    const y = th(x, z); if (y > 17 || !farFromTrees(x, z, 4.4)) continue;
    const k = rr(); tree(k < .5 ? 'treeA' : k < .8 ? 'treeB' : 'treeC', x, z, .9 + rr() * .6, false);
  }
  for (let i = 0; i < 500; i++) { const x = -50 + rr() * 110, z = -150 + rr() * 110, y = th(x, z); if (y < 2 || y > 20 || mpathInfo(x, z)[0] < 8 || sdLow(x, z) < 3 || !farFromTrees(x, z, 5.5)) continue; tree(rr() < .6 ? 'treeC' : 'treeD', x, z, 1 + rr() * .7, false, new T.Color(.62 + rr() * .2, 1.0, 1.05 + rr() * .35)); }
  // grass, ferns, flowers
  const pavedCore = (x, z) => Math.abs(x) < 17.5 && Math.abs(z) < 17.5;
  for (let i = 0; i < 90000; i++) {
    const x = -105 + rr() * 165, z = -46 + rr() * 92, d = sdLow(x, z); if (d > 9 || (d > 1 && rr() < .6)) continue; if (x > 30.5) continue;
    if (pavedCore(x, z) && rr() < .9) continue; if (Math.abs(x) < 6.6 && z < -8.2 && z > -18.2) continue; if (x > -15 && x < -5 && z > 21.6) continue;
    if (x < -18) { if (trailDist(x, z) < 1.3 && rr() < .9) continue; if (Math.hypot(x - POND.x, z - POND.z) < POND.r + .4) continue; if (Math.hypot(x - GLADE.x, z - GLADE.z) < 2.6) continue; }
    const n = fbm(x * .15, z * .15, 2); if (n < .32 && rr() < .7) continue;
    const y = th(x, z), k = rr(), v = .7 + rr() * .6;
    if (k < .93) I('grass', x, y - .02, z, rr() * 6, .8 + rr() * .7, new T.Color(v * (.85 + n * .5), v, v * .8), .6 + rr() * .9);
    else if (k < .975) { if (x < -18 || d > -3) I('fern', x, y, z, rr() * 6, .8 + rr() * .8, new T.Color(v, v, v)); }
    else I('flower', x, y, z, rr() * 6, 1 + rr() * .6, [new T.Color(1, .55, .8), new T.Color(1, 1, 1), new T.Color(.75, .6, 1), new T.Color(1, .9, .4)][Math.floor(rr() * 4)]);
  }
  // dry grass on the summit and along the stair
  for (let i = 0; i < 9000; i++) {
    const x = -24 + rr() * 72, z = -118 + rr() * 98, pd = mpathInfo(x, z)[0], dm = Math.hypot(x - MOUNT.x, z - MOUNT.z);
    if (!((pd > 1.9 && pd < 5.5 && sdLow(x, z) > 0) || (dm > 15.6 && dm < 22))) continue;
    const y = th(x, z), v = .8 + rr() * .5; I('grass', x, y - .02, z, rr() * 6, .8 + rr() * .7, new T.Color(v * 1.7, v * 1.25, v * .55), .6 + rr());
  }
  // bushes along the lowland edges
  for (let i = 0; i < 1400; i++) { const x = -105 + rr() * 135, z = -46 + rr() * 92, d = sdLow(x, z); if (d < -.8 || d > 3.5 || x > 30) continue; if (Math.abs(x) < 23 && Math.abs(z) < 23) continue; I('bush', x, th(x, z) - .1, z, rr() * 6, .8 + rr() * .9, new T.Color(.8 + rr() * .4, .9 + rr() * .2, .7 + rr() * .4)); }
  for (let i = 0; i < 60; i++) { const x = -20 + rr() * 40, z = (rr() < .5 ? -1 : 1) * (23 + rr() * 3); if (sdLow(x, z) < .3) continue; I('bush', x, th(x, z) - .1, z, rr() * 6, 1 + rr(), new T.Color(.9, 1, .8)); }
}
function shuffle(a, r) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } }
function buildWorld(progress) {
  buildTerrainGrid(); progress(.25);
  buildTerrainMesh(); progress(.35);
  buildCourtyard(); progress(.45); buildForest(); progress(.58); buildTemple(); progress(.7); buildSanctuary(); progress(.8);
  scatterScenery(); buildDressing(); progress(.88);
  finalizeBatches(); finalizeShafts();
  const rs = rng(31); for (const k of ['grass', 'fern', 'flower']) if (W.inst[k]) shuffle(W.inst[k], rs);
  const defs = {
    grass: { geom: grassClumpGeom(3), mat: MATS.grass, colored: true }, fern: { geom: fernGeom(5), mat: MATS.grass, colored: true }, flower: { geom: flowerGeom(7), mat: MATS.grass, colored: true },
    bush: { geom: bushGeom(9), mat: MATS.leaf, colored: true, cast: true }, ivy: { geom: ivyGeom(11), mat: MATS.ivy }, mush: { geom: mushroomGeom(13), mat: MATS.glowInst, colored: true }, bulb: { geom: bulbGeom(15), mat: MATS.glowInst, colored: true },
  };
  const pals = { treeA: ['#3f7a2a', '#4f8f30', '#2f6a2e', '#5b9a38'], treeB: ['#245a34', '#2f6f3a', '#1f5540', '#38783a'], treeC: ['#5a9a3a', '#6fae44', '#4a8a3a'], treeD: ['#9a8a3a', '#b89a44', '#8a7a34'], treeG: ['#2f6a2c', '#3f7f30', '#27603a', '#4f8f34'] };
  for (const k of Object.keys(TREE)) { const t = TREE[k], to = Object.assign({ pal: pals[k], roots: k === 'treeG' ? 10 : 5, rootLen: k === 'treeG' ? 5.2 : 3.6, branches: k === 'treeG' ? 8 : 4, fill: k === 'treeG' ? 7 : 3, detail: k === 'treeC' || k === 'treeD' ? 1 : 2 }, t), sd = k.charCodeAt(4) * 31, g = treeGeoms(sd, to), g1 = treeGeoms(sd, to, 1); defs[k + '_w'] = { geom: g.wood, mat: MATS.bark, cast: true, lod: g1.wood }; defs[k + '_l'] = { geom: g.leaves, mat: MATS.leaf, colored: true, cast: true, lod: g1.leaves }; }
  finalizeInstances(defs); initBursts(); progress(1);
}
