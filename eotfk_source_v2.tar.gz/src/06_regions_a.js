// ============================================================================
// Regions (part A): shared scenery helpers, the Forgotten Courtyard, the Whispering Forest
// ============================================================================
const TREE = { treeA: { h: 9, r: .42, crown: 3.0 }, treeB: { h: 12.5, r: .55, crown: 3.9 }, treeC: { h: 7, r: .3, crown: 2.5 }, treeD: { h: 5, r: .22, crown: 1.8 }, treeG: { h: 17, r: 1.3, crown: 6.6 } };
const TREES_PLACED = [];
function tree(kind, x, z, s = 1, collide = true, tint) {
  const y = terrainH(x, z) - .2, yaw = RND() * 6, v = .78 + RND() * .45;
  I(kind + '_w', x, y, z, yaw, s); I(kind + '_l', x, y, z, yaw, s, tint || new T.Color(v * (.88 + RND() * .24), v, v * (.8 + RND() * .35)));
  if (collide) addCyl(x, z, TREE[kind].r * s * 1.3, y - 2, y + 9); TREES_PLACED.push([x, z]);
}
function farFromTrees(x, z, d) { for (const t of TREES_PLACED) if ((t[0] - x) ** 2 + (t[1] - z) ** 2 < d * d) return false; return true; }
function hdr(hex, k) { return new T.Color(hex).multiplyScalar(k); }
function mush(x, z, hex, s = 1, y) { I('mush', x, y == null ? terrainH(x, z) - .02 : y, z, RND() * 6, s * (.8 + RND() * .8), hdr(hex, 2.6)); }
function ivy(x, y, z, yaw, s = 1) { I('ivy', x, y, z, yaw, s * (.85 + RND() * .4)); }
function makeWater(x0, x1, z0, z1, y, deepHex, sunCut = 1e6, radius = 0) {
  const g = radius ? new T.CircleGeometry(radius, 28).rotateX(-Math.PI / 2).translate((x0 + x1) / 2, y, (z0 + z1) / 2) : new T.PlaneGeometry(x1 - x0, z1 - z0).rotateX(-Math.PI / 2).translate((x0 + x1) / 2, y, (z0 + z1) / 2);
  const u = { uTime, uSun: { value: SUN }, uSunCol: { value: envCur.sunC }, uSky: { value: envCur.zen }, uHor: { value: envCur.hor }, uDeep: { value: new T.Color(deepHex) }, uFogC: { value: envCur.fog }, uFogD: { value: .01 }, uSunCut: { value: sunCut } };
  const m = new T.Mesh(g, new T.ShaderMaterial({ uniforms: u, transparent: true, depthWrite: false,
    vertexShader: 'varying vec3 vW;void main(){vec4 w=modelMatrix*vec4(position,1.);vW=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}',
    fragmentShader: `uniform float uTime,uFogD,uSunCut;uniform vec3 uSun,uSunCol,uSky,uHor,uDeep,uFogC;varying vec3 vW;${GLSL_NOISE}
float hg(vec2 p){return fbm2(p*.9+vec2(uTime*.11,uTime*.07))*.62+fbm2(p*2.6-vec2(uTime*.17,-uTime*.1))*.3;}
void main(){vec2 p=vW.xz;float e=.14;float h0=hg(p);vec3 n=normalize(vec3((h0-hg(p+vec2(e,0.)))/e*.42,1.,(h0-hg(p+vec2(0.,e)))/e*.42));
vec3 V=normalize(cameraPosition-vW);float fr=.03+.97*pow(1.-max(dot(n,V),0.),4.);
vec3 Rf=reflect(-V,n);vec3 sky=mix(uHor,uSky,clamp(Rf.y*1.4,0.,1.));
float sv=smoothstep(uSunCut+1.5,uSunCut-1.5,vW.x);float sp=pow(max(dot(Rf,uSun),0.),260.)*sv;
vec3 c=mix(uDeep*(.45+.9*h0),sky*(.55+.5*sv),fr)+uSunCol*sp*7.+uDeep*pow(h0,4.)*2.2;c*=mix(.5,1.,sv);
float d=length(cameraPosition-vW);c=mix(c,uFogC,1.-exp(-uFogD*uFogD*d*d));
gl_FragColor=vec4(c,mix(.6,.95,fr));}` }));
  m.renderOrder = 2; W.scene.add(m); W.updaters.push(() => { u.uFogD.value = envCur.dens; });
  W.water.push({ x0, x1, z0, z1, y, mesh: m }); return m;
}

// ---------------------------------------------------------------- THE FORGOTTEN COURTYARD
const GATE = {};
function buildCourtyard() {
  const rg = 'court';
  // flagstones (grass grows through the gaps)
  for (let ix = -12; ix <= 12; ix++) for (let iz = -12; iz <= 12; iz++) {
    const x = ix * 1.5, z = iz * 1.5, edge = Math.max(Math.abs(x), Math.abs(z));
    if (RND() < .1 + .55 * sstep(10, 18.5, edge)) continue; if (Math.abs(x) < 6.6 && z < -8 && z > -18) continue;
    stone(rg, x + (RND() - .5) * .08, -.09 + RND() * .03, z + (RND() - .5) * .08, 1.42, .14, 1.42, { yaw: (RND() - .5) * .07, col: false, chip: .05, aoH: .01, v: .88 });
  }
  // dais and the Echo Gate
  stone(rg, 0, -.3, -13, 12.4, .55, 9.4); stone(rg, 0, .25, -13.3, 10.2, .25, 7.8); stone(rg, 0, .5, -13.6, 8.2, .25, 6.2);
  const DY = .75, GZ = -15;
  arch(rg, 0, DY, GZ, 3.9, 5.2, 1.7, 0, { t: 1.5 });
  stone(rg, -4.6, DY - .5, GZ, 1.4, 3.4, 2.2, { chip: .14 }); stone(rg, 4.6, DY - .5, GZ, 1.4, 2.6, 2.2, { chip: .14 });
  const seal = new T.Group(); seal.position.set(0, DY, GZ);
  const sl = new T.Mesh(dynStone(blockGeom(3.9, 5.5, .5, .03, 901), rg), MATS.stone); sl.position.y = 2.75;
  const sc = new T.Mesh(dynStone(new T.CylinderGeometry(1.95, 1.95, .5, 20, 1, false, 0, Math.PI).rotateY(Math.PI / 2).rotateX(Math.PI / 2).translate(0, 5.5, 0), rg), MATS.stone);
  sl.castShadow = sl.receiveShadow = sc.castShadow = true; seal.add(sl, sc);
  const sg = glyphPlane('g_gate', 3.0, '#8fe6ff', .5); sg.position.set(0, 3.4, .27); seal.add(sg); W.scene.add(seal);
  addBox(0, GZ, 2, .45, 0, 9);
  const portal = new T.Mesh(new T.PlaneGeometry(3.9, 7.5), new T.ShaderMaterial({ uniforms: { uTime, uOn: { value: 0 } }, transparent: true, depthWrite: false, blending: T.AdditiveBlending,
    vertexShader: 'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader: `varying vec2 vUv;uniform float uTime,uOn;${GLSL_NOISE}
void main(){vec2 q=(vUv-vec2(.5,0.))*vec2(3.9,7.5);float inside=q.y<5.5?step(abs(q.x),1.95):step(length(q-vec2(0.,5.5)),1.95);
vec2 c=q-vec2(0.,3.4);float r=length(c),a=atan(c.y,c.x);float sw=fbm2(vec2(a*1.6+r*1.4-uTime*.9,r*1.2-uTime*.6));float core=exp(-r*.55);
vec3 col=mix(vec3(.1,.9,.6),vec3(.7,1.,.95),sw)*(.5+2.2*sw*sw+3.*core);gl_FragColor=vec4(col*inside*uOn,1.);}` }));
  portal.position.set(0, DY + 3.75, GZ - .1); portal.visible = false; W.scene.add(portal);
  const gateGlow = glow(0, DY + 3.4, GZ + 1.2, '#7dffd0', 0, 16);
  Object.assign(GATE, { seal, sg, portal, gateGlow, DY, GZ, sockets: [] });
  crystalCluster(-5.6, .25, -9.6, '#7fe9ff', 3, .9, { power: .6 }); crystalCluster(5.6, .25, -9.6, '#7fe9ff', 3, .9, { power: .6 });
  // three sockets
  const defs = [['frag_root', -2.4, -11.9, 'g_tree'], ['frag_tide', 0, -11.4, 'g_wave'], ['frag_sky', 2.4, -11.9, 'g_star']];
  for (const [id, x, z, gl] of defs) {
    const it = ITEMS[id]; pedestal(rg, x, DY, z, 1.05, .3);
    const gp = glyphPlane(gl, .42, it.hex, .7); gp.position.set(x, DY + .62, z + .34); W.scene.add(gp);
    const rel = relicMesh(it.hex); rel.position.set(x, DY + 1.55, z); rel.visible = false; W.scene.add(rel);
    const g2 = glow(x, DY + 1.6, z, it.hex, 0, 7);
    W.updaters.push((dt, t) => { if (rel.visible) { rel.position.y = DY + 1.55 + Math.sin(t * 1.3 + x) * .06; rel.rotation.y += dt * .8; } });
    const so = addInter({ pos: new V3(x, DY + 1.3, z), reach: 3.2, get label() { return G.placed[id] ? '' : G.has(id) ? 'Set the ' + it.name + ' in its socket' : 'Examine the empty socket'; },
      use() {
        if (G.placed[id]) return;
        if (!G.has(id)) { UI.toast('An empty socket, carved with a sign. The ' + it.name + ' belongs here.', 'hint'); AU.sfx('deny'); return; }
        G.take(id); G.placed[id] = true; rel.visible = true; g2.power = .9; setGlyph(gp, it.hex, 2.6); AU.sfx('place'); burst(so.pos, it.hex, 70, 3, 1.6); so.on = false;
        const n = G.placedCount(); setGlyph(sg, '#8fe6ff', .5 + n * .7); gateGlow.power = n * .35; UI.refresh();
        UI.toast(n === 3 ? 'All three fragments are set. The Echo Gate is listening.' : 'The fragment settles into the socket. ' + (3 - n) + ' remain.', 'good');
        if (n === 3) { GATE.core.on = true; AU.sfx('solve'); }
      } });
    GATE.sockets.push({ id, rel, x, z, hex: it.hex });
  }
  GATE.core = addInter({ pos: new V3(0, DY + 2.4, GZ + .6), reach: 5, on: false, prio: 1, label: 'Awaken the Echo Gate', use() { GATE.core.on = false; startFinale(); } });
  addInter({ pos: new V3(0, DY + 2.2, GZ + .5), reach: 3.6, label: 'Examine the sealed gate', use() { UI.toast(G.placedCount() === 3 ? 'The seal trembles under your hand.' : 'A slab of living stone seals the arch. Three empty sockets wait on the dais before it.', 'hint'); G.flag('seen_gate'); } });
  // perimeter walls + gates
  const Wd = 21.5;
  ruinWall(rg, -Wd, -Wd, -Wd, -3.1, 5.6); ruinWall(rg, -Wd, 3.1, -Wd, Wd, 5);
  ruinWall(rg, Wd, -Wd, Wd, -2.8, 5.4); ruinWall(rg, Wd, 2.8, Wd, Wd, 5);
  ruinWall(rg, -Wd, -Wd, 9.2, -Wd, 6.2); ruinWall(rg, 14.8, -Wd, Wd, -Wd, 5);
  ruinWall(rg, -Wd, Wd, -11.7, Wd, 4.6, { minH: 3.3 }); ruinWall(rg, -8.3, Wd, Wd, Wd, 5, { minH: 3.3 });
  for (const [sx, sz, h] of [[-1, -1, 7.5], [1, -1, 5.2], [-1, 1, 4.4], [1, 1, 6.6]]) { stone(rg, sx * Wd, -.4, sz * Wd, 2.7, h, 2.7, { chip: .16 }); stone(rg, sx * Wd, h - .4, sz * Wd, 3.1, .4, 3.1, { col: false }); }
  arch(rg, -Wd, -.25, 0, 4.2, 3.6, 1.5, Math.PI / 2);                       // west: to the forest
  arch(rg, Wd, -.25, 0, 3.6, 3.6, 1.5, Math.PI / 2);                        // east: temple door
  arch(rg, 12, -.25, -Wd, 3.6, 3.6, 1.5, 0);                                // north-east: mountain stair
  stone(rg, -10, 2.95, Wd, 3.6, 1.1, 1.25, { col: false });
  const dT = slabDoor(rg, Wd, -.3, 0, 3.55, 5.6, .5, Math.PI / 2, 'g_wave', '#6fe6ff');
  const dS = slabDoor(rg, 12, -.3, -Wd, 3.55, 5.6, .5, 0, 'g_star', '#cfd8ff');
  const dC = slabDoor(rg, -10, -.3, Wd, 3.3, 3.3, .9, 0, 'g_eye', '#ffcf7a');
  const lockDoor = (door, x, z, key, flag, name, msg) => { const it = addInter({ pos: new V3(x, 1.5, z), reach: 3.4, get label() { return G.has(key) ? 'Unlock the ' + name + ' with the ' + ITEMS[key].name : 'Examine the ' + name; },
    use() { if (!G.has(key)) { UI.toast(msg, 'hint'); AU.sfx('deny'); return; } G.take(key); it.on = false; AU.sfx('key'); UI.toast('The ' + ITEMS[key].name + ' turns. Stone grinds against stone.', 'good'); door.open(); G.flag(flag); } }); };
  lockDoor(dT, Wd - .9, 0, 'key_verdant', 'door_temple', 'temple door', 'A slab carved with waves. There is a keyhole shaped like a leaf.');
  lockDoor(dS, 12, -Wd + .9, 'key_star', 'door_stair', 'barred stair', 'A slab carved with a star. The keyhole has seven points.');
  // colonnade
  const br = [1, .34, .62, 1, .2, .8, 1, .46]; let bi = 0;
  for (const x of [-7, 7]) for (const z of [-4.5, .5, 5.5, 10.5]) { const b = br[bi++]; column(rg, x, -.1, z, .55, 6.6, { broken: b }); if (b < .5) fallenDrum(rg, x + (x < 0 ? -2.4 : 2.6), z + 1.4, .52, 2.2, .5 + bi); }
  fallenDrum(rg, -11.5, 12.5, .5, 3.1, 1.1); rubble(rg, -11, 11, 7, 2.2); rubble(rg, 9.5, -2, 6, 1.8); rubble(rg, 16, -15, 9, 2.5); rubble(rg, -17, 17, 8, 2.4); rubble(rg, 4, 17.5, 5, 1.5);
  rock(rg, -16.5, 6, 1.2); rock(rg, 17.5, -8.5, 1.0); rock(rg, 15.5, 4.2, .7);
  // ancient trees with twisting roots
  tree('treeG', 14.2, 13.6, 1); tree('treeG', -14.6, -12.2, .9);
  // the hidden cellar: lever behind the elder tree
  const lv = lever(rg, 17.6, 0, 17.2, -2.3, 'Pull the iron branch', it => { it.on = false; UI.toast('Somewhere behind you, a wall remembers how to move.', 'good'); G.flag('secret_cellar'); later(.6, () => dC.open(4)); });
  // cellar room
  stone(rg, -14.3, -.4, 26.4, .9, 3.8, 9); stone(rg, -5.7, -.4, 26.4, .9, 3.8, 9); stone(rg, -10, -.4, 30.6, 9.4, 3.8, .9); stone(rg, -10, 3.3, 26.4, 9.6, .6, 9.4, { col: false }); stone(rg, -10, -.25, 26.2, 7.8, .27, 8, { col: false, aoH: .01, v: .8 });
  pedestal(rg, -10, 0, 28.6, 1, .32); pickup(sealMesh('#ffcf7a'), -10, 1.4, 28.6, 'Take the golden seal', '#ffcf7a', () => G.give('seal_king'));
  tablet(rg, -13.2, 27, Math.PI / 2, 'crypt', { hex: '#ffcf7a', y: 0 }); crystalCluster(-6.9, 0, 29.4, '#ffb347', 3, .8); crystalCluster(-13, 0, 23.6, '#ffb347', 2, .6, { light: false });
  // tablets + spirit
  tablet(rg, 3.4, 11.4, 0, 'founding'); tablet(rg, 18.4, -4.8, -Math.PI / 2, 'templedoor'); tablet(rg, 7.4, -18.8, 0, 'stairgate'); tablet(rg, -4.6, 19.4, Math.PI, 'cellar', { hex: '#ffcf7a' });
  spirit(-3.8, 6.5, 'Warden Ilyra', '#9fe8ff', () => {
    const n = G.fragCount(), p = G.placedCount();
    if (p === 3) return ['It is all there. I can feel it — like standing next to a held breath.', 'Lay your hand on the seal, traveller. I have waited long enough to see what is on the other side.'];
    if (n === 3) return ['Three. You carry all three.', 'Set each fragment in its socket on the dais, beneath its own sign, and then wake the Gate.'];
    if (!G.flags['spoke_Warden Ilyra']) return ['A living footstep. I had forgotten the sound.', 'I am Ilyra. I kept the watch on this courtyard when Elvareth walked through the Echo Gate, and I keep it still.', 'The Gate is sealed. Its Heartstone was broken in three: one fragment in the forest to the west, one in the drowned temple to the east, one on the mountain behind the Gate.', 'The west arch stands open. Begin with the Gardeners — the other two ways are locked, and each calling hid the next one\'s key.', 'Read the stones as you go. We wrote everything down. We hoped someone would come.'];
    if (!G.has('frag_root') && !G.placed.frag_root) return ['The forest first. Follow the trail west to the glade of five stones.', 'The Gardeners sang the seasons in order. There is a song-stone at the edge of the glade; trust it.'];
    if (!G.flags.door_temple) return G.has('key_verdant') ? ['That is the Verdant Key. The temple door is in the east wall, behind you.'] : ['The temple door wants the Verdant Key. In the forest, find the stone watcher at the fork and walk where it is looking — the blue caps mark the way.'];
    if (!G.has('frag_tide') && !G.placed.frag_tide) return ['The Tide-Keepers trusted light more than locks.', 'Find the lens for their lamp, then turn the mirrors until the beam reaches the Eye.'];
    if (!G.flags.door_stair) return ['The stair to the Sanctuary is in the north wall, east of the Gate. The Star Key from the temple vault will open it.'];
    return ['Climb. The Astronomers kept the last fragment closest to the sky.', 'They will ask you to put the Sun, the Moon and the Star in their places. Take hold of the stones and walk them there.'];
  });
  // greenery on the walls
  for (let i = 0; i < 16; i++) { const t = -19 + RND() * 38; if (i % 4 === 0 && Math.abs(t) > 4) ivy(-Wd + .62, 2.6 + RND() * 1.6, t, Math.PI / 2, 1.2); else if (i % 4 === 1 && Math.abs(t) > 4) ivy(Wd - .62, 2.6 + RND() * 1.6, t, -Math.PI / 2, 1.2); else if (i % 4 === 2 && (t < 8 || t > 16)) ivy(t, 2.8 + RND() * 2, -Wd + .62, 0, 1.3); else if (t < -13 || t > -7) ivy(t, 2.6 + RND() * 1.4, Wd - .62, Math.PI, 1.2); }
  ivy(-2.7, DY + 5.4, GZ + .9, 0, 1.1); ivy(3.1, DY + 4.6, GZ + .9, 0, .9); ivy(-4.6, 3.6, GZ + 1.15, 0, .9);
  for (let i = 0; i < 9; i++) mush(-19 + RND() * 3, -5 + RND() * 10, '#59d8ff');
  for (let i = 0; i < 7; i++) { const a = RND() * TAU; mush(14.2 + Math.cos(a) * 2.6, 13.6 + Math.sin(a) * 2.6, '#ffb86a'); }
  glow(-18, .6, 0, '#59d8ff', .35, 6);
  makeMotes(260, r => [-20 + r() * 40, .4 + r() * 5, -20 + r() * 40], '#fff3c0', .035);
}

// ---------------------------------------------------------------- THE WHISPERING FOREST
const RUNES = { order: ['tree', 'wave', 'sun', 'moon', 'star'], ring: ['moon', 'tree', 'star', 'sun', 'wave'], stones: [], idx: 0, solved: false, busy: false };
function buildForest() {
  const rg = 'forest', th = (x, z) => terrainH(x, z);
  // ruins along the trail
  arch(rg, -27.5, th(-27.5, -2) - .3, -2.2, 4.4, 3.5, 1.4, Math.PI / 2 + .25, { broken: 1 });
  ruinWall(rg, -24.5, -8.6, -32, -10.4, 4.2); ruinWall(rg, -38.5, 12.5, -44, 14.5, 3.8); ruinWall(rg, -55, -6.5, -61, -5, 3.6); ruinWall(rg, -66, 12, -71, 15.5, 4.4);
  ivy(-28, th(-28, -9.5) + 3, -8.9, 0, 1.3); ivy(-41, th(-41, 13) + 2.8, 12.6, Math.PI, 1.2); ivy(-58, th(-58, -6) + 2.7, -5.1, 0, 1.2); ivy(-68.5, th(-68, 13) + 3.2, 13.1, 2.6, 1.3);
  column(rg, -36.5, th(-36.5, 2.5) - .2, 2.6, .5, 5.5, { broken: .45 }); column(rg, -52, th(-52, -2) - .2, -2.2, .5, 5.5, { broken: .7 }); fallenDrum(rg, -50, -4.6, .48, 2.6, .7);
  rubble(rg, -29, 2.5, 6, 2); rubble(rg, -41, -1, 5, 2); rubble(rg, -58, 6, 6, 2.2);
  for (const [x, z, s] of [[-25, 6.5, 1.3], [-33, 4.5, .9], [-40.5, -8.5, 1.5], [-56.5, 9, 1.2], [-64.5, -3.5, 1.1], [-51.5, 14.5, 1.6], [-45, 15.5, 1.3], [-70, 12, 1.0], [-87, 12, 1.5], [-88, -4, 1.3]]) rock(rg, x, z, s);
  // the stone watcher at the fork gazes down the hidden trail
  statue(rg, -45.4, 9.6, Math.atan2(-5, 14), { s: 1.15 });
  I('bush', -49.6, th(-49.6, 10.8), 10.8, 1, 1.2); I('bush', -47.2, th(-47.2, 12.2), 12.2, 2, 1.1); I('bush', -51, th(-51, 12.5), 12.5, 4, 1.0);
  for (let i = 0; i < 4; i++) I('fern', -50 + RND() * 3, th(-49, 11) + .02, 10 + RND() * 3, RND() * 6, 1.3);
  for (let k = 0; k < HPATH.length - 1; k++) { const a = HPATH[k], b = HPATH[k + 1], L = Math.hypot(b[0] - a[0], b[1] - a[1]); for (let d = 2.2; d < L; d += 1.9) { const t = d / L, sd = (Math.round(d / 1.9) % 2 ? 1 : -1) * (1.1 + RND() * .7), nx = -(b[1] - a[1]) / L, nz = (b[0] - a[0]) / L, x = lerp(a[0], b[0], t) + nx * sd, z = lerp(a[1], b[1], t) + nz * sd; mush(x, z, '#4fd0ff', 1.3); if (Math.round(d / 1.9) % 3 === 0) glow(x, th(x, z) + .35, z, '#4fd0ff', .3, 5); } }
  // the Gardeners' hollow: key + hidden seal
  const hy = th(HOLLOW.x, HOLLOW.z);
  stone(rg, -61.6, hy - .2, 31.4, 1.9, 1.0, 1.0, { yaw: .6, chip: .14 }); cyl(rg, -58.2, hy - .1, 32.3, .55, .5, .65, { tint: '#6d5a44' }); addCyl(-58.2, 32.3, .55, hy - 1, hy + .55);
  pickup(keyMesh('#8fe88a'), -61.6, hy + 1.25, 31.4, 'Take the Verdant Key', '#8fe88a', () => { G.give('key_verdant'); });
  pickup(sealMesh('#8fe88a'), -58.2, hy + .95, 32.3, 'Take the leaf-marked seal', '#8fe88a', () => G.give('seal_garden'));
  crystalCluster(-63.4, hy, 29.2, '#7dff9a', 3, .8, { power: .6 }); rock(rg, -57, 26.6, 1.3); rock(rg, -64, 33.2, 1.5);
  for (let i = 0; i < 8; i++) { const a = RND() * TAU; mush(HOLLOW.x + Math.cos(a) * (2 + RND() * 2.6), HOLLOW.z + Math.sin(a) * (2 + RND() * 2.6), i % 2 ? '#4fd0ff' : '#7dff9a'); }
  // the statue grove
  const gy = th(GROVE.x, GROVE.z);
  for (const a of [.3, 2.2, 4.1]) { const x = GROVE.x + Math.cos(a) * 5.4, z = GROVE.z + Math.sin(a) * 5.4; statue(rg, x, z, Math.atan2(GROVE.x - x, GROVE.z - z), { s: 1.05 + RND() * .2 }); }
  for (const a of [2.85, 3.5, 5.25]) { const x = GROVE.x + Math.cos(a) * 6.2, z = GROVE.z + Math.sin(a) * 6.2; stone(rg, x, th(x, z) - .4, z, 1.0, 2.4 + RND() * 1.4, .7, { yaw: -a, rz: (RND() - .5) * .16, chip: .15 }); }
  tablet(rg, -39.8, -27.6, Math.atan2(GROVE.x + 39.8, GROVE.z + 27.6), 'lament', { hex: '#9dffb0' });
  crystalCluster(-47.5, th(-47.5, -28.5), -28.5, '#7dff9a', 3, .9, { power: .6 });
  spirit(GROVE.x + .5, GROVE.z + .8, 'Thalen the Gardener', '#9dffb0', () => RUNES.solved
    ? ['The bud opened. I felt it in every root.', G.flags.door_temple ? 'Go gently, traveller.' : 'If you still need the Keepers\' key: the stone watcher at the fork has been pointing at it for a very long time.']
    : ['Hush. Hear them? The trees repeat what we sang to them.', 'In the glade at the end of the trail stand five stones: Root, Wave, Sun, Moon, Star. Wake them the way a year wakes — the song-stone has the order.', 'Touch a stone out of turn and they all go dark again. They are patient. So were we.', 'And if you want the Keepers\' key — the watcher at the fork looks straight down the path to our hollow. Follow the blue caps.']);
  // the rune glade
  const cx = GLADE.x, cz = GLADE.z, cy = th(cx, cz) - .05;
  tablet(rg, -64.8, 5.6, Math.PI / 2, 'song', { hex: '#9dffb0' });
  cyl(rg, cx, cy, cz, 2.3, 2.2, .3, { seg: 18 }); addCyl(cx, cz, 2.3, cy - 1, cy + .3, { walk: true });
  cyl(rg, cx, cy + .3, cz, .62, .5, .85, { seg: 8 }); addCyl(cx, cz, .95, cy, cy + 2.4);
  const petals = []; const pm = MATS.stone;
  for (let i = 0; i < 6; i++) { const a = i / 6 * TAU, piv = new T.Group(); piv.position.set(cx + Math.cos(a) * .52, cy + 1.12, cz + Math.sin(a) * .52); piv.rotation.y = -a + Math.PI / 2; const m = new T.Mesh(dynStone(blockGeom(.62, 1.5, .14, .04, 300 + i).translate(0, .75, 0), rg), pm); m.castShadow = true; piv.add(m); piv.rotation.x = 0; piv.userData.tilt = .34; m.rotation.x = -.34; W.scene.add(piv); petals.push(m); }
  const bud = makeHalo('#7dff9a', 1.6, .5); bud.position.set(cx, cy + 1.9, cz); W.scene.add(bud);
  const relic = pickup(relicMesh('#7dff9a'), cx, cy + 1.95, cz, 'Take the Fragment of the Root', '#7dff9a', () => { G.give('frag_root'); UI.toast('The forest exhales. One fragment of the Heartstone is yours.', 'good'); }, { on: false, reach: 3.4 });
  RUNES.ring.forEach((name, i) => {
    const a = i / 5 * TAU + .45, x = cx + Math.cos(a) * 5.7, z = cz + Math.sin(a) * 5.7, y = th(x, z), yaw = Math.atan2(cx - x, cz - z);
    stone(rg, x, y - .45, z, 1.25, 3.1, .58, { yaw, chip: .13, rz: (RND() - .5) * .08 });
    const gp = glyphPlane('g_' + name, .95, '#9dffb0', .28); gp.position.set(x + Math.sin(yaw) * .32, y + 1.65, z + Math.cos(yaw) * .32); gp.rotation.y = yaw; W.scene.add(gp);
    const gl = glow(x + Math.sin(yaw) * .8, y + 1.6, z + Math.cos(yaw) * .8, '#7dff9a', 0, 7);
    const st = { name, gp, gl, lit: false, i };
    st.inter = addInter({ pos: new V3(x + Math.sin(yaw) * .5, y + 1.6, z + Math.cos(yaw) * .5), reach: 3.3, label: 'Wake the rune of the ' + name[0].toUpperCase() + name.slice(1), use() { runeTouch(st); } });
    RUNES.stones.push(st);
  });
  RUNES.open = () => { RUNES.solved = true; for (const s of RUNES.stones) s.inter.on = false; AU.sfx('solve'); AU.sfx('stone', 2.5); G.flag('rune_solved');
    UI.toast('The five stones sing together. The stone bud is opening.', 'good'); burst(new V3(cx, cy + 2, cz), '#7dff9a', 120, 4.5, 2.2);
    tween(2.6, k => { for (const p of petals) p.rotation.x = lerp(-.34, 1.25, k); bud.material.opacity = .5 * (1 - k); }, () => relic.show()); };
  // pond
  makeWater(POND.x - POND.r, POND.x + POND.r, POND.z - POND.r, POND.z + POND.r, POND.y, '#1b4a40', 1e6, POND.r + .6);
  for (let i = 0; i < 12; i++) { const a = RND() * TAU, d = POND.r + .3 + RND() * 1.6, x = POND.x + Math.cos(a) * d, z = POND.z + Math.sin(a) * d; I('bulb', x, th(x, z), z, RND() * 6, 1 + RND() * .8, hdr(i % 3 ? '#6fffd8' : '#ff9ad6', 3)); }
  glow(POND.x, POND.y + .6, POND.z, '#6fffd8', .4, 9); rock(rg, POND.x + 4.4, POND.z - 2.6, 1.1); rock(rg, POND.x - 3.6, POND.z - 4, .8);
  for (let i = 0; i < 16; i++) { const a = RND() * TAU, d = 7 + RND() * 5, x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d; I('bulb', x, th(x, z), z, RND() * 6, 1 + RND(), hdr(i % 2 ? '#8dffb0' : '#b89aff', 2.8)); }
  // trees
  const rr = rng(4242);
  for (let i = 0; i < 2600 && TREES_PLACED.length < 330; i++) {
    const x = -112 + rr() * 96, z = -48 + rr() * 96, d = sdLow(x, z); if (d > 15 || x > -17.5) continue;
    if (d < -.4) { if (trailDist(x, z) < 3.8 || Math.hypot(x - cx, z - cz) < 9.5 || Math.hypot(x - HOLLOW.x, z - HOLLOW.z) < 4.6 || Math.hypot(x - GROVE.x, z - GROVE.z) < 7.4 || Math.hypot(x - POND.x, z - POND.z) < 7 || rr() > .5) continue; }
    if (!farFromTrees(x, z, d < 2 ? 3.4 : 4.6)) continue;
    const k = rr(), kind = k < .45 ? 'treeA' : k < .8 ? 'treeB' : 'treeC';
    tree(kind, x, z, .85 + rr() * .5, d < 2.5, kind === 'treeC' && rr() < .4 ? new T.Color(1.9, .95, 1.25) : null);
    if (d < 2 && rr() < .5) { const a = rr() * TAU; mush(x + Math.cos(a) * 1.1, z + Math.sin(a) * 1.1, rr() < .5 ? '#5fffc0' : '#ffb04a'); }
  }
  // sun shafts through the canopy
  for (let i = 0; i < 26; i++) { const p = FPATH[1 + (i % 4)], x = p[0] + (rr() - .5) * 26, z = p[1] + (rr() - .5) * 22; if (sdLow(x, z) > 0) continue; shaft(x - SUN.x * 1.5, th(x, z) - 1, z - SUN.z * 1.5, 17 + rr() * 5, 1.8 + rr() * 2.4, '#fff0b4', .1 + rr() * .1); }
  for (let i = 0; i < 5; i++) { const a = i / 5 * TAU; shaft(cx + Math.cos(a) * 6, cy - 1, cz + Math.sin(a) * 6, 20, 3, '#eaffc8', .1); }
  const tr = [FPATH, HPATH, GPATH];
  makeMotes(620, r => { const pl = tr[r() < .6 ? 0 : r() < .5 ? 1 : 2], k = Math.floor(r() * (pl.length - 1)), t = r(), x = lerp(pl[k][0], pl[k + 1][0], t) + (r() - .5) * 16, z = lerp(pl[k][1], pl[k + 1][1], t) + (r() - .5) * 16; return [x, terrainH(x, z) + .3 + r() * 3.8, z]; }, '#c8ff8a', .05);
  makeMotes(160, r => { const a = r() * TAU, d = r() * 12; return [cx + Math.cos(a) * d, cy + .3 + r() * 5, cz + Math.sin(a) * d]; }, '#8dffd0', .06);
}
function runeTouch(st) {
  const Rn = RUNES; if (Rn.solved || Rn.busy || st.lit) return;
  if (st.name === Rn.order[Rn.idx]) {
    st.lit = true; setGlyph(st.gp, '#9dffb0', 3.2); st.gl.power = .7; AU.sfx('rune', Rn.idx); burst(st.inter.pos, '#9dffb0', 26, 1.6, 1.2); Rn.idx++;
    if (Rn.idx === 5) { Rn.busy = true; later(.7, Rn.open); } else UI.toast('The rune wakes. (' + Rn.idx + ' of 5)', 'good');
  } else {
    Rn.busy = true; AU.sfx('wrong'); UI.toast('The stones shudder and fall dark. That was not the order of the seasons.', 'bad');
    for (const s of Rn.stones) setGlyph(s.gp, '#ff5a4a', 2.4);
    later(.9, () => { for (const s of Rn.stones) { s.lit = false; s.gl.power = 0; setGlyph(s.gp, '#9dffb0', .28); } Rn.idx = 0; Rn.busy = false; });
  }
}
