// ============================================================================
// User interface: HUD, prompts, toasts, reader, dialogue, inventory, journal, menus
// ============================================================================
const $ = id => document.getElementById(id);
const NOLOCK = location.hash.indexOf('test') >= 0;
const ICONS = {
  relic: '<svg viewBox="0 0 40 40"><path d="M20 3 31 20 20 37 9 20Z" fill="currentColor" opacity=".85"/><path d="M20 3 31 20 20 37 9 20ZM9 20h22M20 3v34" fill="none" stroke="#fff" stroke-opacity=".55"/></svg>',
  key: '<svg viewBox="0 0 40 40"><circle cx="13" cy="13" r="7" fill="none" stroke="currentColor" stroke-width="3"/><path d="M18 18 34 34M28 28l4-4M24 24l3-3" stroke="currentColor" stroke-width="3" fill="none" stroke-linecap="round"/></svg>',
  lens: '<svg viewBox="0 0 40 40"><circle cx="20" cy="20" r="13" fill="currentColor" opacity=".35"/><circle cx="20" cy="20" r="13" fill="none" stroke="currentColor" stroke-width="3"/><path d="M13 16a9 9 0 0 1 8-5" stroke="#fff" fill="none" stroke-width="2" stroke-linecap="round"/></svg>',
  seal: '<svg viewBox="0 0 40 40"><circle cx="20" cy="20" r="14" fill="currentColor" opacity=".3"/><circle cx="20" cy="20" r="14" fill="none" stroke="currentColor" stroke-width="2.5"/><path d="M20 9l3 8 8 1-6 5 2 8-7-5-7 5 2-8-6-5 8-1z" fill="currentColor"/></svg>',
  note: '<svg viewBox="0 0 40 40"><path d="M10 6h16l5 5v23H10z" fill="currentColor" opacity=".25"/><path d="M10 6h16l5 5v23H10zM14 15h12M14 20h12M14 25h8" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
};
const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');
const UI = {
  panel: null, parent: null, target: null, locked: false, dlg: null, sel: null, jtab: 'Objectives', jsel: null, lastRegion: '', cine: false,
  show(id, on) { $(id).classList.toggle('hidden', !on); },
  lock() { if (NOLOCK) { UI.locked = true; return; } const c = $('view'); try { const p = c.requestPointerLock(); if (p && p.catch) p.catch(() => { }); } catch (e) { } },
  open(name, parent) {
    if (UI.panel && UI.panel !== name) UI.show(UI.panel, false);
    UI.panel = name; UI.parent = parent || null; UI.show(name, true);
    if (name !== 'reader' && name !== 'dialog' && document.pointerLockElement) document.exitPointerLock();
    if (name === 'pause') SAVE.write();
    if (name === 'inventory') UI.renderInv(); if (name === 'journal') UI.renderJournal(); if (name === 'settings') UI.syncSettings();
    if (name !== 'reader' && name !== 'dialog') AU.sfx('ui');
  },
  close() {
    if (!UI.panel) return; const p = UI.panel; UI.show(p, false); UI.panel = null;
    if (UI.parent) { const par = UI.parent; UI.parent = null; if (par === 'title') { UI.show('title', true); return; } UI.open(par); return; }
    if (G.mode === 'play') UI.lock();
  },
  toast(msg, kind) { if (SAVE.replaying) return; const d = document.createElement('div'); d.className = 'toast ' + (kind || ''); d.textContent = msg; const box = $('toasts'); box.appendChild(d); while (box.children.length > 4) box.removeChild(box.firstChild); setTimeout(() => d.classList.add('out'), 5200); setTimeout(() => d.remove(), 6000); },
  region(name) { const r = $('region'); r.querySelector('b').textContent = name; r.classList.remove('show'); void r.offsetWidth; r.classList.add('show'); },
  read(title, text, rec) { $('readTitle').textContent = title; $('readBody').innerHTML = esc(text).replace(/\n/g, '<br>'); $('readRec').textContent = rec || ''; UI.open('reader'); },
  dialog(who, lines) { UI.dlg = { who, lines, i: 0 }; $('dlgWho').textContent = who; $('dlgLine').textContent = lines[0]; UI.open('dialog'); },
  dialogNext() { const d = UI.dlg; if (!d) return; d.i++; if (d.i >= d.lines.length) { UI.dlg = null; UI.close(); } else { $('dlgLine').textContent = d.lines[d.i]; AU.sfx('ui'); } },
  refresh() {
    const n = G.fragCount(), gems = $('relics').querySelectorAll('i'), ids = ['frag_root', 'frag_tide', 'frag_sky'];
    gems.forEach((g, i) => g.classList.toggle('on', !!(G.inv[ids[i]] || G.placed[ids[i]])));
    $('relicTxt').textContent = n + ' / 3';
    const ob = G.objectives().find(o => !o.d); $('objective').textContent = ob ? ob.t : '';
    if (UI.panel === 'inventory') UI.renderInv(); if (UI.panel === 'journal') UI.renderJournal();
  },
  renderInv() {
    const cats = ['Relic Fragments', 'Ancient Keys', 'Puzzle Items', 'Hidden Artifacts']; let h = '';
    for (const c of cats) { const ids = Object.keys(ITEMS).filter(k => ITEMS[k].cat === c && G.inv[k]); h += '<h3>' + c + '</h3><div class="slots">'; if (!ids.length) h += '<span class="none">— nothing yet —</span>'; for (const id of ids) h += `<button class="slot${UI.sel === id ? ' sel' : ''}" data-id="${id}" style="color:${ITEMS[id].hex}" title="${esc(ITEMS[id].name)}">${ICONS[ITEMS[id].icon]}</button>`; h += '</div>'; }
    h += '<h3>Notes &amp; Inscriptions</h3><div class="slots">'; if (!G.notes.length) h += '<span class="none">— nothing yet —</span>';
    for (const id of G.notes) h += `<button class="slot${UI.sel === 'n:' + id ? ' sel' : ''}" data-id="n:${id}" style="color:#e8d9b0" title="${esc(NOTES[id].title)}">${ICONS.note}</button>`;
    $('invList').innerHTML = h + '</div>';
    const s = UI.sel, d = $('invDetail');
    if (s && s.startsWith('n:') && G.notes.includes(s.slice(2))) { const n = NOTES[s.slice(2)]; d.innerHTML = `<h2>${esc(n.title)}</h2><div class="tag">Inscription — ${n.cat}</div><p>${esc(n.text).replace(/\n/g, '<br>')}</p>`; }
    else if (s && G.inv[s]) { const it = ITEMS[s]; d.innerHTML = `<div class="big" style="color:${it.hex}">${ICONS[it.icon]}</div><h2>${esc(it.name)}</h2><div class="tag">${it.cat}</div><p>${esc(it.desc)}</p>`; }
    else d.innerHTML = '<p class="none">Select an item to examine it.</p><p class="none">Fragments placed at the Echo Gate: ' + G.placedCount() + ' / 3</p>';
  },
  renderJournal() {
    const tabs = ['Objectives', 'Clues', 'Lore']; $('jTabs').innerHTML = tabs.map(t => `<button class="${UI.jtab === t ? 'sel' : ''}" data-tab="${t}">${t}</button>`).join('');
    let l = '', r = '';
    if (UI.jtab === 'Objectives') { const obs = G.objectives(), cur = obs.findIndex(o => !o.d); obs.forEach((o, i) => { if (i <= cur || o.d || cur < 0) l += `<div class="obj ${o.d ? 'done' : i === cur ? 'cur' : ''}"><i></i>${esc(o.t)}</div>`; }); r = `<h2>The Wanderer's Journal</h2><p>Fragments recovered: ${G.fragCount()} / 3<br>Fragments set in the Gate: ${G.placedCount()} / 3<br>Hidden seals found: ${G.secrets()} / 4<br>Inscriptions read: ${G.notes.length} / ${Object.keys(NOTES).length}</p><p class="none">Clues and histories you read are copied here. Open the other tabs to review them.</p>`; }
    else { const ids = G.notes.filter(id => NOTES[id].cat === UI.jtab); if (!ids.length) l = '<span class="none">Nothing recorded yet. Read the glowing inscriptions you find.</span>'; if (!ids.includes(UI.jsel)) UI.jsel = ids[ids.length - 1] || null; for (const id of ids) l += `<button class="entry${UI.jsel === id ? ' sel' : ''}" data-note="${id}">${esc(NOTES[id].title)}</button>`; if (UI.jsel) { const n = NOTES[UI.jsel]; r = `<h2>${esc(n.title)}</h2><p>${esc(n.text).replace(/\n/g, '<br>')}</p>`; } }
    $('jLeft').innerHTML = l; $('jRight').innerHTML = r;
  },
  syncSettings() { $('optPreset').value = OPT.preset; $('optSens').value = OPT.sens; $('optVol').value = OPT.volume; $('optFov').value = OPT.fov; $('optInv').checked = OPT.invertY; $('optGuide').checked = OPT.guide !== false; $('optFps').checked = !!OPT.fps; $('fovVal').textContent = OPT.fov + '°'; },
  frame() {
    const play = G.mode === 'play', t = UI.target, lbl = t && !UI.panel ? t.label : '';
    $('prompt').classList.toggle('show', !!lbl); if (lbl) $('promptTxt').textContent = lbl; $('reticle').classList.toggle('hot', !!lbl);
    UI.show('resume', play && !UI.panel && !UI.locked && !UI.dragLook);
  },
  victory() {
    G.mode = 'end'; SAVE.clear(); if (document.pointerLockElement) document.exitPointerLock(); UI.show('hud', false);
    const s = Math.floor(G.time), mm = Math.floor(s / 60), ss = ('0' + s % 60).slice(-2);
    $('vStats').innerHTML = `<div><b>${mm}:${ss}</b><span>Time wandered</span></div><div><b>${G.secrets()} / 4</b><span>Hidden seals</span></div><div><b>${G.notes.length} / ${Object.keys(NOTES).length}</b><span>Inscriptions read</span></div>`;
    UI.show('victory', true);
  },
  init() {
    const c = $('view');
    document.addEventListener('pointerlockchange', () => {
      if (NOLOCK) return; UI.locked = document.pointerLockElement === c;
      if (!UI.locked && G.mode === 'play') { if (UI.panel === 'reader' || UI.panel === 'dialog') { UI.show(UI.panel, false); UI.panel = null; UI.dlg = null; } if (!UI.panel) { UI.escT = performance.now(); UI.open('pause'); } }
    });
    document.addEventListener('pointerlockerror', () => { UI.dragLook = true; UI.toast('Mouse capture unavailable — hold the left mouse button and drag to look (or use the arrow keys).', 'hint'); });
    document.addEventListener('mousemove', e => {
      if (UI.dragLook && !UI.locked && !NOLOCK && G.mode === 'play' && !UI.panel && (e.buttons & 1)) { const k = .0022 * OPT.sens; P.yaw -= e.movementX * k; P.pitch = clamp(P.pitch - e.movementY * k * (OPT.invertY ? -1 : 1), -1.5, 1.5); }
    });
    document.addEventListener('mousemove', e => { if (!UI.locked || NOLOCK || G.mode !== 'play' || (UI.panel && UI.panel !== 'dialog')) return; const k = .0022 * OPT.sens; P.yaw -= e.movementX * k; P.pitch = clamp(P.pitch - e.movementY * k * (OPT.invertY ? -1 : 1), -1.5, 1.5); });
    c.addEventListener('mousedown', e => { if (G.mode !== 'play') return; if (!UI.locked) { if (!UI.dragLook) UI.lock(); return; } if (e.button === 0) UI.act(); });
    $('resume').addEventListener('click', () => UI.lock());
    $('dialog').addEventListener('click', () => UI.dialogNext()); $('reader').addEventListener('click', () => UI.close());
    window.addEventListener('keydown', e => {
      const k = e.code; if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab'].includes(k)) e.preventDefault();
      if (G.mode !== 'play') { if (k === 'Escape' && UI.panel) UI.close(); return; }
      if (k === 'Escape') { if (performance.now() - (UI.escT || 0) < 350) return; if (UI.panel) UI.close(); else UI.open('pause'); return; }
      if (UI.panel === 'dialog') { if (!e.repeat && (k === 'KeyE' || k === 'Enter' || k === 'Space')) UI.dialogNext(); return; }
      if (UI.panel === 'reader') { if (!e.repeat && (k === 'KeyE' || k === 'Enter' || k === 'Space')) UI.close(); return; }
      if (k === 'KeyI' && !e.repeat) { if (UI.panel === 'inventory') UI.close(); else if (!UI.panel || UI.panel === 'journal') UI.open('inventory'); return; }
      if (k === 'KeyJ' && !e.repeat) { if (UI.panel === 'journal') UI.close(); else if (!UI.panel || UI.panel === 'inventory') UI.open('journal'); return; }
      if (UI.panel) return;
      if (k === 'KeyH' && !e.repeat) { GUIDE.hint(); return; }
      KEYS[k] = true; if (k === 'KeyE' && !e.repeat) UI.act();
    });
    window.addEventListener('keyup', e => { KEYS[e.code] = false; });
    window.addEventListener('blur', () => { for (const k in KEYS) KEYS[k] = false; });
    window.addEventListener('resize', resizeRenderer);
    $('invList').addEventListener('click', e => { const b = e.target.closest('[data-id]'); if (b) { UI.sel = b.dataset.id; AU.sfx(b.dataset.id.startsWith('n:') ? 'page' : 'ui'); UI.renderInv(); } });
    $('journal').addEventListener('click', e => { const tb = e.target.closest('[data-tab]'), n = e.target.closest('[data-note]'); if (tb) { UI.jtab = tb.dataset.tab; AU.sfx('page'); UI.renderJournal(); } else if (n) { UI.jsel = n.dataset.note; AU.sfx('page'); UI.renderJournal(); } });
    document.addEventListener('click', e => {
      const a = e.target.closest('[data-act]'); if (!a) return; const act = a.dataset.act;
      if (act === 'begin') { AU.init(); SAVE.clear(); startGame(); }
      else if (act === 'continue') { AU.init(); const d = SAVE.read(); startGame(); if (d) SAVE.replay(d); }
      else if (act === 'close') UI.close();
      else if (act === 'settings' || act === 'controls') { const par = G.mode === 'title' ? 'title' : 'pause'; if (par === 'title') UI.show('title', false); UI.open(act, par); }
      else if (act === 'inventory' || act === 'journal') UI.open(act);
      else if (act === 'unstuck') { P.pos.set(0, 0, 16); P.vel.set(0, 0, 0); P.grab = null; UI.close(); UI.toast('You find yourself back in the Courtyard.', 'hint'); }
      else if (act === 'restart') { if (a.dataset.sure) { SAVE.clear(); G.mode = 'end'; try { location.reload(); } catch (err) { } } else { a.dataset.sure = '1'; a.textContent = 'Really restart? Click again'; } }
    });
    $('optPreset').addEventListener('change', e => { OPT.preset = e.target.value; applyPreset(OPT.preset); saveOpts(); });
    $('optSens').addEventListener('input', e => { OPT.sens = +e.target.value; saveOpts(); });
    $('optVol').addEventListener('input', e => { OPT.volume = +e.target.value; AU.setVolume(OPT.volume); saveOpts(); });
    $('optFov').addEventListener('input', e => { OPT.fov = +e.target.value; $('fovVal').textContent = OPT.fov + '°'; saveOpts(); });
    $('optFps').addEventListener('change', e => { OPT.fps = e.target.checked; saveOpts(); });
    $('optGuide').addEventListener('change', e => { OPT.guide = e.target.checked; saveOpts(); });
    window.addEventListener('beforeunload', () => SAVE.write()); document.addEventListener('visibilitychange', () => { if (document.hidden) SAVE.write(); });
    $('optInv').addEventListener('change', e => { OPT.invertY = e.target.checked; saveOpts(); });
  },
  act() {
    if (G.mode !== 'play' || UI.panel) return; const t = UI.target || pickInter(); if (!t || !t.label) return; t.use();
  },
};
