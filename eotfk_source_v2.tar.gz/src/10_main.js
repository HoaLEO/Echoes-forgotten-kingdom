// ============================================================================
// Boot, main loop, finale
// ============================================================================
const REGION_NAMES = { court: 'The Forgotten Courtyard', forest: 'The Whispering Forest', temple: 'The Sunken Temple', sanct: 'The Celestial Sanctuary' };
function startGame() {
  UI.show('title', false); UI.show('hud', true); G.mode = 'play'; P.frozen = false; P.pos.set(0, 0, 16); P.yaw = 0; P.pitch = 0; UI.lock(); UI.refresh();
  R.fade = 1; R.fadeColor.set(0, 0, 0); tween(2.2, k => { R.fade = 1 - k; });
  UI.toast('Move the mouse to look around · WASD to walk · E to interact', 'hint');
  setTimeout(() => UI.toast('You have found the ruins of a forgotten kingdom. Look for glowing inscriptions — and for anyone who is still here.', 'hint'), 1800);
}
function startFinale() {
  G.mode = 'cine'; G.flag('finale'); P.frozen = true; P.grab = null; UI.show('hud', false); AU.sfx('finale');
  const { DY, GZ, seal, sg, portal, gateGlow, sockets } = GATE, p0 = P.pos.clone(), y0 = P.yaw, pi0 = P.pitch, dur = 15;
  const yawT = y0 + Math.atan2(Math.sin(-y0), Math.cos(-y0)); portal.visible = true; let bt = 0;
  tween(dur, (_, lin) => {
    const t = lin * dur, a = sstep(0, 3, t);
    P.pos.set(lerp(p0.x, 0, a), lerp(p0.y, DY, a), lerp(p0.z, GZ + 9.5, a) - sstep(10, 15, t) * 8.6); P.yaw = lerp(y0, yawT, a); P.pitch = lerp(pi0, .16, a) - sstep(10, 14, t) * .1;
    const f = sstep(1, 4.5, t); for (const s of sockets) { s.rel.position.set(lerp(s.x, 0, f), DY + 1.55 + f * 2, lerp(s.z, GZ + .7, f)); s.rel.scale.setScalar(1 + f * .6); }
    setGlyph(sg, '#8fffe0', 2.6 + sstep(3, 6, t) * 6); R.shake = .05 * sstep(4, 6, t) * (1 - sstep(8.5, 10, t));
    seal.position.y = DY - sstep(5, 9.5, t) * 8.2; portal.material.uniforms.uOn.value = sstep(5.5, 9, t); gateGlow.power = 1 + sstep(5, 9, t) * 2.5;
    R.bloomMul = 1 + sstep(5, 12, t) * 2.2; R.exposureMul = 1 + sstep(9, 14, t) * .8;
    if (t > 4.5 && t < 12 && W.time - bt > .12) { bt = W.time; burst(new V3((Math.random() - .5) * 3.4, DY + .5 + Math.random() * 6, GZ + .4), Math.random() < .5 ? '#8fffe0' : '#ffe9a0', 14, 3.5, 2.2, .6); if (f >= 1) for (const s of sockets) s.rel.visible = false; }
    R.fadeColor.set(1, 1, 1); R.fade = sstep(11.5, 14.8, t);
  }, () => { R.shake = 0; UI.victory(); });
}
function boot() {
  const bar = $('loadBar'), msg = $('loadMsg'), steps = [];
  const prog = v => { bar.style.width = Math.round(v * 100) + '%'; };
  if (!PRESETS[OPT.preset]) OPT.preset = 'high';
  let ok = true;
  try { R.presetName = OPT.preset; R.preset = PRESETS[OPT.preset]; initRenderer($('view')); } catch (e) { ok = false; msg.textContent = 'This game needs a WebGL2-capable browser and GPU. (' + e.message + ')'; console.error(e); }
  if (!ok) return;
  steps.push(() => { msg.textContent = 'Carving stone…'; buildMaterials(512); prog(.18); });
  steps.push(() => { msg.textContent = 'Raising the kingdom…'; buildWorld(prog); });
  steps.push(() => { msg.textContent = 'Lighting the crystals…'; UI.init(); applyPreset(OPT.preset); P.camY = P.pos.y; updateEnvironment(10, P.pos.x, P.pos.y, P.pos.z, 0); R.renderer.compile(W.scene, R.camera); UI.refresh(); });
  steps.push(() => { UI.show('loading', false); UI.show('title', true); { const d = SAVE.read(), b = $('btnContinue'); if (d) { b.classList.remove('hidden'); b.textContent = 'Continue · ' + (d.frags || 0) + '/3 fragments · ' + Math.floor((d.time || 0) / 60) + ' min'; document.querySelector('[data-act=begin]').textContent = 'New journey'; } } P.frozen = true; requestAnimationFrame(frame); window.__EOTFK.ready = true; });
  const run = i => { if (i >= steps.length) return; try { steps[i](); } catch (e) { msg.textContent = 'Failed to build the world: ' + e.message; console.error(e); return; } setTimeout(() => run(i + 1), 30); };
  setTimeout(() => run(0), 30);
}
let lastT = 0;
function frame(now) {
  requestAnimationFrame(frame);
  const raw = now - lastT, dt = Math.min(.05, Math.max(0, raw / 1000)); lastT = now;
  { const F = frame, el = $('fps'); F.n = (F.n || 0) + 1; F.acc = (F.acc || 0) + raw; F.worst = Math.max(F.worst || 0, raw); if (F.acc > 500) { if (OPT.fps) { const i = R.renderer.info.render; el.textContent = Math.round(F.n * 1000 / F.acc) + ' fps  (worst ' + Math.round(F.worst) + ' ms)\n' + (i.triangles / 1e6).toFixed(2) + 'M tris · ' + i.calls + ' calls · ' + R.presetName; } el.classList.toggle('hidden', !OPT.fps || G.mode !== 'play'); F.n = F.acc = F.worst = 0; } } if (!window.__EOTFK.manual) stepFrame(dt);
}
function stepFrame(dt) {
  W.time += dt; uTime.value = W.time;
  const sim = G.mode === 'play' && !UI.panel;
  if (sim) { G.time += dt; updatePlayer(dt); SAVE.frame(dt); GUIDE.frame(dt); }
  if (sim || G.mode === 'cine') updateTweens(dt);
  for (const u of W.updaters) u(dt, W.time);
  updateBursts(dt); updateCamera(dt); R.camera.updateMatrixWorld(); UI.target = sim ? pickInter() : null;
  const cam = R.camera;
  if (G.mode === 'title') { const a = W.time * .05; cam.position.set(Math.sin(a) * 6, 3.4 + Math.sin(W.time * .2) * .3, 17 + Math.cos(a) * 2); cam.rotation.set(.03, Math.sin(a) * .28, 0); }
  const px = cam.position.x, py = P.pos.y, pz = cam.position.z, w = regionWeights(px, py, pz);
  const indoor = (px > 56.4 && px < 97 && pz > -20 && pz < 22.6 && py < 4) || (px > -14 && px < -6 && pz > 22 && pz < 30.4) ? 1 : 0;
  R.indoor = lerp(R.indoor || 0, indoor, 1 - Math.exp(-dt * 2));
  updateEnvironment(dt, px, py, pz, R.indoor);
  let ng = 99; for (let i = 0; i < 3 && i < W.glows.length; i++) { const g = W.glows[i]; if (g.on && g.power > 0) ng = Math.min(ng, g.pos.distanceTo(cam.position)); }
  AU.update(dt, w, R.indoor, ng);
  if (G.mode === 'play') { let best = 'court', bv = 0; for (const k in w) if (w[k] > bv) { bv = w[k]; best = k; } if (bv > .62 && best !== G.region) { G.region = best; UI.region(REGION_NAMES[best]); } }
  UI.frame(dt);
  UPH.value = R.h / (2 * Math.tan(cam.fov * Math.PI / 360));
  if (!window.__EOTFK.noRender) renderFrame();
}
window.__EOTFK = { G, P, W, R, UI, AU, RUNES, LIGHT, PLATES, GATE, ITEMS, NOTES, OPT, stepFrame, traceBeam, terrainH, groundAt, startGame, pickInter, snapshot, SAVE, GUIDE, NAV, inPlay, regionWeights };
boot();
