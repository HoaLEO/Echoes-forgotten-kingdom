import fs from 'fs';
const tpl = fs.readFileSync('template.html', 'utf8');
const three = fs.readFileSync('vendor/three.r180.js', 'utf8');
const game = fs.readdirSync('src').filter(f => f.endsWith('.js')).sort().map(f => `// ---- ${f} ----\n` + fs.readFileSync('src/' + f, 'utf8')).join('\n');
if (/<\/script/i.test(three) || /<\/script/i.test(game)) throw new Error('script terminator inside bundle');
const out = tpl.replace('/*__THREE__*/', () => three).replace('/*__GAME__*/', () => game);
fs.mkdirSync('dist', { recursive: true });
fs.writeFileSync('dist/index.html', out);
console.log('built dist/index.html', (out.length / 1024).toFixed(0) + ' KB');
