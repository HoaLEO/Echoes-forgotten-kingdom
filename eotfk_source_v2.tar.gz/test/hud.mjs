import { open, begin } from './lib.mjs';
const { browser, page, logs } = await open(960, 540, 'medium');
await begin(page);
await page.evaluate(() => { const E = window.__EOTFK; E.P.yaw = .5; for (let i = 0; i < 5; i++) E.stepFrame(.05); window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyH' })); E.stepFrame(.05); });
await page.screenshot({ path: 'test/u_hud2.png' });
console.log(await page.evaluate(() => JSON.stringify([window.__EOTFK.GUIDE.state().slice(0, 2), window.__EOTFK.GUIDE.aim, document.getElementById('cmpDist').textContent])));
console.log(logs.join('\n') || 'no errors'); await browser.close();
