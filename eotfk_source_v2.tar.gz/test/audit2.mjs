import { open, begin, view } from './lib.mjs';
import fs from 'fs';
const { browser, page, logs } = await open(960, 540, 'high');
await begin(page);
const V = [[0, 2, 0, 4, 'a01_gate'], [8, 0, -90, 0, 'a02_east'], [-34, -4, 90, 0, 'a03_trail'], [-64, 3, 90, 0, 'a04_glade'], [-56, 24, 143, -5, 'a05_hollow'], [-40, -16, 27, 0, 'a06_grove'], [58, 0, -90, 0, 'a07_hall', -1.1], [77.5, 0, -90, -8, 'a08_mirrors', -1.1], [86, -12, 0, 0, 'a09_vault', -1.1], [14, -50, 0, 10, 'a10_stair'], [14, -88, 63, 0, 'a11_summit', 28], [0, -90, 180, -5, 'a12_vista', 28]];
const stats = {};
for (const v of V) { await view(page, v[0], v[1], v[2], v[3], v[4] + '.jpg', v[5]);
  stats[v[4]] = await page.evaluate(() => { const E = window.__EOTFK, r = E.R.renderer, gl = r.getContext(); r.info.autoReset = false; r.info.reset(); E.stepFrame(.016); const c = r.info.render.calls, t = r.info.render.triangles; r.info.reset(); gl.finish(); const t0 = performance.now(); for (let i = 0; i < 4; i++) E.stepFrame(.016); gl.finish(); const ms = (performance.now() - t0) / 4; r.info.autoReset = true; return { calls: c, tris: t, ms: +ms.toFixed(0), lights: (() => { let n = 0; E.W.scene.traverse(o => { if (o.isLight && o.visible) n++; }); return n; })() }; }); }
console.log(JSON.stringify(stats, null, 0));
console.log('globals', await page.evaluate(() => [typeof applyPreset, typeof PRESETS].join()));
// preset cost at glade
const pre = await page.evaluate(() => { if (typeof applyPreset !== 'function') return 'n/a'; const E = window.__EOTFK, r = E.R.renderer, gl = r.getContext(), P = E.P, o = {}; P.pos.set(-64, E.groundAt(-64, 3, 1e3, 0), 3); P.yaw = Math.PI / 2; for (const p of ['low', 'medium', 'high', 'ultra']) { applyPreset(p); for (let i = 0; i < 3; i++) E.stepFrame(.016); gl.finish(); const t0 = performance.now(); for (let i = 0; i < 4; i++) E.stepFrame(.016); gl.finish(); o[p] = +((performance.now() - t0) / 4).toFixed(0); } applyPreset('high'); return o; });
console.log('preset ms (software GL, relative only)', JSON.stringify(pre));
console.log('mem', await page.evaluate(() => { const i = window.__EOTFK.R.renderer.info.memory; let meshes = 0, mats = new Set(), shadowCasters = 0; window.__EOTFK.W.scene.traverse(o => { if (o.isMesh) { meshes++; mats.add(o.material); if (o.castShadow) shadowCasters++; } }); return JSON.stringify({ geoms: i.geometries, tex: i.textures, meshes, mats: mats.size, shadowCasters }); }));
// UI screenshots
await page.evaluate(() => { const E = window.__EOTFK; E.P.pos.set(0, 0, 14); E.P.yaw = 0; E.G.give && 0; E.stepFrame(.02); E.UI.open('journal'); E.stepFrame(.02); }); await page.screenshot({ path: 'test/u_journal.png' });
await page.evaluate(() => { const E = window.__EOTFK; E.UI.close(); E.UI.open('inventory'); E.stepFrame(.02); }); await page.screenshot({ path: 'test/u_inv.png' });
await page.evaluate(() => { const E = window.__EOTFK; E.UI.close(); E.UI.open('pause'); E.stepFrame(.02); }); await page.screenshot({ path: 'test/u_pause.png' });
await page.evaluate(() => { const E = window.__EOTFK; E.UI.close(); E.UI.open('settings', 'pause'); E.stepFrame(.02); }); await page.screenshot({ path: 'test/u_set.png' });
await page.evaluate(() => { const E = window.__EOTFK; E.UI.close(); E.UI.close(); E.stepFrame(.02); }); await page.screenshot({ path: 'test/u_hud.png' });
console.log(logs.join('\n') || 'no errors'); await browser.close();
