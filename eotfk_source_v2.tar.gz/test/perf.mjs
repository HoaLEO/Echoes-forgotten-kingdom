// Render-load statistics per viewpoint (triangles / draw calls incl. shadow pass). Software GL: timings are NOT representative.
import { open, begin, view } from './lib.mjs';
const preset = process.argv[2] || 'high', shots = process.argv[3] === 'shots';
const { browser, page, logs } = await open(+(process.env.W || 960), +(process.env.H || 540), preset);
await begin(page);
const V = [[0, 2, 0, 4, 'gate'], [8, 0, -90, 0, 'east'], [-34, -4, 90, 0, 'trail'], [-64, 3, 90, 0, 'glade'], [-56, 24, 143, -5, 'hollow'], [-40, -16, 27, 0, 'grove'], [58, 0, -90, 0, 'hall', -1.1], [77.5, 0, -90, -8, 'mirrors', -1.1], [86, -12, 0, 0, 'vault', -1.1], [36, -70, 20, 5, 'stair'], [14, -88, 63, 0, 'summit', 28], [0, -90, 180, -5, 'vista', 28]];
const only = process.env.VIEWS ? process.env.VIEWS.split(',') : null; if (process.env.EXTRA) V.push(...JSON.parse(process.env.EXTRA));
const out = [];
for (const v of V) { if (only && !only.includes(v[4])) continue; await view(page, v[0], v[1], v[2], v[3], shots ? 'p_' + v[4] + '.jpg' : null, v[5]);
  out.push(v[4] + ': ' + await page.evaluate(() => { const E = window.__EOTFK, r = E.R.renderer; r.info.autoReset = false; r.info.reset(); E.stepFrame(.016); const c = r.info.render.calls, t = r.info.render.triangles; r.info.autoReset = true; return (t / 1e6).toFixed(2) + 'M tris, ' + c + ' calls'; })); }
console.log(preset + ' | ' + out.join(' | ')); console.log(logs.join('\n') || 'no errors'); await browser.close();
