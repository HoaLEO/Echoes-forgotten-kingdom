import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
export async function open(w = 960, h = 540, preset = 'high') {
  const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'] });
  const page = await browser.newPage({ viewport: { width: w, height: h } });
  const logs = [];
  page.on('console', m => { const t = m.text(); if ((m.type() === 'error' || m.type() === 'warning') && !/GPU stall|ReadPixels/.test(t)) logs.push(m.type() + ': ' + t.slice(0, 900)); });
  page.on('pageerror', e => logs.push('PAGEERROR: ' + e.message + '\n' + (e.stack || '').slice(0, 900)));
  page.on('request', r => { if (!r.url().startsWith('file:')) logs.push('EXTERNAL REQUEST ' + r.url()); });
  await page.addInitScript(p => { try { localStorage.setItem('eotfk_opts', JSON.stringify({ preset: p })); } catch (e) { } }, preset);
  await page.goto('file:///home/claude/eotfk/dist/index.html#test');
  await page.waitForFunction(() => window.__EOTFK && window.__EOTFK.ready, null, { timeout: 180000 });
  await page.evaluate(() => { window.__EOTFK.manual = true; });
  return { browser, page, logs };
}
export async function begin(page) {
  await page.evaluate(() => document.querySelector('[data-act=begin]').click()); await page.waitForTimeout(300);
  await page.evaluate(() => { const E = window.__EOTFK; E.R.fade = 0; E.W.tweens.length = 0; });
}
import fs from 'fs';
export async function view(page, x, z, yawDeg, pitchDeg = 0, file, y = null) {
  const data = await page.evaluate(([x, z, yaw, pitch, y]) => { const E = window.__EOTFK, P = E.P; if (x != null) { P.pos.set(x, y == null ? E.groundAt(x, z, 1e3, 0) : y, z); P.vel.set(0, 0, 0); P.yaw = yaw * Math.PI / 180; P.pitch = pitch * Math.PI / 180; P.camY = P.pos.y; } for (let i = 0; i < 6; i++) E.stepFrame(.3); E.stepFrame(.016); return document.getElementById('view').toDataURL('image/jpeg', .9); }, [x, z, yawDeg, pitchDeg, y]);
  if (file) fs.writeFileSync('test/' + file.replace('.png', '.jpg'), Buffer.from(data.split(',')[1], 'base64'));
}
