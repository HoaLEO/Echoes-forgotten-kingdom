import { open, begin } from './lib.mjs';
const { browser, page, logs } = await open(640, 360, 'high');
await begin(page); await page.evaluate(() => { window.__EOTFK.noRender = true; });
console.log(await page.evaluate(() => { const E = window.__EOTFK, P = E.P, o = {}; 
  o.inst = Object.entries(E.W.instMeshes).map(([k, m]) => { const g = m.geometry, t = (g.index ? g.index.count : g.attributes.position.count) / 3; return [k, m.count, t, Math.round(m.count * t / 1000) + 'k', m.frustumCulled, m.castShadow]; });
  let other = 0; E.W.scene.traverse(m => { if (m.isMesh && !m.isInstancedMesh) { const g = m.geometry; other += (g.index ? g.index.count : g.attributes.position.count) / 3; } }); o.otherTrisK = Math.round(other / 1000);
  const kd = c => window.dispatchEvent(new KeyboardEvent('keydown', { code: c })), ku = c => window.dispatchEvent(new KeyboardEvent('keyup', { code: c }));
  o.summit = []; for (let a = 0; a < 24; a++) { const an = a / 24 * 6.283; P.pos.set(0, 28, -95); P.vel.set(0, 0, 0); kd('KeyW'); kd('ShiftLeft'); P.yaw = Math.atan2(-Math.sin(an), -Math.cos(an)); for (let i = 0; i < 350; i++) { if (i % 12 === 0) kd('Space'); else ku('Space'); E.stepFrame(.04); } ku('KeyW'); ku('ShiftLeft'); if (P.pos.y < 24) o.summit.push([a, +P.pos.x.toFixed(0), +P.pos.y.toFixed(0), +P.pos.z.toFixed(0)]); }
  // forest west leak: path trace
  P.pos.set(-70, E.groundAt(-70, 4, 1e3, 0), 4); P.vel.set(0, 0, 0); o.forest = []; for (let a = 0; a < 16; a++) { const an = a / 16 * 6.283; P.pos.set(-70, E.groundAt(-70, 4, 1e3, 0), 4); kd('KeyW'); kd('ShiftLeft'); P.yaw = an; for (let i = 0; i < 700; i++) { if (i % 12 === 0) kd('Space'); else ku('Space'); E.stepFrame(.04); } ku('KeyW'); ku('ShiftLeft'); o.forest.push([+P.pos.x.toFixed(0), +P.pos.y.toFixed(0), +P.pos.z.toFixed(0), E.G.region]); }
  return JSON.stringify(o); }));
await browser.close();
