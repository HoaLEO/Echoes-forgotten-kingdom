import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
const url = 'file:///home/claude/eotfk/dist/index.html#test';
const browser = await chromium.launch({ executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--enable-webgl'] });
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
const logs = [];
page.on('console', m => { const t = m.text(); if (m.type() === 'error' || m.type() === 'warning') logs.push(m.type() + ': ' + t.slice(0, 600)); });
page.on('pageerror', e => logs.push('PAGEERROR: ' + e.message + '\n' + (e.stack || '').slice(0, 800)));
page.on('requestfailed', r => logs.push('REQFAILED ' + r.url()));
page.on('request', r => { if (!r.url().startsWith('file:')) logs.push('EXTERNAL REQUEST ' + r.url()); });
const t0 = Date.now();
await page.goto(url);
try { await page.waitForFunction(() => window.__EOTFK && window.__EOTFK.ready, null, { timeout: 180000 }); } catch (e) { logs.push('TIMEOUT waiting ready: ' + await page.evaluate(() => document.getElementById('loadMsg').textContent)); }
console.log('load ms', Date.now() - t0);
await page.waitForTimeout(1500);
await page.screenshot({ path: 'test/shot_title.png' });
console.log(await page.evaluate(() => { const E = window.__EOTFK; if (!E || !E.ready) return 'not ready'; const i = E.R.renderer.info; return JSON.stringify({ calls: i.render.calls, tris: i.render.triangles, geoms: i.memory.geometries, tex: i.memory.textures, colliders: E.W.colliders.length, inter: E.W.inter.length, glows: E.W.glows.length, inst: Object.fromEntries(Object.entries(E.W.instMeshes).map(([k, m]) => [k, m.count + '/' + m.chunks.length])) }); }));
console.log(logs.join('\n') || 'no console errors');
await browser.close();
