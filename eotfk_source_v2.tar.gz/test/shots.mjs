import { open, begin, view } from './lib.mjs';
const { browser, page, logs } = await open();
await begin(page);
const V = JSON.parse(process.argv[2]);
for (const v of V) await view(page, v[0], v[1], v[2], v[3], v[4], v[5]);
console.log(logs.join('\n') || 'no errors');
await browser.close();
