import { open, begin } from './lib.mjs';
const { browser, page, logs } = await open(640, 360, 'low');
await begin(page); await page.evaluate(() => { window.__EOTFK.noRender = true; });
console.log(JSON.stringify(await page.evaluate(() => { const E = window.__EOTFK, out = {};
  out.th = [[30, 0], [33, 0], [40, 0], [44, 8.5], [65, 18]].map(p => +E.terrainH(p[0], p[1]).toFixed(2));
  out.g = [[40, 0], [44, 8.5], [65, 18], [50, 11]].map(p => +E.groundAt(p[0], p[1], 5, 0).toFixed(2));
  const P = E.P; P.pos.set(26, 0, 0); P.vel.set(0, 0, 0); P.yaw = -Math.PI / 2; window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyW' })); const tr = []; for (let i = 0; i < 60; i++) { E.stepFrame(.04); if (i % 6 === 0) tr.push([+P.pos.x.toFixed(1), +P.pos.y.toFixed(2), P.onGround]); } window.dispatchEvent(new KeyboardEvent('keyup', { code: 'KeyW' })); out.tr = tr;
  // grab test
  const s = E.PLATES.stones[0]; P.pos.set(s.x + 1.6, 28, s.z); P.yaw = Math.PI / 2; P.pitch = -.45; E.stepFrame(.02); const pk = E.pickInter(); out.pick = pk ? pk.label : null; out.locked = E.UI.locked;
  return out; })));
await browser.close();
