import { open, begin } from './lib.mjs';
const { browser, page, logs } = await open(640, 360, 'low');
await begin(page); await page.evaluate(() => { window.__EOTFK.noRender = true; });
const ev = (fn, a) => page.evaluate(fn, a);
const out = {};
// helper injected
await ev(() => { const E = window.__EOTFK, P = E.P; const kd = c => window.dispatchEvent(new KeyboardEvent('keydown', { code: c })), ku = c => window.dispatchEvent(new KeyboardEvent('keyup', { code: c }));
  window.A = { kd, ku, put(x, z, y) { P.pos.set(x, y == null ? E.groundAt(x, z, 1e3, 0) : y, z); P.vel.set(0, 0, 0); P.onGround = true; P.grab = null; },
    go(tx, tz, secs, dt = .04, jump = false, sprint = false) { kd('KeyW'); if (sprint) kd('ShiftLeft'); let i = 0, n = secs / dt; for (; i < n; i++) { P.yaw = Math.atan2(-(tx - P.pos.x), -(tz - P.pos.z)); if (jump && i % 12 === 0) kd('Space'); else ku('Space'); E.stepFrame(dt); if (Math.hypot(tx - P.pos.x, tz - P.pos.z) < .8) break; } ku('KeyW'); ku('ShiftLeft'); ku('Space'); return [+P.pos.x.toFixed(2), +P.pos.y.toFixed(2), +P.pos.z.toFixed(2)]; } }; });
// 1. sequence-break probe: from courtyard, push in 32 directions with jumping+sprinting; where can we get without keys?
out.escape = await ev(() => { const E = window.__EOTFK, P = E.P, res = []; for (let a = 0; a < 32; a++) { const an = a / 32 * 6.283; A.put(0, 4); const p = A.go(Math.sin(an) * 300, Math.cos(an) * 300, 45, .04, true, true); const inTemple = p[0] > 34, summit = p[1] > 15; if (inTemple || summit || Math.hypot(p[0], p[2]) > 60) res.push([a, ...p, E.G.region]); } return res; });
// 2. frame-rate independence: jump apex and causeway gap at different dt
out.jump = await ev(() => { const E = window.__EOTFK, P = E.P, r = {}; for (const dt of [1 / 240, 1 / 144, 1 / 60, 1 / 30, .05]) { A.put(0, 10); const y0 = P.pos.y; A.kd('Space'); let mx = 0; for (let t = 0; t < 1.2; t += dt) { E.stepFrame(dt); A.ku('Space'); mx = Math.max(mx, P.pos.y - y0); } r[(1 / dt).toFixed(0) + 'fps'] = +mx.toFixed(3); } return r; });
out.speed = await ev(() => { const E = window.__EOTFK, P = E.P, r = {}; for (const dt of [1 / 240, 1 / 60, 1 / 30, .05]) { A.put(-8, 10); A.kd('KeyD'); P.yaw = 0; for (let t = 0; t < 2; t += dt) E.stepFrame(dt); A.ku('KeyD'); r[(1 / dt).toFixed(0) + 'fps'] = +(P.pos.x + 8).toFixed(2); } return r; });
// 3. temple: open door via flags? use real key give + door use is covered by play.mjs; here teleport inside and test water traps
out.gap = await ev(() => { const E = window.__EOTFK, P = E.P, r = {}; 
  // walk (no jump) across causeway: should fall in gap
  A.put(42.5, 0, -1.1); r.walkNoJump = A.go(54, 0, 8); 
  // from in the gap water, try to get back out west / east without and with jumping
  A.put(46.9, 0); r.inGapY = +P.pos.y.toFixed(2); r.outWest = A.go(30, 0, 25, .04, true); A.put(46.9, 0); r.outEast = A.go(60, 0, 25, .04, true);
  // from open water beside causeway
  A.put(44, 6); r.sideY = +P.pos.y.toFixed(2); r.sideOutWest = A.go(30, 0, 30, .04, true);
  // jump the gap at various dt (sprint+jump at edge)
  r.jumpGap = {}; for (const dt of [1 / 144, 1 / 60, 1 / 30]) for (const sprint of [false, true]) { A.put(42.5, 0, -1.1); A.kd('KeyW'); if (sprint) A.kd('ShiftLeft'); P.yaw = -Math.PI / 2; let jumped = false; for (let t = 0; t < 3; t += dt) { if (!jumped && P.pos.x > 45.6) { A.kd('Space'); jumped = true; } E.stepFrame(dt); A.ku('Space'); } A.ku('KeyW'); A.ku('ShiftLeft'); r.jumpGap[(1 / dt).toFixed(0) + (sprint ? 'sprint' : 'walk')] = [+P.pos.x.toFixed(1), +P.pos.y.toFixed(2)]; }
  return r; });
// flooded vault exit
out.vault = await ev(() => { const E = window.__EOTFK, P = E.P; A.put(65, 18); const a = [+P.pos.y.toFixed(2)]; return { y: a, back: A.go(65, 6, 25, .04, false) }; });
// 4. mirrors: enumerate all states
out.mirrors = await ev(() => { const E = window.__EOTFK, L = E.LIGHT; const save = L.mirrors.map(m => [m.a, m.k]); const on0 = L.on; L.on = true; let sol = [], n = 0; const N = 8; for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) for (let c = 0; c < N; c++) { [a, b, c].forEach((k, i) => { L.mirrors[i].a = k * Math.PI / 4; }); const r = E.traceBeam(); n++; if (r.hit) sol.push([a, b, c]); } L.mirrors.forEach((m, i) => { m.a = save[i][0]; m.k = save[i][1]; }); L.on = on0; return { states: n, solutions: sol, init: save.map(s => s[1]) }; });
// 5. plates: stone edge cases
out.stones = await ev(() => { const E = window.__EOTFK, P = E.P, PL = E.PLATES, r = {}; const Y = 28; const s = PL.stones[0];
  const grab = st => { A.put(st.x + 1.6, st.z, Y); P.yaw = Math.PI / 2; P.pitch = -.45; E.stepFrame(.02); const t = E.pickInter(); if (t !== st.inter) return 'nopick:' + (t && t.label); A.kd('KeyE'); A.ku('KeyE'); return P.grab === st; };
  r.grab = grab(s);
  // drag toward the cliff edge for 20s
  r.dragEdge = A.go(s.x + 60, s.z, 20); r.stoneAfter = [+s.x.toFixed(1), +s.z.toFixed(1)]; r.stillHeld = P.grab === s;
  if (P.grab) { A.kd('KeyE'); A.ku('KeyE'); } r.regrab = grab(s); if (P.grab) { A.kd('KeyE'); A.ku('KeyE'); }
  // open inventory while holding
  grab(s); A.kd('KeyI'); A.ku('KeyI'); r.panelWhileHold = E.UI.panel; r.heldInPanel = P.grab === s; A.kd('KeyI'); A.ku('KeyI'); if (P.grab) { A.kd('KeyE'); A.ku('KeyE'); }
  // push stone into another stone
  const s2 = PL.stones[1]; s.x = s2.x + 1.3; s.z = s2.z; E.stepFrame(.02); r.g2 = grab(s); r.pushInto = A.go(s2.x - 5, s2.z, 5); r.overlap = +Math.hypot(s.x - s2.x, s.z - s2.z).toFixed(2); if (P.grab) { A.kd('KeyE'); A.ku('KeyE'); }
  // can the player get boxed in? stand between stone and wall
  // two stones on one plate
  const p = PL.plates[0]; s.x = p.x; s.z = p.z; s2.x = p.x + .3; s2.z = p.z; for (let i = 0; i < 5; i++) E.stepFrame(.05); r.twoOnOne = PL.plates.map(q => q.state);
  return r; });
// 6. fall off summit with sprint+jump
out.summit = await ev(() => { let esc = 0, minY = 99; const E = window.__EOTFK, P = E.P; for (let a = 0; a < 24; a++) { const an = a / 24 * 6.283; A.put(0, -95, 28); const p = A.go(Math.sin(an) * 200, -95 + Math.cos(an) * 200, 14, .04, true, true); minY = Math.min(minY, p[1]); if (p[1] < 20) esc++; } return { esc, minY }; });
// 7. large dt tunnelling: sprint into courtyard walls at dt .05
out.tunnel = await ev(() => { const E = window.__EOTFK, P = E.P, r = []; for (const [tx, tz] of [[0, 60], [60, 10], [-60, 20], [20, -60]]) { A.put(0, 4); r.push(A.go(tx, tz, 20, .05, false, true)); } return r; });
// 8. sim CPU cost
out.cpu = await ev(() => { const E = window.__EOTFK, r = {}; for (const [n, x, z, y] of [['court', 0, 10], ['forest', -62, 2], ['temple', 80, 0, -1.1], ['sanct', 0, -95, 28]]) { A.put(x, z, y); for (let i = 0; i < 10; i++) E.stepFrame(.016); const t = performance.now(); for (let i = 0; i < 300; i++) E.stepFrame(.016); r[n] = +((performance.now() - t) / 300).toFixed(3); } r.updaters = E.W.updaters.length; r.inter = E.W.inter.length; r.colliders = E.W.colliders.length; return r; });
for (const k in out) console.log(k, JSON.stringify(out[k]));
console.log(logs.join('\n') || 'no errors'); await browser.close();
