// Boundary / physics regression: sprint-jump in all directions from several places; player must stay inside the explorable world.
import { open, begin } from './lib.mjs';
const { browser, page, logs } = await open(640, 360, 'low');
await begin(page); await page.evaluate(() => { window.__EOTFK.noRender = true; });
const r = await page.evaluate(() => { const E = window.__EOTFK, P = E.P, o = { bad: [] };
  const kd = c => window.dispatchEvent(new KeyboardEvent('keydown', { code: c })), ku = c => window.dispatchEvent(new KeyboardEvent('keyup', { code: c }));
  const starts = [['court', 0, 4, null, 0, 6], ['glade', -70, 4, null, -3, 6], ['grove', -44, -24, null, -3, 6], ['hollow', -60, 30, null, -3, 6], ['path', 40, -58, null, 0, 30], ['summit', 0, -95, 28, 26, 30], ['templeYard', 44, 8, null, -4, 6]];
  for (const [name, x, z, y, minY, maxY] of starts) for (let a = 0; a < 32; a++) { const an = a / 32 * 6.283; P.pos.set(x, y == null ? E.groundAt(x, z, 1e3, 0) : y, z); P.vel.set(0, 0, 0); P.onGround = true; P.safe.copy(P.pos); P.safeT = 0; kd('KeyW'); kd('ShiftLeft'); P.yaw = an; let hi = -99, lo = 99;
    for (let i = 0; i < 500; i++) { if (i % 10 === 0) kd('Space'); else ku('Space'); E.stepFrame(.04); hi = Math.max(hi, P.pos.y); lo = Math.min(lo, P.pos.y); if (!E.inPlay(P.pos.x, P.pos.z)) { o.bad.push([name, a, 'left world', +P.pos.x.toFixed(1), +P.pos.z.toFixed(1)]); break; } }
    ku('KeyW'); ku('ShiftLeft'); ku('Space');
    if (name !== 'path' && name !== 'court' && name !== 'summit' && (hi > maxY + 2 || lo < minY)) o.bad.push([name, a, 'height', +lo.toFixed(1), +hi.toFixed(1)]);
    if (name === 'court' && hi > 12 && !E.G.flags.door_stair) o.bad.push([name, a, 'climbed without key', +hi.toFixed(1)]); }
  o.jump = {}; for (const dt of [1 / 240, 1 / 60, 1 / 30, .05]) { P.pos.set(0, 0, 10); P.vel.set(0, 0, 0); P.onGround = true; kd('Space'); let mx = 0; for (let t = 0; t < 1.2; t += dt) { E.stepFrame(dt); ku('Space'); mx = Math.max(mx, P.pos.y); } o.jump[Math.round(1 / dt)] = +mx.toFixed(3); }
  // region label while standing at the highest reachable forest bank
  let worst = 0; for (let x = -92; x < -22; x += 1.5) for (let z = -34; z < 38; z += 1.5) if (E.inPlay(x, z)) { const w = E.regionWeights(x, E.terrainH(x, z), z); worst = Math.max(worst, w.sanct); } o.forestSanctWeight = +worst.toFixed(2);
  return o; });
console.log(JSON.stringify(r)); const jv = Object.values(r.jump);
const pass = r.bad.length === 0 && Math.max(...jv) - Math.min(...jv) < .03 && r.forestSanctWeight < .5;
console.log(pass ? 'BOUNDS PASS' : 'BOUNDS FAIL'); console.log(logs.join('\n') || 'no errors'); await browser.close();
