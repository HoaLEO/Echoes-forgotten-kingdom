// Automated full playthrough. Drives the real interaction objects and real key input.
import { open, begin, view } from './lib.mjs';
const { browser, page, logs } = await open(640, 360, 'low');
const res = []; const ok = (name, cond, extra = '') => { const l = (cond ? 'PASS ' : 'FAIL ') + name + (extra ? '  [' + extra + ']' : ''); res.push(l); console.log(l); };
const ev = (fn, arg) => page.evaluate(fn, arg);
const step = (n = 10, dt = .05) => ev(([n, dt]) => { for (let i = 0; i < n; i++) window.__EOTFK.stepFrame(dt); }, [n, dt]);
// helper: stand near an interactable, look at it, and use it through the normal picking path
const useNear = (label, opts = {}) => ev(([label, opts]) => {
  const E = window.__EOTFK, P = E.P, c = E.W.inter.filter(o => o.on && o.label && o.label.indexOf(label) >= 0);
  const o = opts.nth != null ? c[opts.nth] : c[0]; if (!o) return 'NOTFOUND ' + label;
  if (E.UI.panel) return 'PANEL OPEN ' + E.UI.panel;
  // find a free standing spot around the target
  let best = null; for (let a = 0; a < 16; a++) { const an = a / 16 * 6.283, d = opts.dist || 1.9, x = o.pos.x + Math.cos(an) * d, z = o.pos.z + Math.sin(an) * d, g = E.groundAt(x, z, o.pos.y + .5, 0); if (Math.abs(g + 1.4 - o.pos.y) > 1.6) continue; P.pos.set(x, g, z); const before = [P.pos.x, P.pos.z]; E.KEYS = null; P.vel.set(0, 0, 0); P.onGround = true; E.stepFrame(.02); if (Math.hypot(P.pos.x - before[0], P.pos.z - before[1]) < .05) { best = [x, g, z]; break; } }
  if (!best) return 'NOSPOT ' + label;
  const eye = P.pos.y + P.eye; P.yaw = Math.atan2(-(o.pos.x - P.pos.x), -(o.pos.z - P.pos.z)); P.pitch = Math.atan2(o.pos.y - eye, Math.hypot(o.pos.x - P.pos.x, o.pos.z - P.pos.z)); P.camY = P.pos.y;
  E.stepFrame(.02); const t = E.pickInter(); if (t !== o) return 'PICK MISMATCH wanted "' + o.label + '" got "' + (t ? t.label : 'none') + '"';
  window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyE' })); window.dispatchEvent(new KeyboardEvent('keyup', { code: 'KeyE' })); return 'OK';
}, [label, opts]);
const closePanel = async () => { for (let i = 0; i < 12; i++) { const p = await ev(() => window.__EOTFK.UI.panel); if (!p) return; await page.keyboard.press('KeyE'); await step(2); } };
const st = () => ev(() => { const E = window.__EOTFK, G = E.G; return { inv: Object.keys(G.inv), notes: G.notes.length, flags: Object.keys(G.flags), placed: Object.keys(G.placed), mode: G.mode, panel: E.UI.panel, pos: [E.P.pos.x, E.P.pos.y, E.P.pos.z].map(v => +v.toFixed(2)), obj: document.getElementById('objective').textContent, relic: document.getElementById('relicTxt').textContent }; });


let storageLost = 0;
// save -> reload page -> Continue -> world state must be identical
const reloadCheck = async (name) => {
  const a = await ev(() => { const E = window.__EOTFK; E.SAVE.write(); return E.snapshot(); });
  const raw = await ev(() => localStorage.getItem('eotfk_save_v1'));
  const load = async () => { await page.reload(); await page.waitForFunction(() => window.__EOTFK && window.__EOTFK.ready, null, { timeout: 180000 }); };
  await load();
  // headless Chrome on file:// sometimes drops localStorage across a reload; the game did write it (raw), so re-seed and note it
  if (await ev(() => localStorage.getItem('eotfk_save_v1')) !== raw) { storageLost++; await ev(r => localStorage.setItem('eotfk_save_v1', r), raw); await load(); }
  await ev(() => { window.__EOTFK.manual = true; });
  const hasBtn = await ev(() => !document.getElementById('btnContinue').classList.contains('hidden'));
  await ev(() => document.getElementById('btnContinue').click()); await page.waitForTimeout(200);
  await ev(() => { const E = window.__EOTFK; E.R.fade = 0; E.noRender = true; }); await step(4);
  const b = await ev(() => window.__EOTFK.snapshot());
  const dp = Math.hypot(a.pos[0] - b.pos[0], a.pos[1] - b.pos[1], a.pos[2] - b.pos[2]); const sd = Math.max(...a.stones.map((q, i) => Math.hypot(q[0] - b.stones[i][0], q[1] - b.stones[i][1]))); const A = { ...a, pos: 0, stones: sd < .15 }, B = { ...b, pos: 0, stones: true };
  const diff = Object.keys(A).filter(k => JSON.stringify(A[k]) !== JSON.stringify(B[k]));
  ok('save/continue restores world: ' + name, hasBtn && diff.length === 0 && dp < .5, diff.length ? 'DIFF ' + diff.map(k => k + ': ' + JSON.stringify(A[k]).slice(0, 120) + ' -> ' + JSON.stringify(B[k]).slice(0, 120)).join(' | ') : 'dp=' + dp.toFixed(2));
};
// ---- startup
ok('title screen visible', await ev(() => !document.getElementById('title').classList.contains('hidden')));
await begin(page); await ev(() => { window.__EOTFK.noRender = true; }); let s = await st();
ok('game starts in play mode at spawn', s.mode === 'play' && Math.abs(s.pos[2] - 16) < .5, JSON.stringify(s.pos));
ok('HUD shows 0/3 and first objective', s.relic === '0 / 3' && s.obj.length > 10, s.obj);

// ---- movement & collision with real key events
await page.keyboard.down('KeyW'); await step(40, .05); await page.keyboard.up('KeyW'); s = await st();
ok('W walks forward (north)', s.pos[2] < 9, 'z=' + s.pos[2]);
await page.keyboard.down('ShiftLeft'); await page.keyboard.down('KeyW'); await step(20, .05); const zs = (await st()).pos[2]; await page.keyboard.up('KeyW'); await page.keyboard.up('ShiftLeft');
ok('sprint is faster than walking', (s.pos[2] - zs) / 1.0 > 5.5, 'speed=' + ((s.pos[2] - zs)).toFixed(2));
await ev(() => { const P = window.__EOTFK.P; P.pos.set(0, 0, 10); P.vel.set(0, 0, 0); }); await step(3);
await page.keyboard.down('Space'); await step(4, .03); await page.keyboard.up('Space'); const yj = (await st()).pos[1]; await step(30, .03); const yl = (await st()).pos[1];
ok('jump leaves the ground and gravity returns', yj > .25 && Math.abs(yl) < .05, `apex~${yj} land=${yl}`);
await ev(() => { const P = window.__EOTFK.P; P.pos.set(-19, 0, 10); P.yaw = Math.PI / 2; P.vel.set(0, 0, 0); }); await page.keyboard.down('KeyW'); await step(60, .05); await page.keyboard.up('KeyW'); s = await st();
ok('courtyard wall blocks the player', s.pos[0] > -21.2, 'x=' + s.pos[0]);
await ev(() => { const P = window.__EOTFK.P; P.pos.set(18, 0, 0); P.yaw = -Math.PI / 2; P.vel.set(0, 0, 0); }); await page.keyboard.down('KeyW'); await step(60, .05); await page.keyboard.up('KeyW'); s = await st();
ok('locked temple door blocks the player', s.pos[0] < 21.4, 'x=' + s.pos[0]);
await ev(() => { const P = window.__EOTFK.P; P.pos.set(0, 0, 0); P.yaw = 0; P.vel.set(0, 0, 0); }); await page.keyboard.down('KeyW'); await step(120, .05); await page.keyboard.up('KeyW'); s = await st();
ok('player climbs the dais steps and is stopped by the sealed gate', s.pos[1] > .7 && s.pos[2] > -15, JSON.stringify(s.pos));

// ---- reading, journal, inventory, dialogue
ok('read Founding Stone', await useNear('Read — The Founding Stone') === 'OK'); await step(2); s = await st();
ok('reader opens and note is recorded', s.panel === 'reader' && s.notes === 1); await closePanel();
ok('speak with spirit', await useNear('Speak with Warden') === 'OK'); await step(2); ok('dialogue box open', (await st()).panel === 'dialog'); await closePanel(); ok('dialogue closes after last line', (await st()).panel === null);
await page.keyboard.press('KeyJ'); await step(2); ok('J opens journal', (await st()).panel === 'journal' && await ev(() => document.querySelectorAll('#jLeft .obj').length >= 1));
await page.keyboard.press('KeyI'); await step(2); ok('I switches to inventory', (await st()).panel === 'inventory'); await page.keyboard.press('Escape'); await step(2); ok('Esc closes panel', (await st()).panel === null);
await page.keyboard.press('Escape'); await step(2); ok('Esc opens pause menu', (await st()).panel === 'pause'); await page.keyboard.press('Escape'); await step(2);
ok('examine empty socket gives feedback', await useNear('Examine the empty socket') === 'OK');
ok('gate core not available before fragments', await ev(() => !window.__EOTFK.GATE.core.on));

// ---- secret cellar
ok('pull hidden lever', await useNear('Pull the iron branch') === 'OK'); await page.waitForTimeout(700); await step(120, .05);
ok('cellar door opened (collider off)', await ev(() => !!window.__EOTFK.G.flags.secret_cellar));
await ev(() => { const P = window.__EOTFK.P; P.pos.set(-10, 0, 18); P.yaw = Math.PI; P.vel.set(0, 0, 0); }); await page.keyboard.down('KeyW'); await step(70, .05); await page.keyboard.up('KeyW'); s = await st();
ok('player can walk into the cellar', s.pos[2] > 23, 'z=' + s.pos[2]);
ok('take hidden seal', await useNear('Take the golden seal') === 'OK'); ok('seal in inventory', (await st()).inv.includes('seal_king'));

// ---- FOREST: walk the trail for real (W + steering) to prove the path is traversable
const walkTo = async (tx, tz, max = 900) => ev(([tx, tz, max]) => { const E = window.__EOTFK, P = E.P; let i = 0; window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyW' })); for (; i < max; i++) { P.yaw = Math.atan2(-(tx - P.pos.x), -(tz - P.pos.z)); E.stepFrame(.04); if (Math.hypot(tx - P.pos.x, tz - P.pos.z) < 1.2) break; } window.dispatchEvent(new KeyboardEvent('keyup', { code: 'KeyW' })); return [i, +P.pos.x.toFixed(1), +P.pos.y.toFixed(1), +P.pos.z.toFixed(1)]; }, [tx, tz, max]);
const route = async (name, pts) => { let last; for (const p of pts) { last = await walkTo(p[0], p[1]); if (last[0] >= 900) { ok('walk: ' + name, false, 'stuck heading to ' + p + ' at ' + last.slice(1)); return false; } } ok('walk: ' + name, true, 'arrived ' + last.slice(1)); return true; };
await ev(() => { const P = window.__EOTFK.P; P.pos.set(-12, 0, 0); P.vel.set(0, 0, 0); });
await route('courtyard -> west arch -> forest trail -> glade', [[-20, 0], [-34, -4], [-48, 6], [-62, 2], [-71, 4]]);
ok('region toast: Whispering Forest', await ev(() => window.__EOTFK.G.region === 'forest'));
ok('read Song of Seasons', await useNear('Read — The Song of Seasons') === 'OK'); await closePanel();
// wrong order first
ok('touch wrong rune', await useNear('Wake the rune of the Sun') === 'OK'); await step(2);
ok('wrong rune resets with feedback', await ev(() => window.__EOTFK.RUNES.busy && window.__EOTFK.RUNES.idx === 0)); await step(26);
ok('runes usable again after reset', await ev(() => !window.__EOTFK.RUNES.busy));
ok('touch Root', await useNear('Wake the rune of the Tree') === 'OK'); ok('touch Wave', await useNear('Wake the rune of the Wave') === 'OK');
ok('partial progress kept', await ev(() => window.__EOTFK.RUNES.idx === 2));
ok('touch Star out of order', await useNear('Wake the rune of the Star') === 'OK'); await step(26);
ok('sequence reset to zero', await ev(() => window.__EOTFK.RUNES.idx === 0 && window.__EOTFK.RUNES.stones.every(s => !s.lit)));
ok('relic not obtainable before solving', await ev(() => !window.__EOTFK.W.inter.some(o => o.on && o.label === 'Take the Fragment of the Root')));
for (const r of ['Tree', 'Wave', 'Sun', 'Moon', 'Star']) { const u = await useNear('Wake the rune of the ' + r); if (u !== 'OK') ok('rune ' + r, false, u); }
await page.waitForTimeout(900); await step(80, .05);
ok('rune puzzle solved', await ev(() => window.__EOTFK.RUNES.solved));
ok('take Fragment of the Root', await useNear('Take the Fragment of the Root', { dist: 2.6 }) === 'OK'); s = await st();
ok('fragment 1 in inventory, HUD 1/3', s.inv.includes('frag_root') && s.relic === '1 / 3', s.relic);
await reloadCheck('after first fragment');
// hidden trail + key
await ev(() => { const P = window.__EOTFK.P; P.pos.set(-62, window.__EOTFK.terrainH(-62, 2), 2); P.vel.set(0, 0, 0); });
await route('fork -> hidden trail -> hollow', [[-48, 6.5], [-53, 20], [-59, 28.5]]);
ok('take Verdant Key', await useNear('Take the Verdant Key') === 'OK'); ok('take garden seal', await useNear('Take the leaf-marked seal') === 'OK');
await route('hollow -> fork -> grove', [[-53, 20], [-48, 6.5], [-34, -4], [-42, -20], [-43, -22]]);
ok('speak with Thalen', await useNear('Speak with Thalen') === 'OK'); await closePanel();
await route('grove -> courtyard -> temple door', [[-42, -20], [-34, -4], [-20, 0], [0, 4], [18.5, 0]]);

// ---- TEMPLE
ok('unlock temple door with key', await useNear('Unlock the temple door') === 'OK'); await step(100, .05); s = await st();
ok('key consumed, door flag set', !s.inv.includes('key_verdant') && s.flags.includes('door_temple'));
await route('door -> ramp -> causeway (with jump gap) -> hall', [[24, 0], [33, 0], [45.2, 0]]);
// jump the broken gap with a real jump
await ev(() => { const E = window.__EOTFK, P = E.P; P.yaw = -Math.PI / 2; const kd = c => window.dispatchEvent(new KeyboardEvent('keydown', { code: c })), ku = c => window.dispatchEvent(new KeyboardEvent('keyup', { code: c })); kd('KeyW'); for (let i = 0; i < 6; i++) E.stepFrame(.04); kd('Space'); for (let i = 0; i < 30; i++) E.stepFrame(.03); ku('Space'); for (let i = 0; i < 10; i++) E.stepFrame(.04); ku('KeyW'); });
s = await st(); ok('jumped the causeway gap (still on stone, past it)', s.pos[0] > 47.7 && s.pos[1] > -1.2, JSON.stringify(s.pos));
await route('causeway -> hall -> south corridor -> lens vault', [[58, 0], [62, 4], [65, 8.5], [65, 15], [65, 17.5]]);
s = await st(); ok('vault is flooded (player in water)', await ev(() => window.__EOTFK.P.inWater), 'y=' + s.pos[1]);
ok('examine blind lamp fails without lens (checked later)', true);
ok('take Crystal Lens', await useNear('Take the Crystal Lens') === 'OK');
await route('vault -> hall -> chamber of mirrors', [[65, 15], [65, 8.5], [70, 4], [73, 0], [77.5, 0], [79.5, 2.2]]);
ok('region: Sunken Temple', await ev(() => window.__EOTFK.G.region === 'temple'));
ok('beam off before lens', await ev(() => !window.__EOTFK.LIGHT.on));
ok('seat lens in lamp', await useNear('Seat the Crystal Lens') === 'OK'); await step(5); s = await st();
ok('lens consumed, beam on', !s.inv.includes('lens') && await ev(() => window.__EOTFK.LIGHT.on));
let tb = await ev(() => { const r = window.__EOTFK.traceBeam(); return { n: r.pts.length, hit: r.hit, end: r.pts[r.pts.length - 1] }; });
ok('initial beam is blocked by the pillar, not solved', !tb.hit && Math.abs(tb.end[0] - 88.32) < .05 && Math.abs(tb.end[1] - 4) < .01, JSON.stringify(tb));
// rotate mirrors through the real interaction; mirror indices 0..3
const turn = async (i, times) => { for (let k = 0; k < times; k++) { const u = await ev(i => { const E = window.__EOTFK, m = E.LIGHT.mirrors[i], P = E.P; const spots = [[0, 1.9], [1.9, 0], [-1.9, 0], [0, -1.9]]; for (const sp of spots) { const x = m.x + sp[0], z = m.z + sp[1]; P.pos.set(x, E.groundAt(x, z, 2, 0), z); P.vel.set(0, 0, 0); E.stepFrame(.02); if (Math.hypot(P.pos.x - x, P.pos.z - z) < .05) break; } const o = m.inter, eye = P.pos.y + P.eye; P.yaw = Math.atan2(-(o.pos.x - P.pos.x), -(o.pos.z - P.pos.z)); P.pitch = Math.atan2(o.pos.y - eye, Math.hypot(o.pos.x - P.pos.x, o.pos.z - P.pos.z)); E.stepFrame(.02); if (E.pickInter() !== o) return 'pick fail'; window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyE' })); window.dispatchEvent(new KeyboardEvent('keyup', { code: 'KeyE' })); return 'OK'; }, i); if (u !== 'OK') return u; await step(14, .05); } return 'OK'; };
ok('turn mirror 1 x3', await turn(0, 3) === 'OK');
tb = await ev(() => { const r = window.__EOTFK.traceBeam(); return { n: r.pts.length, hit: r.hit, pts: r.pts.map(p => p.map(v => +v.toFixed(2))) }; });
ok('beam now reflects north off mirror 1 to mirror 2', tb.pts.length >= 3 && Math.abs(tb.pts[1][0] - 84) < .02 && Math.abs(tb.pts[2][0] - 84) < .05 && tb.pts[2][1] < 0, JSON.stringify(tb.pts));
ok('turn mirror 2 x2', await turn(1, 2) === 'OK'); ok('not solved with two mirrors', await ev(() => !window.__EOTFK.LIGHT.solved));
await reloadCheck('mid mirror puzzle');
ok('turn mirror 3 x3', await turn(2, 3) === 'OK'); await step(30, .05);
tb = await ev(() => { const r = window.__EOTFK.traceBeam(); return { hit: r.hit, pts: r.pts.map(p => p.map(v => +v.toFixed(2))) }; });
ok('beam path emitter->M1->M2->M3->Eye', tb.hit && tb.pts.length === 5, JSON.stringify(tb.pts));
ok('light puzzle solved', await ev(() => window.__EOTFK.LIGHT.solved)); await page.waitForTimeout(1000); await step(120, .05);
await route('chamber -> hidden vault through opened door', [[86, -6], [86, -13.5]]);
ok('take Fragment of the Tide', await useNear('Take the Fragment of the Tide') === 'OK'); ok('take Star Key', await useNear('Take the Star Key') === 'OK'); s = await st();
ok('fragment 2 + star key held, HUD 2/3', s.inv.includes('frag_tide') && s.inv.includes('key_star') && s.relic === '2 / 3');
await reloadCheck('after temple');
ok('take sunken seal', await (async () => { await ev(() => { const P = window.__EOTFK.P; P.pos.set(50, -2, 11); P.vel.set(0, 0, 0); }); return useNear('Take the sunken seal', { dist: 1.6 }); })() === 'OK');

// ---- SANCTUARY
await ev(() => { const P = window.__EOTFK.P; P.pos.set(12, 0, -17); P.vel.set(0, 0, 0); });
ok('unlock barred stair', await useNear('Unlock the barred stair') === 'OK'); await step(100, .05);
await ev(() => { const P = window.__EOTFK.P; P.pos.set(12, 0, -18); P.vel.set(0, 0, 0); });
await route('mountain stair to the summit', [[12, -24], [30, -36], [42, -60], [34, -82], [21, -91.5], [13, -94.5]]);
s = await st(); ok('reached the summit plateau', s.pos[1] > 27.5, JSON.stringify(s.pos));
ok('region: Celestial Sanctuary', await ev(() => window.__EOTFK.G.region === 'sanct'));
// containment: try to walk off the summit in 12 directions
const fell = await ev(() => { const E = window.__EOTFK, P = E.P; let bad = 0; window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyW' })); for (let a = 0; a < 12; a++) { P.pos.set(0 + Math.cos(a) * 5, 28, -95 + Math.sin(a) * 5); P.vel.set(0, 0, 0); P.yaw = Math.atan2(-Math.cos(a), -Math.sin(a)); for (let i = 0; i < 160; i++) E.stepFrame(.04); if (P.pos.y < 26 && Math.hypot(P.pos.x, P.pos.z + 95) > 19 && !(P.pos.x > 12 && Math.abs(P.pos.z + 94) < 6)) bad++; } window.dispatchEvent(new KeyboardEvent('keyup', { code: 'KeyW' })); return bad; });
ok('cannot fall off the summit (12 directions)', fell === 0, 'escapes=' + fell);
ok('read astrolabe', await (async () => { await ev(() => { const P = window.__EOTFK.P; P.pos.set(6, 28, -92); P.vel.set(0, 0, 0); }); return useNear('Read — The Astrolabe Stone'); })() === 'OK'); await closePanel();
// drag each stone by grabbing it and physically walking toward its plate
const drag = async (name, px, pz, via = []) => ev(([name, px, pz, via]) => {
  const E = window.__EOTFK, P = E.P, s = E.PLATES.stones.find(q => q.name === name), pts = via.concat([[px, pz]]);
  const dx = pts[0][0] - s.x, dz = pts[0][1] - s.z, d = Math.hypot(dx, dz); P.pos.set(s.x - dx / d * 1.6, 28, s.z - dz / d * 1.6); P.vel.set(0, 0, 0); P.yaw = Math.atan2(-dx, -dz); P.pitch = -.45; E.stepFrame(.02);
  if (E.pickInter() !== s.inter) return 'pick fail: ' + (E.pickInter() ? E.pickInter().label : 'none');
  document.getElementById('view').dispatchEvent(new MouseEvent('mousedown', { button: 0, bubbles: true }));   // left mouse button grabs
  if (P.grab !== s) return 'grab fail panel=' + E.UI.panel;
  window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyW' })); let i = 0, k = 0;
  for (; i < 1500; i++) { const tx = pts[k][0] - s.x, tz = pts[k][1] - s.z, td = Math.hypot(tx, tz); if (td < (k < pts.length - 1 ? .6 : .2)) { if (++k >= pts.length) break; continue; }
    P.yaw = Math.atan2(-(pts[k][0] - P.pos.x), -(pts[k][1] - P.pos.z)); E.stepFrame(.04); if (P.grab !== s) return 'dropped at ' + s.x.toFixed(1) + ',' + s.z.toFixed(1); }
  window.dispatchEvent(new KeyboardEvent('keyup', { code: 'KeyW' })); P.yaw = Math.atan2(-(s.x - P.pos.x), -(s.z - P.pos.z)); E.stepFrame(.02);
  window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyE' })); window.dispatchEvent(new KeyboardEvent('keyup', { code: 'KeyE' }));   // E releases
  const dd = Math.hypot(px - s.x, pz - s.z); return (P.grab ? 'still held ' : dd < .5 ? 'OK ' : 'MISSED ') + i + ' d=' + dd.toFixed(2);
}, [name, px, pz, via]);
let d1 = await drag('moon', 7.5, -95); ok('drag MOON stone onto the SUN plate (wrong on purpose)', d1.startsWith('OK'), d1); await step(5);
ok('wrong stone wakes plate (state 1) but does not solve', await ev(() => window.__EOTFK.PLATES.plates[0].state === 1 && !window.__EOTFK.PLATES.solved));
ok('Rune of Return resets stones', await useNear('Touch the Rune of Return') === 'OK'); await step(10);
ok('stones back home', await ev(() => window.__EOTFK.PLATES.stones.every(s => Math.hypot(s.x - s.hx, s.z - s.hz) < .01) && window.__EOTFK.PLATES.plates[0].state === 0));
d1 = await drag('sun', 7.5, -95, [[-3, -85.5], [5, -87]]); ok('drag SUN stone to SUN plate', d1.startsWith('OK'), d1);
d1 = await drag('moon', -7.5, -95); ok('drag MOON stone to MOON plate', d1.startsWith('OK'), d1);
ok('two plates correct, not yet solved', await ev(() => !window.__EOTFK.PLATES.solved && window.__EOTFK.PLATES.plates.filter(p => p.state === 2).length === 2), await ev(() => JSON.stringify({ pl: window.__EOTFK.PLATES.plates.map(p => [p.name, p.state, p.x, p.z]), st: window.__EOTFK.PLATES.stones.map(s => [s.name, +s.x.toFixed(2), +s.z.toFixed(2)]) })));
await reloadCheck('mid plate puzzle');
d1 = await drag('star', 0, -102.5, [[6, -87.5], [10.3, -93.5], [10.3, -97], [7, -102.6]]); ok('drag STAR stone to STAR plate', d1.startsWith('OK'), d1); await step(40, .05);
ok('plate puzzle solved', await ev(() => window.__EOTFK.PLATES.solved)); await step(80, .05);
ok('take Fragment of the Sky', await useNear('Take the Fragment of the Sky', { dist: 3.3 }) === 'OK'); s = await st();
ok('all three fragments, HUD 3/3', s.relic === '3 / 3' && ['frag_root', 'frag_tide', 'frag_sky'].every(f => s.inv.includes(f)), s.relic);
ok('take astronomer seal', await useNear('Take the star-engraved seal') === 'OK');
await route('walk back down the mountain to the courtyard', [[13, -94.5], [21, -91.5], [34, -82], [42, -60], [30, -36], [12, -24], [12, -17], [0, -8]]);

// ---- FINALE
for (const n of ['Fragment of the Root', 'Fragment of the Tide', 'Fragment of the Sky']) { const u = await useNear('Set the ' + n); ok('place ' + n, u === 'OK', u); await step(3); }
s = await st(); ok('fragments consumed from inventory, 3 placed', s.placed.length === 3 && !s.inv.some(i => i.startsWith('frag')), JSON.stringify(s.placed));
await reloadCheck('fragments placed in gate');
ok('HUD still 3/3 and objective is to awaken the gate', s.relic === '3 / 3' && /Awaken/.test(s.obj), s.obj);
await page.keyboard.press('KeyI'); await step(2); ok('inventory lists 4 hidden seals', await ev(() => document.querySelectorAll('#invList .slot').length >= 4 && window.__EOTFK.G.secrets() === 4)); await page.keyboard.press('KeyI'); await step(2);
ok('awaken the Echo Gate', await useNear('Awaken the Echo Gate', { dist: 3.5 }) === 'OK'); await step(5);
ok('cinematic mode, input frozen', await ev(() => window.__EOTFK.G.mode === 'cine' && window.__EOTFK.P.frozen));
await step(160, .05); await ev(() => { window.__EOTFK.noRender = false; }); await view(page, null, null, 0, 0, 'p_finale.png'); await ev(() => { window.__EOTFK.noRender = true; });
await step(180, .05);
ok('victory screen shown', await ev(() => window.__EOTFK.G.mode === 'end' && !document.getElementById('victory').classList.contains('hidden')), await ev(() => document.getElementById('vStats').textContent));
// ---- restart
await ev(() => document.querySelector('#victory [data-act=restart]').click());
await page.waitForFunction(() => window.__EOTFK && window.__EOTFK.ready && window.__EOTFK.G.mode === 'title', null, { timeout: 120000 });
ok('restart returns to a fresh title screen', await ev(() => Object.keys(window.__EOTFK.G.inv).length === 0 && !document.getElementById('title').classList.contains('hidden')));
console.log('\n' + res.filter(r => r.startsWith('PASS')).length + ' passed, ' + res.filter(r => r.startsWith('FAIL')).length + ' failed');
console.log(logs.length ? 'CONSOLE:\n' + [...new Set(logs)].slice(0, 15).join('\n') : 'no console errors, no external requests');
await browser.close();
